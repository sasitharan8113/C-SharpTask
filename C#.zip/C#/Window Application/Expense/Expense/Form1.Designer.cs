﻿namespace Expense
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tc_expense = new System.Windows.Forms.TabControl();
            this.tb_category = new System.Windows.Forms.TabPage();
            this.lbl_expenseCategory = new System.Windows.Forms.Label();
            this.pn_category = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_expenseNewButton = new System.Windows.Forms.Button();
            this.btn_expenseLogoutButton = new System.Windows.Forms.Button();
            this.btn_expenseClearButton = new System.Windows.Forms.Button();
            this.btn_categorySubmitButton = new System.Windows.Forms.Button();
            this.txt_categoryName = new System.Windows.Forms.TextBox();
            this.lbl_categoryName = new System.Windows.Forms.Label();
            this.txt_categoryId = new System.Windows.Forms.TextBox();
            this.lbl_categoryId = new System.Windows.Forms.Label();
            this.tb_subCategory = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cb_productType = new System.Windows.Forms.ComboBox();
            this.txt_descriptionExpense = new System.Windows.Forms.TextBox();
            this.lbl_descriptionExpense = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_newExpenseButton = new System.Windows.Forms.Button();
            this.btn_logoutExpenseButton = new System.Windows.Forms.Button();
            this.btn_clearExpenseButton = new System.Windows.Forms.Button();
            this.btn_submitExpenseButton = new System.Windows.Forms.Button();
            this.txt_productName = new System.Windows.Forms.TextBox();
            this.lbl_productName = new System.Windows.Forms.Label();
            this.lbl_productType = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tc_expense.SuspendLayout();
            this.tb_category.SuspendLayout();
            this.pn_category.SuspendLayout();
            this.tb_subCategory.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tc_expense
            // 
            this.tc_expense.Controls.Add(this.tb_category);
            this.tc_expense.Controls.Add(this.tb_subCategory);
            this.tc_expense.Controls.Add(this.tabPage1);
            this.tc_expense.Location = new System.Drawing.Point(45, 71);
            this.tc_expense.Name = "tc_expense";
            this.tc_expense.SelectedIndex = 0;
            this.tc_expense.Size = new System.Drawing.Size(1827, 815);
            this.tc_expense.TabIndex = 0;
            // 
            // tb_category
            // 
            this.tb_category.BackColor = System.Drawing.Color.Gray;
            this.tb_category.Controls.Add(this.lbl_expenseCategory);
            this.tb_category.Controls.Add(this.pn_category);
            this.tb_category.Location = new System.Drawing.Point(4, 29);
            this.tb_category.Name = "tb_category";
            this.tb_category.Padding = new System.Windows.Forms.Padding(3);
            this.tb_category.Size = new System.Drawing.Size(1819, 782);
            this.tb_category.TabIndex = 0;
            this.tb_category.Text = "category";
            // 
            // lbl_expenseCategory
            // 
            this.lbl_expenseCategory.AutoSize = true;
            this.lbl_expenseCategory.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_expenseCategory.Location = new System.Drawing.Point(762, 117);
            this.lbl_expenseCategory.Name = "lbl_expenseCategory";
            this.lbl_expenseCategory.Size = new System.Drawing.Size(295, 41);
            this.lbl_expenseCategory.TabIndex = 10;
            this.lbl_expenseCategory.Text = "Expense Category";
            // 
            // pn_category
            // 
            this.pn_category.Controls.Add(this.label2);
            this.pn_category.Controls.Add(this.label1);
            this.pn_category.Controls.Add(this.btn_expenseNewButton);
            this.pn_category.Controls.Add(this.btn_expenseLogoutButton);
            this.pn_category.Controls.Add(this.btn_expenseClearButton);
            this.pn_category.Controls.Add(this.btn_categorySubmitButton);
            this.pn_category.Controls.Add(this.txt_categoryName);
            this.pn_category.Controls.Add(this.lbl_categoryName);
            this.pn_category.Controls.Add(this.txt_categoryId);
            this.pn_category.Controls.Add(this.lbl_categoryId);
            this.pn_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pn_category.Location = new System.Drawing.Point(532, 196);
            this.pn_category.Name = "pn_category";
            this.pn_category.Size = new System.Drawing.Size(755, 390);
            this.pn_category.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(316, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 37);
            this.label2.TabIndex = 8;
            this.label2.Text = "*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(268, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 37);
            this.label1.TabIndex = 7;
            this.label1.Text = "*";
            // 
            // btn_expenseNewButton
            // 
            this.btn_expenseNewButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_expenseNewButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_expenseNewButton.ForeColor = System.Drawing.Color.White;
            this.btn_expenseNewButton.Location = new System.Drawing.Point(39, 275);
            this.btn_expenseNewButton.Name = "btn_expenseNewButton";
            this.btn_expenseNewButton.Size = new System.Drawing.Size(154, 49);
            this.btn_expenseNewButton.TabIndex = 6;
            this.btn_expenseNewButton.Text = "New";
            this.btn_expenseNewButton.UseVisualStyleBackColor = false;
            this.btn_expenseNewButton.Click += new System.EventHandler(this.btn_expenseNewButton_Click);
            // 
            // btn_expenseLogoutButton
            // 
            this.btn_expenseLogoutButton.BackColor = System.Drawing.Color.Red;
            this.btn_expenseLogoutButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_expenseLogoutButton.ForeColor = System.Drawing.Color.Black;
            this.btn_expenseLogoutButton.Location = new System.Drawing.Point(566, 275);
            this.btn_expenseLogoutButton.Name = "btn_expenseLogoutButton";
            this.btn_expenseLogoutButton.Size = new System.Drawing.Size(154, 49);
            this.btn_expenseLogoutButton.TabIndex = 5;
            this.btn_expenseLogoutButton.Text = "Logout";
            this.btn_expenseLogoutButton.UseVisualStyleBackColor = false;
            this.btn_expenseLogoutButton.Click += new System.EventHandler(this.btn_expenseLogoutButton_Click);
            // 
            // btn_expenseClearButton
            // 
            this.btn_expenseClearButton.BackColor = System.Drawing.Color.Gray;
            this.btn_expenseClearButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_expenseClearButton.ForeColor = System.Drawing.Color.White;
            this.btn_expenseClearButton.Location = new System.Drawing.Point(391, 275);
            this.btn_expenseClearButton.Name = "btn_expenseClearButton";
            this.btn_expenseClearButton.Size = new System.Drawing.Size(154, 49);
            this.btn_expenseClearButton.TabIndex = 4;
            this.btn_expenseClearButton.Text = "Clear";
            this.btn_expenseClearButton.UseVisualStyleBackColor = false;
            this.btn_expenseClearButton.Click += new System.EventHandler(this.btn_expenseClearButton_Click);
            this.btn_expenseClearButton.KeyUp += new System.Windows.Forms.KeyEventHandler(this.btn_expenseClearButton_KeyUp);
            // 
            // btn_categorySubmitButton
            // 
            this.btn_categorySubmitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_categorySubmitButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_categorySubmitButton.Location = new System.Drawing.Point(215, 275);
            this.btn_categorySubmitButton.Name = "btn_categorySubmitButton";
            this.btn_categorySubmitButton.Size = new System.Drawing.Size(154, 49);
            this.btn_categorySubmitButton.TabIndex = 3;
            this.btn_categorySubmitButton.Text = "Submit";
            this.btn_categorySubmitButton.UseVisualStyleBackColor = false;
            this.btn_categorySubmitButton.Click += new System.EventHandler(this.btn_categorySubmitButton_Click);
            // 
            // txt_categoryName
            // 
            this.txt_categoryName.Location = new System.Drawing.Point(379, 190);
            this.txt_categoryName.Name = "txt_categoryName";
            this.txt_categoryName.Size = new System.Drawing.Size(178, 44);
            this.txt_categoryName.TabIndex = 2;
            this.txt_categoryName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_categoryName_KeyUp);
            // 
            // lbl_categoryName
            // 
            this.lbl_categoryName.AutoSize = true;
            this.lbl_categoryName.BackColor = System.Drawing.Color.White;
            this.lbl_categoryName.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_categoryName.Location = new System.Drawing.Point(102, 188);
            this.lbl_categoryName.Name = "lbl_categoryName";
            this.lbl_categoryName.Size = new System.Drawing.Size(221, 36);
            this.lbl_categoryName.TabIndex = 2;
            this.lbl_categoryName.Text = "Category Name:";
            // 
            // txt_categoryId
            // 
            this.txt_categoryId.Location = new System.Drawing.Point(379, 93);
            this.txt_categoryId.Name = "txt_categoryId";
            this.txt_categoryId.Size = new System.Drawing.Size(178, 44);
            this.txt_categoryId.TabIndex = 1;
            this.txt_categoryId.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_categoryId_KeyUp);
            // 
            // lbl_categoryId
            // 
            this.lbl_categoryId.AutoSize = true;
            this.lbl_categoryId.BackColor = System.Drawing.Color.White;
            this.lbl_categoryId.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_categoryId.Location = new System.Drawing.Point(102, 93);
            this.lbl_categoryId.Name = "lbl_categoryId";
            this.lbl_categoryId.Size = new System.Drawing.Size(174, 36);
            this.lbl_categoryId.TabIndex = 0;
            this.lbl_categoryId.Text = "Category Id:";
            // 
            // tb_subCategory
            // 
            this.tb_subCategory.BackColor = System.Drawing.Color.RosyBrown;
            this.tb_subCategory.Controls.Add(this.label7);
            this.tb_subCategory.Controls.Add(this.panel1);
            this.tb_subCategory.Location = new System.Drawing.Point(4, 29);
            this.tb_subCategory.Name = "tb_subCategory";
            this.tb_subCategory.Padding = new System.Windows.Forms.Padding(3);
            this.tb_subCategory.Size = new System.Drawing.Size(1819, 782);
            this.tb_subCategory.TabIndex = 1;
            this.tb_subCategory.Text = "Sub_category";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(719, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(363, 41);
            this.label7.TabIndex = 11;
            this.label7.Text = "Expense Sub Category";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.cb_productType);
            this.panel1.Controls.Add(this.txt_descriptionExpense);
            this.panel1.Controls.Add(this.lbl_descriptionExpense);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.btn_newExpenseButton);
            this.panel1.Controls.Add(this.btn_logoutExpenseButton);
            this.panel1.Controls.Add(this.btn_clearExpenseButton);
            this.panel1.Controls.Add(this.btn_submitExpenseButton);
            this.panel1.Controls.Add(this.txt_productName);
            this.panel1.Controls.Add(this.lbl_productName);
            this.panel1.Controls.Add(this.lbl_productType);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(532, 136);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(755, 511);
            this.panel1.TabIndex = 1;
            // 
            // cb_productType
            // 
            this.cb_productType.FormattingEnabled = true;
            this.cb_productType.Location = new System.Drawing.Point(379, 85);
            this.cb_productType.Name = "cb_productType";
            this.cb_productType.Size = new System.Drawing.Size(210, 45);
            this.cb_productType.TabIndex = 11;
            // 
            // txt_descriptionExpense
            // 
            this.txt_descriptionExpense.Location = new System.Drawing.Point(379, 274);
            this.txt_descriptionExpense.Multiline = true;
            this.txt_descriptionExpense.Name = "txt_descriptionExpense";
            this.txt_descriptionExpense.Size = new System.Drawing.Size(235, 72);
            this.txt_descriptionExpense.TabIndex = 10;
            // 
            // lbl_descriptionExpense
            // 
            this.lbl_descriptionExpense.AutoSize = true;
            this.lbl_descriptionExpense.BackColor = System.Drawing.Color.White;
            this.lbl_descriptionExpense.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_descriptionExpense.Location = new System.Drawing.Point(102, 278);
            this.lbl_descriptionExpense.Name = "lbl_descriptionExpense";
            this.lbl_descriptionExpense.Size = new System.Drawing.Size(171, 36);
            this.lbl_descriptionExpense.TabIndex = 9;
            this.lbl_descriptionExpense.Text = "Description:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(300, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 37);
            this.label3.TabIndex = 8;
            this.label3.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(287, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 37);
            this.label4.TabIndex = 7;
            this.label4.Text = "*";
            // 
            // btn_newExpenseButton
            // 
            this.btn_newExpenseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_newExpenseButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newExpenseButton.ForeColor = System.Drawing.Color.White;
            this.btn_newExpenseButton.Location = new System.Drawing.Point(44, 385);
            this.btn_newExpenseButton.Name = "btn_newExpenseButton";
            this.btn_newExpenseButton.Size = new System.Drawing.Size(154, 49);
            this.btn_newExpenseButton.TabIndex = 6;
            this.btn_newExpenseButton.Text = "New";
            this.btn_newExpenseButton.UseVisualStyleBackColor = false;
            this.btn_newExpenseButton.Click += new System.EventHandler(this.btn_newExpenseButton_Click);
            // 
            // btn_logoutExpenseButton
            // 
            this.btn_logoutExpenseButton.BackColor = System.Drawing.Color.Red;
            this.btn_logoutExpenseButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logoutExpenseButton.ForeColor = System.Drawing.Color.Black;
            this.btn_logoutExpenseButton.Location = new System.Drawing.Point(571, 385);
            this.btn_logoutExpenseButton.Name = "btn_logoutExpenseButton";
            this.btn_logoutExpenseButton.Size = new System.Drawing.Size(154, 49);
            this.btn_logoutExpenseButton.TabIndex = 5;
            this.btn_logoutExpenseButton.Text = "Logout";
            this.btn_logoutExpenseButton.UseVisualStyleBackColor = false;
            this.btn_logoutExpenseButton.Click += new System.EventHandler(this.btn_logoutExpenseButton_Click);
            // 
            // btn_clearExpenseButton
            // 
            this.btn_clearExpenseButton.BackColor = System.Drawing.Color.Gray;
            this.btn_clearExpenseButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clearExpenseButton.ForeColor = System.Drawing.Color.White;
            this.btn_clearExpenseButton.Location = new System.Drawing.Point(396, 385);
            this.btn_clearExpenseButton.Name = "btn_clearExpenseButton";
            this.btn_clearExpenseButton.Size = new System.Drawing.Size(154, 49);
            this.btn_clearExpenseButton.TabIndex = 4;
            this.btn_clearExpenseButton.Text = "Clear";
            this.btn_clearExpenseButton.UseVisualStyleBackColor = false;
            this.btn_clearExpenseButton.Click += new System.EventHandler(this.btn_clearExpenseButton_Click);
            // 
            // btn_submitExpenseButton
            // 
            this.btn_submitExpenseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_submitExpenseButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_submitExpenseButton.Location = new System.Drawing.Point(220, 385);
            this.btn_submitExpenseButton.Name = "btn_submitExpenseButton";
            this.btn_submitExpenseButton.Size = new System.Drawing.Size(154, 49);
            this.btn_submitExpenseButton.TabIndex = 3;
            this.btn_submitExpenseButton.Text = "Submit";
            this.btn_submitExpenseButton.UseVisualStyleBackColor = false;
            this.btn_submitExpenseButton.Click += new System.EventHandler(this.btn_submitExpenseButton_Click);
            // 
            // txt_productName
            // 
            this.txt_productName.Location = new System.Drawing.Point(379, 190);
            this.txt_productName.Name = "txt_productName";
            this.txt_productName.Size = new System.Drawing.Size(210, 44);
            this.txt_productName.TabIndex = 2;
            // 
            // lbl_productName
            // 
            this.lbl_productName.AutoSize = true;
            this.lbl_productName.BackColor = System.Drawing.Color.White;
            this.lbl_productName.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_productName.Location = new System.Drawing.Point(102, 188);
            this.lbl_productName.Name = "lbl_productName";
            this.lbl_productName.Size = new System.Drawing.Size(205, 36);
            this.lbl_productName.TabIndex = 2;
            this.lbl_productName.Text = "Product Name:";
            // 
            // lbl_productType
            // 
            this.lbl_productType.AutoSize = true;
            this.lbl_productType.BackColor = System.Drawing.Color.White;
            this.lbl_productType.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_productType.Location = new System.Drawing.Point(102, 93);
            this.lbl_productType.Name = "lbl_productType";
            this.lbl_productType.Size = new System.Drawing.Size(192, 36);
            this.lbl_productType.TabIndex = 0;
            this.lbl_productType.Text = "Product Type:";
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1819, 782);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Account_expenses";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.tc_expense);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tc_expense.ResumeLayout(false);
            this.tb_category.ResumeLayout(false);
            this.tb_category.PerformLayout();
            this.pn_category.ResumeLayout(false);
            this.pn_category.PerformLayout();
            this.tb_subCategory.ResumeLayout(false);
            this.tb_subCategory.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tc_expense;
        private System.Windows.Forms.TabPage tb_category;
        private System.Windows.Forms.TabPage tb_subCategory;
        private System.Windows.Forms.Panel pn_category;
        private System.Windows.Forms.Label lbl_expenseCategory;
        private System.Windows.Forms.TextBox txt_categoryName;
        private System.Windows.Forms.Label lbl_categoryName;
        private System.Windows.Forms.TextBox txt_categoryId;
        private System.Windows.Forms.Label lbl_categoryId;
        private System.Windows.Forms.Button btn_expenseLogoutButton;
        private System.Windows.Forms.Button btn_expenseClearButton;
        private System.Windows.Forms.Button btn_categorySubmitButton;
        private System.Windows.Forms.Button btn_expenseNewButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_newExpenseButton;
        private System.Windows.Forms.Button btn_logoutExpenseButton;
        private System.Windows.Forms.Button btn_clearExpenseButton;
        private System.Windows.Forms.Button btn_submitExpenseButton;
        private System.Windows.Forms.TextBox txt_productName;
        private System.Windows.Forms.Label lbl_productName;
        private System.Windows.Forms.Label lbl_productType;
        private System.Windows.Forms.TextBox txt_descriptionExpense;
        private System.Windows.Forms.Label lbl_descriptionExpense;
        private System.Windows.Forms.ComboBox cb_productType;
        private System.Windows.Forms.TabPage tabPage1;
    }
}

