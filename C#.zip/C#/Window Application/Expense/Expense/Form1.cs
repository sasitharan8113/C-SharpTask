﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Expense
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            BindData();
            display2();
        }

        SqlConnection connection = new SqlConnection(@"Data Source=localhost;Initial Catalog=dbBank;Integrated Security=True");

        private void btn_categorySubmitButton_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "insert into tb_expense values(@category_id,@category_name)";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@category_id", txt_categoryId.Text);
            cmd.Parameters.AddWithValue("@category_name",txt_categoryName.Text);
            cmd.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Insert data is successfully.");
        }

        private void btn_expenseClearButton_Click(object sender, EventArgs e)
        {
            txt_categoryId.Clear();
            txt_categoryName.Clear();   
        }

        private void btn_expenseLogoutButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_expenseNewButton_Click(object sender, EventArgs e)
        {
            string regNumber1;
            connection.Open();
            txt_categoryId.Clear();
            txt_categoryName.Clear();
            string query = "select category_id from tb_expense order by category_id desc";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                int id = int.Parse(reader[0].ToString()) + 1;
                regNumber1 = id.ToString("0");
            }
            else if (Convert.IsDBNull(reader))
            {
                regNumber1 = "1";
            }
            else
            {
                regNumber1 = "1";
            }
            txt_categoryId.Text = regNumber1.ToString();
            txt_categoryId.Focus();
            connection.Close();
        }

        private void txt_categoryId_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void txt_categoryName_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void btn_expenseClearButton_KeyUp(object sender, KeyEventArgs e)
        {
            btn_expenseNewButton.Focus();
        }

        public void display2()
        {
            connection.Open();
            string query2 = "select category_id,category_name from tb_expense order by category_id;";
            SqlDataAdapter adapter = new SqlDataAdapter(query2, connection);
            DataSet table = new DataSet();
            adapter.Fill(table);
            cb_productType.DataSource = table.Tables[0];
            cb_productType.DisplayMember = "category_name";
            cb_productType.ValueMember = "category_id";
            connection.Close();
        }

        private void btn_logoutExpenseButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_clearExpenseButton_Click(object sender, EventArgs e)
        {
            cb_productType.Text = String.Empty;
            txt_productName.Clear();
            txt_descriptionExpense.Clear();
        }

        private void btn_newExpenseButton_Click(object sender, EventArgs e)
        {
            cb_productType.Text = String.Empty;
            txt_productName.Clear();
            txt_descriptionExpense.Clear();
        }

        private void btn_submitExpenseButton_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "insert into tb_expenseSubCategory values" +
                "(@product_type,@product_name,@decription)";
            SqlCommand command=new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@product_type",cb_productType.Text);
            command.Parameters.AddWithValue("@product_name", txt_productName.Text);
            command.Parameters.AddWithValue("@decription", txt_descriptionExpense.Text);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Insert data is successfully");
        }

        public void BindData()
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("select category_name from tb_expense", connection);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                cb_productType.Items.Add(dr[0].ToString());
            }
            dr.Close();
            connection.Close();
        }

    }
}
