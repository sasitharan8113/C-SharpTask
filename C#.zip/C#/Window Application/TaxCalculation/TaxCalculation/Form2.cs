﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TaxCalculation
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            generateId();
            display();
            generateId1();
            display1();
            display2();
            generateCustomerId();
            displaycustomerBilling();
            displayFinancial();
            displayLogin();
            clearData3();
        }

        SqlConnection connection = new SqlConnection(@"Data Source=localhost;Initial Catalog=dbBank;Integrated Security=True");

        //Insert the data in tax.
        private void btn_save_Click(object sender, EventArgs e)
        {
            connection.Open();
            try
            {
                string query1 = "insert into tb_tax values(@taxId,@taxName,@taxValue)";
                SqlCommand cmd = new SqlCommand(query1, connection);
                cmd.Parameters.AddWithValue("@taxId", int.Parse(txt_taxId.Text));
                cmd.Parameters.AddWithValue("@taxName", txt_taxName.Text);
                cmd.Parameters.AddWithValue("@taxValue", txt_taxValue.Text);
                cmd.ExecuteNonQuery();
                connection.Close();
                display();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Insert the data is successfully.");
        }

        public void generateId()
        {
            string regNumber;
            connection.Open();
            string query = "select taxId from tb_tax order by taxId desc";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                int id = int.Parse(reader[0].ToString())+1;
                regNumber = id.ToString("100");
            }
            else if (Convert.IsDBNull(reader))
            {
                regNumber = "101";
            }
            else
            {
                regNumber = "101";
            }
            connection.Close();

            txt_taxId.Text= regNumber.ToString();
        }

        //Clear text box in tax.
        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_taxId.Text = "";
            txt_taxName.Text = "";
            txt_taxValue.Text = "";
        }

        //Tax page Exit.
        private void btn_logout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Delete data in Tax.
        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "delete tb_tax where taxId=@taxId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@taxId", txt_taxId.Text);
                command.ExecuteNonQuery();
                connection.Close();
                display();
            }catch(Exception ex) {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Successfully Deleted");
        }

        //Edit data in tax details.
        private void btn_edit_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "update tb_tax set taxName=@taxName,taxValue=@taxValue where taxId=@taxId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@taxId", int.Parse(txt_taxId.Text));
                command.Parameters.AddWithValue("@taxName", txt_taxName.Text);
                command.Parameters.AddWithValue("@taxValue", txt_taxValue.Text);
                command.ExecuteNonQuery();
                connection.Close();
                display();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Update the data is successfully.");
        }

        private void dg_view_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_taxId.Text = dg_view.CurrentRow.Cells[1].Value.ToString();
            txt_taxName.Text = dg_view.CurrentRow.Cells[2].Value.ToString();
            txt_taxValue.Text = dg_view.CurrentRow.Cells[3].Value.ToString();
        }

        public void display()
        {
            connection.Open();
            string query = "select * from tb_tax order by id;";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dg_view.DataSource = table;
            command.ExecuteNonQuery();
            connection.Close();
        }

        //Refresh Page in tax.
        private void btn_new_Click(object sender, EventArgs e)
        {
            clearData();
            generateId();
            display();
        }
        public void clearData()
        {
            txt_taxName.Text = "";
            txt_taxValue.Text = "";
        }



        //-------------------------------------------------------------------------------------------



        //Refresh Page in item details
        private void btn_new1_Click(object sender, EventArgs e)
        {
            generateId1();
            display1();
            clear();
        }

        //Insert the data in item details.
        private void btn_save1_Click(object sender, EventArgs e)
        {
            connection.Open();
            try
            {
                string query1 = "insert into tb_itemCode values(@itemCode,@itemName,@hsnCode,@unit,@tax,@taxValue,@sellingPrice)";
                SqlCommand cmd = new SqlCommand(query1, connection);
                cmd.Parameters.AddWithValue("@itemCode", int.Parse(txt_itemCode.Text));
                cmd.Parameters.AddWithValue("@itemName", txt_itemName.Text);
                cmd.Parameters.AddWithValue("@hsnCode", int.Parse(txt_hsnCode.Text));
                cmd.Parameters.AddWithValue("@unit", txt_unit.Text);
                cmd.Parameters.AddWithValue("@tax", cb_tax.SelectedValue);
                cmd.Parameters.AddWithValue("@taxValue",txt_taxValueItem.Text);
                cmd.Parameters.AddWithValue("@sellingPrice", txt_sellingPrice.Text);
                cmd.ExecuteNonQuery();
                connection.Close();
                display1();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Insert the data is successfully.");
        }

        //Remove the Item details
        private void btn_delete1_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "delete tb_itemCode where itemCode=@itemCode";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@itemCode", int.Parse(txt_itemCode.Text));
                command.ExecuteNonQuery();
                connection.Close();
                display1();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Successfully Deleted");
        }

        //clear data in text box.
        private void btn_clear1_Click(object sender, EventArgs e)
        {
            txt_itemCode.Text = "";
            txt_itemName.Text = "";
            txt_hsnCode.Text = "";
            txt_unit.Text = "";
            cb_tax.Text = "";
            txt_taxValueItem.Text = "";
            txt_sellingPrice.Text = "";
        }

        //Exit page.
        private void btn_logout1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        public void generateId1()
        {
            connection.Open();
            string regNumber1;
            string query = "select itemCode from tb_itemCode order by itemCode desc";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                int id = int.Parse(reader[0].ToString()) + 1;
                regNumber1 = id.ToString("200");
            }
            else if (Convert.IsDBNull(reader))
            {
                regNumber1 = "201";
            }
            else
            {
                regNumber1 = "201";
            }
            connection.Close();

            txt_itemCode.Text = regNumber1.ToString();
        }

        //display data in item
        public void display1()
        {
            connection.Open();
            string query = "select * from tb_itemCode order by id;";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dg_itemView.DataSource = table;
            command.ExecuteNonQuery();
            connection.Close();
        }

        public void display2()
        {
            connection.Open();
            string query2 = "select taxId,taxName from tb_tax order by taxId;";
            SqlDataAdapter adapter = new SqlDataAdapter(query2, connection);
            DataSet table = new DataSet();
            adapter.Fill(table);
            cb_tax.DataSource = table.Tables[0];
            cb_tax.DisplayMember = "taxName";
            cb_tax.ValueMember = "taxId";
            connection.Close();
        }

        //clear data
        public void clear()
        {
            txt_itemName.Text = "";
            txt_hsnCode.Text = "";
            txt_unit.Text = "";
            cb_tax.Text = "";
            txt_taxValueItem.Text = "";
            txt_sellingPrice.Text = "";
        }

        private void dg_itemView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_itemCode.Text=dg_itemView.CurrentRow.Cells[1].Value.ToString();
            txt_itemName.Text = dg_itemView.CurrentRow.Cells[2].Value.ToString();
            txt_hsnCode.Text = dg_itemView.CurrentRow.Cells[3].Value.ToString();
            txt_unit.Text = dg_itemView.CurrentRow.Cells[4].Value.ToString();
            cb_tax.Text = dg_itemView.CurrentRow.Cells[5].Value.ToString();
            txt_taxValueItem.Text = dg_itemView.CurrentRow.Cells[6].Value.ToString();
            txt_sellingPrice.Text = dg_itemView.CurrentRow.Cells[7].Value.ToString();
        }


        //update data is item details.
        private void btn_edit1_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "update tb_itemCode set " +
                    "itemName=@itemName,hsnCode=@hsnCode,unit=@unit,tax=@tax,taxValue=@taxValue,sellingPrice=@sellingPrice where itemCode=@itemCode";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@itemCode", int.Parse(txt_itemCode.Text));
                cmd.Parameters.AddWithValue("@itemName", txt_itemName.Text);
                cmd.Parameters.AddWithValue("@hsnCode", int.Parse(txt_hsnCode.Text));
                cmd.Parameters.AddWithValue("@unit", txt_unit.Text);
                cmd.Parameters.AddWithValue("@tax", cb_tax.Text);
                cmd.Parameters.AddWithValue("@taxValue", txt_taxValueItem.Text);
                cmd.Parameters.AddWithValue("@sellingPrice", txt_sellingPrice.Text);
                cmd.ExecuteNonQuery();
                connection.Close();
                display1();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Update the data is successfully.");
        }



        //-------------------------------------------------------------------------------------------



        //Refresh Page in customer billing
        private void btn_newCustomer_Click(object sender, EventArgs e)
        {
            clearCustomer();
            generateCustomerId();
        }

        public void clearCustomer()
        {
            txt_customerId.Text = "";
            txt_customerName.Text = "";
            txt_email.Text = "";
            txt_mobile.Text = "";
            txt_phone.Text = "";
            txt_gstNo.Text = "";
            txt_state.Text = "";
            txt_stateCode.Text = "";
            txt_address.Text = "";
        }

        public void generateCustomerId()
        {
            connection.Open();
            string regNumber1;
            string query = "select customerId from tb_customerBilling order by customerId desc";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                int id = int.Parse(reader[0].ToString()) + 1;
                regNumber1 = id.ToString("300");
            }
            else if (Convert.IsDBNull(reader))
            {
                regNumber1 = "301";
            }
            else
            {
                regNumber1 = "301";
            }
            connection.Close();

            txt_customerId.Text = regNumber1.ToString();
        }

        //Insert data into customer billing
        private void btn_saveCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "insert into tb_customerBilling values" +
                    "(@customerId,@customerName,@email,@mobile,@state,@phone,@address,@gstNo,@stateCode)";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@customerId", int.Parse(txt_customerId.Text));
                cmd.Parameters.AddWithValue("@customerName", txt_customerName.Text);
                cmd.Parameters.AddWithValue("@email",txt_email.Text);
                cmd.Parameters.AddWithValue("@mobile", txt_mobile.Text);
                cmd.Parameters.AddWithValue("@state", txt_state.Text);
                cmd.Parameters.AddWithValue("@phone", txt_phone.Text);
                cmd.Parameters.AddWithValue("@address", txt_address.Text);
                cmd.Parameters.AddWithValue("@gstNo",txt_gstNo.Text);
                cmd.Parameters.AddWithValue("@stateCode", txt_stateCode.Text);
                cmd.ExecuteNonQuery();
                connection.Close();
                displaycustomerBilling();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Insert the data is successfully.");
        }

        //Show data in grid data view.
        public void displaycustomerBilling()
        {
            connection.Open();
            string query = "select * from tb_customerBilling order by id;";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dg_viewCustomer.DataSource = table;
            command.ExecuteNonQuery();
            connection.Close();
        }


        //update the details in customer billing
        private void btn_editCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "update tb_customerBilling set customerName=@customerName,email=@email,mobile=@mobile,state=@state,phone=@phone,address=@address,gstNo=@gstNo,stateCode=@stateCode" +
                    " where customerId=@customerId";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@customerId", int.Parse(txt_customerId.Text));
                cmd.Parameters.AddWithValue("@customerName", txt_customerName.Text);
                cmd.Parameters.AddWithValue("@email", txt_email.Text);
                cmd.Parameters.AddWithValue("@mobile", txt_mobile.Text);
                cmd.Parameters.AddWithValue("@state", txt_state.Text);
                cmd.Parameters.AddWithValue("@phone", txt_phone.Text);
                cmd.Parameters.AddWithValue("@address", txt_address.Text);
                cmd.Parameters.AddWithValue("@gstNo", txt_gstNo.Text);
                cmd.Parameters.AddWithValue("@stateCode", txt_stateCode.Text);
                cmd.ExecuteNonQuery();
                connection.Close();
                displaycustomerBilling();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Update the data is successfully.");
        }


        //Remove the data is customer billing
        private void btn_deleteCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "delete tb_customerBilling where customerId=@customerId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@customerId", int.Parse(txt_customerId.Text));
                command.ExecuteNonQuery();
                connection.Close();
                displaycustomerBilling();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Successfully Deleted");
        }


        //Exit page
        private void btn_logoutCustomer_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        private void dg_viewCustomer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_customerId.Text = dg_viewCustomer.CurrentRow.Cells[1].Value.ToString();
            txt_customerName.Text = dg_viewCustomer.CurrentRow.Cells[2].Value.ToString();
            txt_email.Text = dg_viewCustomer.CurrentRow.Cells[3].Value.ToString();
            txt_mobile.Text = dg_viewCustomer.CurrentRow.Cells[4].Value.ToString();
            txt_state.Text = dg_viewCustomer.CurrentRow.Cells[5].Value.ToString();
            txt_phone.Text = dg_viewCustomer.CurrentRow.Cells[6].Value.ToString();
            txt_address.Text = dg_viewCustomer.CurrentRow.Cells[7].Value.ToString();
            txt_gstNo.Text = dg_viewCustomer.CurrentRow.Cells[8].Value.ToString();
            txt_stateCode.Text = dg_viewCustomer.CurrentRow.Cells[9].Value.ToString();
        }

        //clear page in customer billing
        private void btn_clearCustomer_Click(object sender, EventArgs e)
        {
            txt_customerId.Text = "";
            txt_customerName.Text = "";
            txt_email.Text = "";
            txt_mobile.Text = "";
            txt_phone.Text = "";
            txt_gstNo.Text = "";
            txt_state.Text = "";
            txt_stateCode.Text = "";
            txt_address.Text = "";
        }



        //-------------------------------------------------------------------------------------------



        //Insert data in Financial
        private void btn_saveFinancial_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "insert into tb_financial values(@financialId,@financialYear)";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@financialId", int.Parse(txt_financialId.Text));
                cmd.Parameters.AddWithValue("@financialYear", int.Parse(txt_financialYear.Text));
                cmd.ExecuteNonQuery();
                connection.Close();
                displayFinancial();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Insert data is completed.");
        }


        //display show in financial.
        public void displayFinancial()
        {
            connection.Open();
            string query = "select * from tb_financial order by financial_id";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dg_financial.DataSource = table;
            command.ExecuteNonQuery();
            connection.Close();
        }
     

        //Exit pages.
        private void btn_logoutFinancial_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //clear page in financial
        private void btn_clearFinancial_Click(object sender, EventArgs e)
        {
            txt_financialId.Text = "";
            txt_financialYear.Text = "";
        }


        //edit data in financial
        private void btn_editFinancial_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query= "Update tb_financial set financial_year=@financial_year where financial_id=@financial_id";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@financial_id", int.Parse(txt_financialId.Text));
            cmd.Parameters.AddWithValue("@financial_year", int.Parse(txt_financialYear.Text));
            cmd.ExecuteNonQuery();
            connection.Close();
            displayFinancial();
            MessageBox.Show("Update the data is successfully.");
        }


        //delete data in financial
        private void btn_deleteFinancial_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "delete tb_financial where financial_id=@financial_id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@financial_id", int.Parse(txt_financialId.Text));
            command.ExecuteNonQuery();
            connection.Close();
            displayFinancial();
            MessageBox.Show("Delete the data is successfully.");
        }

        private void dg_financial_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_financialId.Text = dg_financial.CurrentRow.Cells[1].Value.ToString();
            txt_financialYear.Text = dg_financial.CurrentRow.Cells[2].Value.ToString();
        }



        //-------------------------------------------------------------------------------------------



        //Insert data in login
        private void btn_saveLogin_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "insert into tb_login values(@username,@password)";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@username", txt_userNameCreate.Text);
                cmd.Parameters.AddWithValue("@password", txt_passwordCreate.Text);
                cmd.ExecuteNonQuery();
                connection.Close();
                displayLogin();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Insert data is completed.");
        }

        //display data in login page
        public void displayLogin()
        {
            connection.Open();
            string query = "select * from tb_login";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dg_loginPage.DataSource = table;
            command.ExecuteNonQuery();
            connection.Close();
        }

        private void btn_editLogin_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "Update tb_login set password=@password where userName=@userName";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@userName", txt_userNameCreate.Text);
                cmd.Parameters.AddWithValue("@password", txt_passwordCreate.Text);
                cmd.ExecuteNonQuery();
                connection.Close();
                displayLogin();
                MessageBox.Show("Update the data is successfully.");
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_deleteLogin_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "delete  tb_login where userName=@userName";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@userName", txt_userNameCreate.Text);
                command.ExecuteNonQuery();
                connection.Close();
                displayLogin();
                MessageBox.Show("Delete the data is successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_clearLogin_Click(object sender, EventArgs e)
        {
            txt_userNameCreate.Text = "";
            txt_passwordCreate.Text = "";
        }

        private void btn_logoutLogin_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dg_loginPage_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_userNameCreate.Text = dg_loginPage.CurrentRow.Cells[1].Value.ToString();
            txt_passwordCreate.Text = dg_loginPage .CurrentRow.Cells[2].Value.ToString();
        }


        //-------------------------------------------------------------------------------------------
        private void btn_logoutInvoice_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txt_customerIdInvoice_TextChanged(object sender, EventArgs e)
        {

            try
            {
                connection.Open();
                string query = "select customername,email,mobile,state,phone,address,gstNo,stateCode from tb_customerBilling where customerId=@customerId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@customerId", txt_customerIdInvoice.Text);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    txt_customerNameInvoice.Text = reader["customername"].ToString();
                    txt_emailInvoice.Text = reader["email"].ToString();
                    txt_mobileInvoice.Text = reader["mobile"].ToString();
                    txt_stateInvoice.Text = reader["state"].ToString();
                    txt_phoneInvoice.Text = reader["phone"].ToString();
                    txt_addressInvoice.Text = reader["address"].ToString();
                    txt_gstNoInvoice.Text = reader["gstNo"].ToString();
                    txt_stateCodeInvoice.Text = reader["stateCode"].ToString();
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

            //Generate id in item invoice.
            public void generateNo()
            {
                try
                {
                    connection.Open();
                    string regNumber;
                    string query = "select billNo from tb_invoiceBills order by billNo desc";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        int id = int.Parse(reader[0].ToString()) + 1;
                        regNumber = id.ToString("100");
                    }
                    else if (Convert.IsDBNull(reader))
                    {
                        regNumber = "101";
                    }
                    else
                    {
                        regNumber = "101";
                    }
                    connection.Close();
                    txt_billNoInvoice.Text = regNumber;
                }
                catch (Exception ex)
                {

                }
            }

        private void btn_saveInvoice_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "insert into tb_invoiceBills values(@billNo,@billName,@customerId,@customerName,@email,@mobile,@phone,@state,@stateCode,@gstNo,@address)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@billNo", int.Parse(txt_billNoInvoice.Text));
                command.Parameters.AddWithValue("@billName", dtp_billDateInvoice.Text);
                command.Parameters.AddWithValue("@customerId", int.Parse(txt_customerIdInvoice.Text));
                command.Parameters.AddWithValue("@customerName", txt_customerNameInvoice.Text);
                command.Parameters.AddWithValue("@email", txt_emailInvoice.Text);
                command.Parameters.AddWithValue("@mobile", txt_mobileInvoice.Text);
                command.Parameters.AddWithValue("@phone", txt_phoneInvoice.Text);
                command.Parameters.AddWithValue("@state", txt_stateInvoice.Text);
                command.Parameters.AddWithValue("@stateCode", txt_stateCodeInvoice.Text);
                command.Parameters.AddWithValue("@gstNo", txt_gstNoInvoice.Text);
                command.Parameters.AddWithValue("@address", txt_addressInvoice.Text);
                command.ExecuteNonQuery();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Insert Data is completed.");
        }

        public void clearData3()
        {
            try
            {
                cb_salesType.Text = "";
                txt_billNoInvoice.Clear();
                dtp_billDateInvoice.Refresh();
                txt_customerIdInvoice.Clear();
                txt_customerNameInvoice.Clear();
                txt_emailInvoice.Clear();
                txt_mobileInvoice.Clear();
                txt_phoneInvoice.Clear();
                txt_stateInvoice.Clear();
                txt_stateCodeInvoice.Clear();
                txt_gstNoInvoice.Clear();
                txt_addressInvoice.Clear();

                txt_itemCodeInvoice.Clear();
                txt_itemNameInvoice.Clear();
                txt_quantityInvoice.Clear();
                txt_priceInvoice.Clear();
                txt_taxInvoiceBill.Clear();
                txt_discountInvoice.Clear();
                txt_totalTaxInvoice.Clear();
                txt_totalAmountInvoice.Clear();
                txt_grandTotalInvoice.Clear();
            }
            catch (Exception ex) { }
        }

        private void btn_clearInvoice_Click(object sender, EventArgs e)
        {
            try
            {
                cb_salesType.Text = "";
                txt_billNoInvoice.Clear();
                dtp_billDateInvoice.Refresh();
                txt_customerIdInvoice.Clear();
                txt_customerNameInvoice.Clear();
                txt_emailInvoice.Clear();
                txt_mobileInvoice.Clear();
                txt_phoneInvoice.Clear();
                txt_stateInvoice.Clear();
                txt_stateCodeInvoice.Clear();
                txt_gstNoInvoice.Clear();
                txt_addressInvoice.Clear();

                txt_itemCodeInvoice.Clear();
                txt_itemNameInvoice.Clear();
                txt_quantityInvoice.Clear();
                txt_priceInvoice.Clear();
                txt_taxInvoiceBill.Clear();
                txt_discountInvoice.Clear();
                txt_totalTaxInvoice.Clear();
                txt_totalAmountInvoice.Clear();
                txt_grandTotalInvoice.Clear();
            }
            catch (Exception ex) { }
        }

        private void btn_newInvoice_Click(object sender, EventArgs e)
        {
            try
            {
                cb_salesType.Text = "";
                txt_billNoInvoice.Clear();
                dtp_billDateInvoice.Refresh();
                txt_customerIdInvoice.Clear();
                txt_customerNameInvoice.Clear();
                txt_emailInvoice.Clear();
                txt_mobileInvoice.Clear();
                txt_phoneInvoice.Clear();
                txt_stateInvoice.Clear();
                txt_stateCodeInvoice.Clear();
                txt_gstNoInvoice.Clear();
                txt_addressInvoice.Clear();

                txt_itemCodeInvoice.Clear();
                txt_itemNameInvoice.Clear();
                txt_quantityInvoice.Clear();
                txt_priceInvoice.Clear();
                txt_taxInvoiceBill.Clear();
                txt_discountInvoice.Clear();
                txt_totalTaxInvoice.Clear();
                txt_totalAmountInvoice.Clear();
                txt_grandTotalInvoice.Clear();

                generateNo();
            }
            catch (Exception ex)
            {

            }
        }

        private void txt_itemCodeInvoice_TextChanged(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "select itemName,taxValue,sellingPrice from tb_itemCode where itemCode=@itemCode";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@itemCode", (txt_itemCodeInvoice.Text));
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    txt_itemNameInvoice.Text = reader["itemName"].ToString();
                    txt_taxInvoiceBill.Text = reader["taxValue"].ToString();
                    txt_priceInvoice.Text = reader["sellingPrice"].ToString();
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_addInvoice_Click(object sender, EventArgs e)
        {
            connection.Open();
            //insert data in item invoice.

            string query = "insert into tb_itemInvoice values" +
             "(@billNo,@itemCode,@itemName,@quantity,@price,@discount,@tax,@totalAmount)";

            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@billNo", int.Parse(txt_billNoInvoice.Text));
            command.Parameters.AddWithValue("@itemCode", txt_itemCodeInvoice.Text);
            command.Parameters.AddWithValue("@itemName", txt_itemNameInvoice.Text);
            command.Parameters.AddWithValue("@quantity", int.Parse(txt_quantityInvoice.Text));
            command.Parameters.AddWithValue("@price", int.Parse(txt_priceInvoice.Text));
            command.Parameters.AddWithValue("@discount", float.Parse(txt_discountInvoice.Text));
            command.Parameters.AddWithValue("@tax", int.Parse(txt_taxInvoiceBill.Text));
            command.Parameters.AddWithValue("@totalAmount", int.Parse(txt_totalAmountInvoice.Text));
            command.ExecuteNonQuery();
            display3();
            totalAdd();
            totalAmount();
            totalDiscount();
            connection.Close();
        }

        public void display3()
        {
            string query1 = "select id,itemName,quantity,price,discount,tax,totalAmount from tb_itemInvoice";
            SqlCommand cmd = new SqlCommand(query1, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dg_invoiceView1.DataSource = table;

        }

        //sum of tax in item INVOICE
        public void totalAdd()
        {
            string query = "select sum(tax) from tb_itemInvoice";
            SqlCommand command = new SqlCommand(query, connection);
            object result = command.ExecuteScalar();
            txt_totalTaxInvoice.Text = result.ToString();
        }

        //sum of Total amount in item INVOICE
        public void totalAmount()
        {
            string query = "select sum(totalAmount) from tb_itemInvoice";
            SqlCommand command = new SqlCommand(query, connection);
            object result = command.ExecuteScalar();
            txt_grandTotalInvoice.Text = result.ToString();
        }

        //sum of total Amount in Item Invoice.
        public void totalDiscount()
        {
            string query = "select sum(discount) from tb_itemInvoice";
            SqlCommand command = new SqlCommand(query, connection);
            object result = command.ExecuteScalar();
            txt_totalDiscountInvoice.Text = result.ToString();
        }

        private void txt_discountInvoice_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string calculation = cb_salesType.SelectedItem.ToString();
                if (calculation != null)
                {
                    if (calculation == "Exclusive")
                    {

                        connection.Open();
                        int a = Convert.ToInt32(txt_quantityInvoice.Text);
                        int b = Convert.ToInt32(txt_priceInvoice.Text);
                        int quantityAndPrice = (a * b);

                        double discount = double.Parse(txt_discountInvoice.Text);
                        double discountCalculation = discount / 100;

                        double productAndDiscount = quantityAndPrice * discountCalculation;

                        double gst = double.Parse(txt_taxInvoiceBill.Text);
                        double gstCalculation = gst / 100;

                        double productAndGst = quantityAndPrice * gstCalculation;

                        double totalDiscount = quantityAndPrice - productAndDiscount;

                        int totalAmount = ((int)(totalDiscount + productAndGst));
                        txt_totalAmountInvoice.Text = totalAmount.ToString();
                        connection.Close();

                    }
                    else if (calculation == "Inclusive")
                    {
                        int a1 = Convert.ToInt32(txt_quantityInvoice.Text);
                        int b1 = Convert.ToInt32(txt_priceInvoice.Text);
                        int quantityAndPrice1 = (a1 * b1);

                        double discount1 = double.Parse(txt_discountInvoice.Text);
                        double discountCalculation1 = discount1 / 100;

                        double productAndDiscount1 = quantityAndPrice1 * discountCalculation1;

                        double gst1 = double.Parse(txt_taxInvoiceBill.Text);
                        double gstCalculation1 = gst1 / (100 + gst1);

                        double productAndGst1 = quantityAndPrice1 * gstCalculation1;

                        double totalDiscount1 = quantityAndPrice1 - productAndDiscount1;

                        int totalAmount1 = ((int)(totalDiscount1 + productAndGst1));
                        txt_totalAmountInvoice.Text = totalAmount1.ToString();
                    }
                }
            }
            catch (Exception ex) { }
        }

        private void btn_deleteInvoice_Click(object sender, EventArgs e)
        {
            connection.Open();
            string Query = "delete tb_invoiceBills where billNo=@billNo";
            SqlCommand cmd = new SqlCommand(Query, connection);
            cmd.Parameters.AddWithValue("@billNo", int.Parse(txt_billNoInvoice.Text));
            cmd.ExecuteNonQuery();
            deleteDataInvoice();
            display();
            connection.Close();
            MessageBox.Show("Delete data in successfully.");
        }

        public void deleteDataInvoice()
        {
            string query1 = "delete tb_itemInvoice where billNo=@billNo";
            SqlCommand command = new SqlCommand(query1, connection);
            command.Parameters.AddWithValue("@billNo", int.Parse(txt_billNoInvoice.Text));
            command.ExecuteNonQuery();
        }

        private void btn_editInvoice_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "update tb_invoiceBills set billDate=@billDate,customerName=@customerName,email=@email,mobile=@mobile,state=@state,phone=@phone,address=@address,gstNo=@gstNo,stateCode=@stateCode where billNo=@billNo";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@billNo", int.Parse(txt_billNoInvoice.Text));
            cmd.Parameters.AddWithValue("@billDate", dtp_billDateInvoice.Text);
            cmd.Parameters.AddWithValue("@customerName", txt_customerNameInvoice.Text);
            cmd.Parameters.AddWithValue("@email", txt_emailInvoice.Text);
            cmd.Parameters.AddWithValue("@mobile", txt_mobileInvoice.Text);
            cmd.Parameters.AddWithValue("@state", txt_stateInvoice.Text);
            cmd.Parameters.AddWithValue("@phone", txt_phoneInvoice.Text);
            cmd.Parameters.AddWithValue("@address", txt_addressInvoice.Text);
            cmd.Parameters.AddWithValue("@gstNo", txt_gstNoInvoice.Text);
            cmd.Parameters.AddWithValue("@stateCode", txt_stateCodeInvoice.Text);
            cmd.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Update Data is completed.");
        }

        private void btn_refreshInvoice_Click(object sender, EventArgs e)
        {
            try
            {
                txt_itemCodeInvoice.Clear();
                txt_itemNameInvoice.Clear();
                txt_quantityInvoice.Clear();
                txt_priceInvoice.Clear();
                txt_discountInvoice.Clear();
                txt_totalTaxInvoice.Clear();
                txt_totalAmountInvoice.Clear();
                txt_grandTotalInvoice.Clear();
            }
            catch (Exception ex) { }
        }

    }
}
