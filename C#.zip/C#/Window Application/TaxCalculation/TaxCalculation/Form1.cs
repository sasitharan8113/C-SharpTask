﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TaxCalculation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //login button
        private void btn_submit_Click(object sender, EventArgs e)
        {

            SqlConnection connection = new SqlConnection(@"Data Source=localhost;Initial Catalog=dbBank;Integrated Security=True");
            connection.Open();
            string query =
            "select * from tb_login where username='" + txt_userName.Text + "' and password='" + txt_password.Text + "'";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                MessageBox.Show("Login successful!");
                Form2 form = new Form2();
                form.Show();
            }
            else
            {
                MessageBox.Show("Login failed. Please check your username and password.");
            }
            connection.Close();
        }

        //Login text box in clear.
        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_userName.Text = "";
            txt_password.Text = "";
        }

        //Login page in Exit.
        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
