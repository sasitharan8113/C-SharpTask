﻿namespace TaxCalculation
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tc_invoiceBills = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_new = new System.Windows.Forms.Button();
            this.dg_view = new System.Windows.Forms.DataGridView();
            this.btn_logout = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_edit = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.txt_taxValue = new System.Windows.Forms.TextBox();
            this.lbl_txtValue = new System.Windows.Forms.Label();
            this.txt_taxName = new System.Windows.Forms.TextBox();
            this.lbl_taxName = new System.Windows.Forms.Label();
            this.txt_taxId = new System.Windows.Forms.TextBox();
            this.lbl_tax = new System.Windows.Forms.Label();
            this.lbl_taxId = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txt_taxValueItem = new System.Windows.Forms.TextBox();
            this.lbl_taxValueItem = new System.Windows.Forms.Label();
            this.dg_itemView = new System.Windows.Forms.DataGridView();
            this.btn_logout1 = new System.Windows.Forms.Button();
            this.btn_clear1 = new System.Windows.Forms.Button();
            this.btn_delete1 = new System.Windows.Forms.Button();
            this.btn_edit1 = new System.Windows.Forms.Button();
            this.btn_save1 = new System.Windows.Forms.Button();
            this.btn_new1 = new System.Windows.Forms.Button();
            this.txt_sellingPrice = new System.Windows.Forms.TextBox();
            this.lbl_sellingPrice = new System.Windows.Forms.Label();
            this.cb_tax = new System.Windows.Forms.ComboBox();
            this.tbtaxBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbBankDataSet = new TaxCalculation.dbBankDataSet();
            this.txt_tax = new System.Windows.Forms.Label();
            this.txt_unit = new System.Windows.Forms.TextBox();
            this.lbl_unit = new System.Windows.Forms.Label();
            this.txt_hsnCode = new System.Windows.Forms.TextBox();
            this.lbl_hsnCode = new System.Windows.Forms.Label();
            this.txt_itemName = new System.Windows.Forms.TextBox();
            this.lbl_itemName = new System.Windows.Forms.Label();
            this.txt_itemCode = new System.Windows.Forms.TextBox();
            this.lbl_itemCode = new System.Windows.Forms.Label();
            this.lbl_itemDetails = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dg_viewCustomer = new System.Windows.Forms.DataGridView();
            this.btn_logoutCustomer = new System.Windows.Forms.Button();
            this.btn_clearCustomer = new System.Windows.Forms.Button();
            this.btn_deleteCustomer = new System.Windows.Forms.Button();
            this.btn_editCustomer = new System.Windows.Forms.Button();
            this.btn_saveCustomer = new System.Windows.Forms.Button();
            this.btn_newCustomer = new System.Windows.Forms.Button();
            this.txt_stateCode = new System.Windows.Forms.TextBox();
            this.lbl_stateCode = new System.Windows.Forms.Label();
            this.txt_state = new System.Windows.Forms.TextBox();
            this.lbl_state = new System.Windows.Forms.Label();
            this.txt_gstNo = new System.Windows.Forms.TextBox();
            this.lbl_gstNo = new System.Windows.Forms.Label();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.lbl_email = new System.Windows.Forms.Label();
            this.txt_phone = new System.Windows.Forms.TextBox();
            this.lbl_phone = new System.Windows.Forms.Label();
            this.txt_mobile = new System.Windows.Forms.TextBox();
            this.lbl_mobile = new System.Windows.Forms.Label();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.lbl_address = new System.Windows.Forms.Label();
            this.txt_customerName = new System.Windows.Forms.TextBox();
            this.lbl_customerName = new System.Windows.Forms.Label();
            this.txt_customerId = new System.Windows.Forms.TextBox();
            this.lbl_customerId = new System.Windows.Forms.Label();
            this.lbl_customerBilling = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dg_financial = new System.Windows.Forms.DataGridView();
            this.btn_logoutFinancial = new System.Windows.Forms.Button();
            this.btn_clearFinancial = new System.Windows.Forms.Button();
            this.btn_deleteFinancial = new System.Windows.Forms.Button();
            this.btn_saveFinancial = new System.Windows.Forms.Button();
            this.btn_editFinancial = new System.Windows.Forms.Button();
            this.txt_financialYear = new System.Windows.Forms.TextBox();
            this.lbl_financialYear = new System.Windows.Forms.Label();
            this.txt_financialId = new System.Windows.Forms.TextBox();
            this.lbl_financialId = new System.Windows.Forms.Label();
            this.lbl_financial = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dg_loginPage = new System.Windows.Forms.DataGridView();
            this.btn_logoutLogin = new System.Windows.Forms.Button();
            this.btn_clearLogin = new System.Windows.Forms.Button();
            this.btn_deleteLogin = new System.Windows.Forms.Button();
            this.btn_editLogin = new System.Windows.Forms.Button();
            this.btn_saveLogin = new System.Windows.Forms.Button();
            this.txt_passwordCreate = new System.Windows.Forms.TextBox();
            this.lbl_passwordCreate = new System.Windows.Forms.Label();
            this.txt_userNameCreate = new System.Windows.Forms.TextBox();
            this.lbl_userNameCreate = new System.Windows.Forms.Label();
            this.lbl_loginCreate = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dg_invoiceView1 = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Discount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TaxValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Edit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btn_logoutInvoice = new System.Windows.Forms.Button();
            this.btn_clearInvoice = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_deleteInvoice = new System.Windows.Forms.Button();
            this.btn_editInvoice = new System.Windows.Forms.Button();
            this.btn_saveInvoice = new System.Windows.Forms.Button();
            this.btn_newInvoice = new System.Windows.Forms.Button();
            this.txt_grandTotalInvoice = new System.Windows.Forms.TextBox();
            this.lbl_grandTotalAmount = new System.Windows.Forms.Label();
            this.txt_totalDiscountInvoice = new System.Windows.Forms.TextBox();
            this.lbl_totalDiscount = new System.Windows.Forms.Label();
            this.txt_totalTaxInvoice = new System.Windows.Forms.TextBox();
            this.lbl_totalGstInvoice = new System.Windows.Forms.Label();
            this.pn_itemDetails = new System.Windows.Forms.Panel();
            this.lbl_taxInvoice = new System.Windows.Forms.Label();
            this.txt_taxInvoiceBill = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_itemCodeInvoice = new System.Windows.Forms.TextBox();
            this.lbl_itemDescription = new System.Windows.Forms.Label();
            this.txt_itemNameInvoice = new System.Windows.Forms.TextBox();
            this.lbl_quantityInvoice = new System.Windows.Forms.Label();
            this.txt_quantityInvoice = new System.Windows.Forms.TextBox();
            this.lbl_discountInvoice = new System.Windows.Forms.Label();
            this.lbl_totalInvoice = new System.Windows.Forms.Label();
            this.txt_discountInvoice = new System.Windows.Forms.TextBox();
            this.lbl_priceInvoice = new System.Windows.Forms.Label();
            this.txt_priceInvoice = new System.Windows.Forms.TextBox();
            this.txt_totalAmountInvoice = new System.Windows.Forms.TextBox();
            this.btn_refreshInvoice = new System.Windows.Forms.Button();
            this.btn_addInvoice = new System.Windows.Forms.Button();
            this.txt_stateCodeInvoice = new System.Windows.Forms.TextBox();
            this.lbl_stateCodeInvoice = new System.Windows.Forms.Label();
            this.txt_stateInvoice = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_phoneInvoice = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_emailInvoice = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_gstNoInvoice = new System.Windows.Forms.TextBox();
            this.txt_addressInvoice = new System.Windows.Forms.TextBox();
            this.lbl_gstNoInvoice = new System.Windows.Forms.Label();
            this.txt_customerNameInvoice = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_mobileInvoice = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_customerIdInvoice = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtp_billDateInvoice = new System.Windows.Forms.DateTimePicker();
            this.lbl_billDate = new System.Windows.Forms.Label();
            this.txt_billNoInvoice = new System.Windows.Forms.TextBox();
            this.lbl_billNo = new System.Windows.Forms.Label();
            this.cb_salesType = new System.Windows.Forms.ComboBox();
            this.lbl_salesType = new System.Windows.Forms.Label();
            this.lbl_invoice = new System.Windows.Forms.Label();
            this.dbBankDataSet1 = new TaxCalculation.dbBankDataSet1();
            this.dbBankDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_taxTableAdapter = new TaxCalculation.dbBankDataSetTableAdapters.tb_taxTableAdapter();
            this.tc_invoiceBills.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_view)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_itemView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbtaxBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbBankDataSet)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_viewCustomer)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_financial)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_loginPage)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_invoiceView1)).BeginInit();
            this.pn_itemDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dbBankDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbBankDataSet1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tc_invoiceBills
            // 
            this.tc_invoiceBills.Controls.Add(this.tabPage1);
            this.tc_invoiceBills.Controls.Add(this.tabPage2);
            this.tc_invoiceBills.Controls.Add(this.tabPage3);
            this.tc_invoiceBills.Controls.Add(this.tabPage4);
            this.tc_invoiceBills.Controls.Add(this.tabPage5);
            this.tc_invoiceBills.Controls.Add(this.tabPage6);
            this.tc_invoiceBills.Location = new System.Drawing.Point(7, 30);
            this.tc_invoiceBills.Name = "tc_invoiceBills";
            this.tc_invoiceBills.SelectedIndex = 0;
            this.tc_invoiceBills.Size = new System.Drawing.Size(1691, 806);
            this.tc_invoiceBills.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btn_new);
            this.tabPage1.Controls.Add(this.dg_view);
            this.tabPage1.Controls.Add(this.btn_logout);
            this.tabPage1.Controls.Add(this.btn_delete);
            this.tabPage1.Controls.Add(this.btn_clear);
            this.tabPage1.Controls.Add(this.btn_edit);
            this.tabPage1.Controls.Add(this.btn_save);
            this.tabPage1.Controls.Add(this.txt_taxValue);
            this.tabPage1.Controls.Add(this.lbl_txtValue);
            this.tabPage1.Controls.Add(this.txt_taxName);
            this.tabPage1.Controls.Add(this.lbl_taxName);
            this.tabPage1.Controls.Add(this.txt_taxId);
            this.tabPage1.Controls.Add(this.lbl_tax);
            this.tabPage1.Controls.Add(this.lbl_taxId);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1683, 773);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tax Calculation";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btn_new
            // 
            this.btn_new.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_new.Location = new System.Drawing.Point(195, 282);
            this.btn_new.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(141, 46);
            this.btn_new.TabIndex = 37;
            this.btn_new.Text = "New";
            this.btn_new.UseVisualStyleBackColor = true;
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // dg_view
            // 
            this.dg_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_view.Location = new System.Drawing.Point(215, 386);
            this.dg_view.Name = "dg_view";
            this.dg_view.RowHeadersWidth = 62;
            this.dg_view.RowTemplate.Height = 28;
            this.dg_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_view.Size = new System.Drawing.Size(716, 201);
            this.dg_view.TabIndex = 36;
            this.dg_view.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_view_CellContentClick);
            // 
            // btn_logout
            // 
            this.btn_logout.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.Location = new System.Drawing.Point(493, 334);
            this.btn_logout.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(141, 46);
            this.btn_logout.TabIndex = 35;
            this.btn_logout.Text = "Logout";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(642, 282);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(141, 46);
            this.btn_delete.TabIndex = 34;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.Location = new System.Drawing.Point(791, 282);
            this.btn_clear.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(141, 46);
            this.btn_clear.TabIndex = 33;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_edit
            // 
            this.btn_edit.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_edit.Location = new System.Drawing.Point(493, 282);
            this.btn_edit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(141, 46);
            this.btn_edit.TabIndex = 32;
            this.btn_edit.Text = "Edit";
            this.btn_edit.UseVisualStyleBackColor = true;
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Location = new System.Drawing.Point(344, 282);
            this.btn_save.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(141, 46);
            this.btn_save.TabIndex = 31;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // txt_taxValue
            // 
            this.txt_taxValue.Location = new System.Drawing.Point(513, 220);
            this.txt_taxValue.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_taxValue.Name = "txt_taxValue";
            this.txt_taxValue.Size = new System.Drawing.Size(223, 26);
            this.txt_taxValue.TabIndex = 30;
            // 
            // lbl_txtValue
            // 
            this.lbl_txtValue.AutoSize = true;
            this.lbl_txtValue.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_txtValue.Location = new System.Drawing.Point(303, 213);
            this.lbl_txtValue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_txtValue.Name = "lbl_txtValue";
            this.lbl_txtValue.Size = new System.Drawing.Size(132, 33);
            this.lbl_txtValue.TabIndex = 29;
            this.lbl_txtValue.Text = "Tax Value:";
            // 
            // txt_taxName
            // 
            this.txt_taxName.Location = new System.Drawing.Point(513, 148);
            this.txt_taxName.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_taxName.Name = "txt_taxName";
            this.txt_taxName.Size = new System.Drawing.Size(223, 26);
            this.txt_taxName.TabIndex = 28;
            // 
            // lbl_taxName
            // 
            this.lbl_taxName.AutoSize = true;
            this.lbl_taxName.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_taxName.Location = new System.Drawing.Point(303, 141);
            this.lbl_taxName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_taxName.Name = "lbl_taxName";
            this.lbl_taxName.Size = new System.Drawing.Size(134, 33);
            this.lbl_taxName.TabIndex = 27;
            this.lbl_taxName.Text = "Tax Name:";
            // 
            // txt_taxId
            // 
            this.txt_taxId.Location = new System.Drawing.Point(513, 69);
            this.txt_taxId.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_taxId.Name = "txt_taxId";
            this.txt_taxId.Size = new System.Drawing.Size(223, 26);
            this.txt_taxId.TabIndex = 26;
            // 
            // lbl_tax
            // 
            this.lbl_tax.AutoSize = true;
            this.lbl_tax.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tax.Location = new System.Drawing.Point(434, 16);
            this.lbl_tax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_tax.Name = "lbl_tax";
            this.lbl_tax.Size = new System.Drawing.Size(232, 36);
            this.lbl_tax.TabIndex = 24;
            this.lbl_tax.Text = "Tax Calculation";
            // 
            // lbl_taxId
            // 
            this.lbl_taxId.AutoSize = true;
            this.lbl_taxId.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_taxId.Location = new System.Drawing.Point(303, 62);
            this.lbl_taxId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_taxId.Name = "lbl_taxId";
            this.lbl_taxId.Size = new System.Drawing.Size(92, 33);
            this.lbl_taxId.TabIndex = 25;
            this.lbl_taxId.Text = "Tax Id:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.txt_taxValueItem);
            this.tabPage2.Controls.Add(this.lbl_taxValueItem);
            this.tabPage2.Controls.Add(this.dg_itemView);
            this.tabPage2.Controls.Add(this.btn_logout1);
            this.tabPage2.Controls.Add(this.btn_clear1);
            this.tabPage2.Controls.Add(this.btn_delete1);
            this.tabPage2.Controls.Add(this.btn_edit1);
            this.tabPage2.Controls.Add(this.btn_save1);
            this.tabPage2.Controls.Add(this.btn_new1);
            this.tabPage2.Controls.Add(this.txt_sellingPrice);
            this.tabPage2.Controls.Add(this.lbl_sellingPrice);
            this.tabPage2.Controls.Add(this.cb_tax);
            this.tabPage2.Controls.Add(this.txt_tax);
            this.tabPage2.Controls.Add(this.txt_unit);
            this.tabPage2.Controls.Add(this.lbl_unit);
            this.tabPage2.Controls.Add(this.txt_hsnCode);
            this.tabPage2.Controls.Add(this.lbl_hsnCode);
            this.tabPage2.Controls.Add(this.txt_itemName);
            this.tabPage2.Controls.Add(this.lbl_itemName);
            this.tabPage2.Controls.Add(this.txt_itemCode);
            this.tabPage2.Controls.Add(this.lbl_itemCode);
            this.tabPage2.Controls.Add(this.lbl_itemDetails);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1683, 773);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "item Details";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // txt_taxValueItem
            // 
            this.txt_taxValueItem.Location = new System.Drawing.Point(261, 299);
            this.txt_taxValueItem.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_taxValueItem.Name = "txt_taxValueItem";
            this.txt_taxValueItem.Size = new System.Drawing.Size(223, 26);
            this.txt_taxValueItem.TabIndex = 46;
            // 
            // lbl_taxValueItem
            // 
            this.lbl_taxValueItem.AutoSize = true;
            this.lbl_taxValueItem.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_taxValueItem.Location = new System.Drawing.Point(55, 292);
            this.lbl_taxValueItem.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_taxValueItem.Name = "lbl_taxValueItem";
            this.lbl_taxValueItem.Size = new System.Drawing.Size(132, 33);
            this.lbl_taxValueItem.TabIndex = 45;
            this.lbl_taxValueItem.Text = "Tax Value:";
            // 
            // dg_itemView
            // 
            this.dg_itemView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_itemView.Location = new System.Drawing.Point(28, 422);
            this.dg_itemView.Name = "dg_itemView";
            this.dg_itemView.RowHeadersWidth = 62;
            this.dg_itemView.RowTemplate.Height = 28;
            this.dg_itemView.Size = new System.Drawing.Size(1098, 167);
            this.dg_itemView.TabIndex = 44;
            this.dg_itemView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_itemView_CellContentClick);
            // 
            // btn_logout1
            // 
            this.btn_logout1.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout1.Location = new System.Drawing.Point(847, 350);
            this.btn_logout1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_logout1.Name = "btn_logout1";
            this.btn_logout1.Size = new System.Drawing.Size(141, 46);
            this.btn_logout1.TabIndex = 43;
            this.btn_logout1.Text = "Logout";
            this.btn_logout1.UseVisualStyleBackColor = true;
            this.btn_logout1.Click += new System.EventHandler(this.btn_logout1_Click);
            // 
            // btn_clear1
            // 
            this.btn_clear1.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear1.Location = new System.Drawing.Point(698, 350);
            this.btn_clear1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_clear1.Name = "btn_clear1";
            this.btn_clear1.Size = new System.Drawing.Size(141, 46);
            this.btn_clear1.TabIndex = 42;
            this.btn_clear1.Text = "Clear";
            this.btn_clear1.UseVisualStyleBackColor = true;
            this.btn_clear1.Click += new System.EventHandler(this.btn_clear1_Click);
            // 
            // btn_delete1
            // 
            this.btn_delete1.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete1.Location = new System.Drawing.Point(549, 350);
            this.btn_delete1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_delete1.Name = "btn_delete1";
            this.btn_delete1.Size = new System.Drawing.Size(141, 46);
            this.btn_delete1.TabIndex = 41;
            this.btn_delete1.Text = "Delete";
            this.btn_delete1.UseVisualStyleBackColor = true;
            this.btn_delete1.Click += new System.EventHandler(this.btn_delete1_Click);
            // 
            // btn_edit1
            // 
            this.btn_edit1.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_edit1.Location = new System.Drawing.Point(400, 350);
            this.btn_edit1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_edit1.Name = "btn_edit1";
            this.btn_edit1.Size = new System.Drawing.Size(141, 46);
            this.btn_edit1.TabIndex = 40;
            this.btn_edit1.Text = "Edit";
            this.btn_edit1.UseVisualStyleBackColor = true;
            this.btn_edit1.Click += new System.EventHandler(this.btn_edit1_Click);
            // 
            // btn_save1
            // 
            this.btn_save1.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save1.Location = new System.Drawing.Point(251, 350);
            this.btn_save1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_save1.Name = "btn_save1";
            this.btn_save1.Size = new System.Drawing.Size(141, 46);
            this.btn_save1.TabIndex = 39;
            this.btn_save1.Text = "Save";
            this.btn_save1.UseVisualStyleBackColor = true;
            this.btn_save1.Click += new System.EventHandler(this.btn_save1_Click);
            // 
            // btn_new1
            // 
            this.btn_new1.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_new1.Location = new System.Drawing.Point(102, 350);
            this.btn_new1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_new1.Name = "btn_new1";
            this.btn_new1.Size = new System.Drawing.Size(141, 46);
            this.btn_new1.TabIndex = 38;
            this.btn_new1.Text = "New";
            this.btn_new1.UseVisualStyleBackColor = true;
            this.btn_new1.Click += new System.EventHandler(this.btn_new1_Click);
            // 
            // txt_sellingPrice
            // 
            this.txt_sellingPrice.Location = new System.Drawing.Point(799, 225);
            this.txt_sellingPrice.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_sellingPrice.Name = "txt_sellingPrice";
            this.txt_sellingPrice.Size = new System.Drawing.Size(223, 26);
            this.txt_sellingPrice.TabIndex = 37;
            // 
            // lbl_sellingPrice
            // 
            this.lbl_sellingPrice.AutoSize = true;
            this.lbl_sellingPrice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sellingPrice.Location = new System.Drawing.Point(581, 218);
            this.lbl_sellingPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_sellingPrice.Name = "lbl_sellingPrice";
            this.lbl_sellingPrice.Size = new System.Drawing.Size(166, 33);
            this.lbl_sellingPrice.TabIndex = 36;
            this.lbl_sellingPrice.Text = "Selling Price:";
            // 
            // cb_tax
            // 
            this.cb_tax.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tbtaxBindingSource, "taxId", true));
            this.cb_tax.DataSource = this.tbtaxBindingSource;
            this.cb_tax.DisplayMember = "taxName";
            this.cb_tax.FormattingEnabled = true;
            this.cb_tax.Location = new System.Drawing.Point(261, 225);
            this.cb_tax.Name = "cb_tax";
            this.cb_tax.Size = new System.Drawing.Size(222, 28);
            this.cb_tax.TabIndex = 35;
            this.cb_tax.ValueMember = "taxId";
            // 
            // tbtaxBindingSource
            // 
            this.tbtaxBindingSource.DataMember = "tb_tax";
            this.tbtaxBindingSource.DataSource = this.dbBankDataSet;
            // 
            // dbBankDataSet
            // 
            this.dbBankDataSet.DataSetName = "dbBankDataSet";
            this.dbBankDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txt_tax
            // 
            this.txt_tax.AutoSize = true;
            this.txt_tax.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tax.Location = new System.Drawing.Point(55, 218);
            this.txt_tax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txt_tax.Name = "txt_tax";
            this.txt_tax.Size = new System.Drawing.Size(134, 33);
            this.txt_tax.TabIndex = 34;
            this.txt_tax.Text = "Tax Name:";
            // 
            // txt_unit
            // 
            this.txt_unit.Location = new System.Drawing.Point(799, 151);
            this.txt_unit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_unit.Name = "txt_unit";
            this.txt_unit.Size = new System.Drawing.Size(223, 26);
            this.txt_unit.TabIndex = 33;
            // 
            // lbl_unit
            // 
            this.lbl_unit.AutoSize = true;
            this.lbl_unit.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_unit.Location = new System.Drawing.Point(581, 144);
            this.lbl_unit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_unit.Name = "lbl_unit";
            this.lbl_unit.Size = new System.Drawing.Size(72, 33);
            this.lbl_unit.TabIndex = 32;
            this.lbl_unit.Text = "Unit:";
            // 
            // txt_hsnCode
            // 
            this.txt_hsnCode.Location = new System.Drawing.Point(260, 151);
            this.txt_hsnCode.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_hsnCode.Name = "txt_hsnCode";
            this.txt_hsnCode.Size = new System.Drawing.Size(223, 26);
            this.txt_hsnCode.TabIndex = 31;
            // 
            // lbl_hsnCode
            // 
            this.lbl_hsnCode.AutoSize = true;
            this.lbl_hsnCode.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hsnCode.Location = new System.Drawing.Point(55, 144);
            this.lbl_hsnCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_hsnCode.Name = "lbl_hsnCode";
            this.lbl_hsnCode.Size = new System.Drawing.Size(144, 33);
            this.lbl_hsnCode.TabIndex = 30;
            this.lbl_hsnCode.Text = "HSN Code:";
            // 
            // txt_itemName
            // 
            this.txt_itemName.Location = new System.Drawing.Point(799, 92);
            this.txt_itemName.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_itemName.Name = "txt_itemName";
            this.txt_itemName.Size = new System.Drawing.Size(223, 26);
            this.txt_itemName.TabIndex = 29;
            // 
            // lbl_itemName
            // 
            this.lbl_itemName.AutoSize = true;
            this.lbl_itemName.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemName.Location = new System.Drawing.Point(581, 77);
            this.lbl_itemName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_itemName.Name = "lbl_itemName";
            this.lbl_itemName.Size = new System.Drawing.Size(142, 33);
            this.lbl_itemName.TabIndex = 28;
            this.lbl_itemName.Text = "Item Name:";
            // 
            // txt_itemCode
            // 
            this.txt_itemCode.Location = new System.Drawing.Point(260, 77);
            this.txt_itemCode.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_itemCode.Name = "txt_itemCode";
            this.txt_itemCode.Size = new System.Drawing.Size(223, 26);
            this.txt_itemCode.TabIndex = 27;
            // 
            // lbl_itemCode
            // 
            this.lbl_itemCode.AutoSize = true;
            this.lbl_itemCode.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemCode.Location = new System.Drawing.Point(55, 70);
            this.lbl_itemCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_itemCode.Name = "lbl_itemCode";
            this.lbl_itemCode.Size = new System.Drawing.Size(137, 33);
            this.lbl_itemCode.TabIndex = 26;
            this.lbl_itemCode.Text = "Item Code:";
            // 
            // lbl_itemDetails
            // 
            this.lbl_itemDetails.AutoSize = true;
            this.lbl_itemDetails.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemDetails.Location = new System.Drawing.Point(450, 22);
            this.lbl_itemDetails.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_itemDetails.Name = "lbl_itemDetails";
            this.lbl_itemDetails.Size = new System.Drawing.Size(180, 36);
            this.lbl_itemDetails.TabIndex = 25;
            this.lbl_itemDetails.Text = "Item Details";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dg_viewCustomer);
            this.tabPage3.Controls.Add(this.btn_logoutCustomer);
            this.tabPage3.Controls.Add(this.btn_clearCustomer);
            this.tabPage3.Controls.Add(this.btn_deleteCustomer);
            this.tabPage3.Controls.Add(this.btn_editCustomer);
            this.tabPage3.Controls.Add(this.btn_saveCustomer);
            this.tabPage3.Controls.Add(this.btn_newCustomer);
            this.tabPage3.Controls.Add(this.txt_stateCode);
            this.tabPage3.Controls.Add(this.lbl_stateCode);
            this.tabPage3.Controls.Add(this.txt_state);
            this.tabPage3.Controls.Add(this.lbl_state);
            this.tabPage3.Controls.Add(this.txt_gstNo);
            this.tabPage3.Controls.Add(this.lbl_gstNo);
            this.tabPage3.Controls.Add(this.txt_email);
            this.tabPage3.Controls.Add(this.lbl_email);
            this.tabPage3.Controls.Add(this.txt_phone);
            this.tabPage3.Controls.Add(this.lbl_phone);
            this.tabPage3.Controls.Add(this.txt_mobile);
            this.tabPage3.Controls.Add(this.lbl_mobile);
            this.tabPage3.Controls.Add(this.txt_address);
            this.tabPage3.Controls.Add(this.lbl_address);
            this.tabPage3.Controls.Add(this.txt_customerName);
            this.tabPage3.Controls.Add(this.lbl_customerName);
            this.tabPage3.Controls.Add(this.txt_customerId);
            this.tabPage3.Controls.Add(this.lbl_customerId);
            this.tabPage3.Controls.Add(this.lbl_customerBilling);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1683, 773);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "CustomerBilling";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dg_viewCustomer
            // 
            this.dg_viewCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_viewCustomer.Location = new System.Drawing.Point(29, 438);
            this.dg_viewCustomer.Name = "dg_viewCustomer";
            this.dg_viewCustomer.RowHeadersWidth = 62;
            this.dg_viewCustomer.RowTemplate.Height = 28;
            this.dg_viewCustomer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_viewCustomer.Size = new System.Drawing.Size(1105, 166);
            this.dg_viewCustomer.TabIndex = 52;
            this.dg_viewCustomer.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_viewCustomer_CellContentClick);
            // 
            // btn_logoutCustomer
            // 
            this.btn_logoutCustomer.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logoutCustomer.Location = new System.Drawing.Point(869, 372);
            this.btn_logoutCustomer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_logoutCustomer.Name = "btn_logoutCustomer";
            this.btn_logoutCustomer.Size = new System.Drawing.Size(141, 46);
            this.btn_logoutCustomer.TabIndex = 50;
            this.btn_logoutCustomer.Text = "Logout";
            this.btn_logoutCustomer.UseVisualStyleBackColor = true;
            this.btn_logoutCustomer.Click += new System.EventHandler(this.btn_logoutCustomer_Click);
            // 
            // btn_clearCustomer
            // 
            this.btn_clearCustomer.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clearCustomer.Location = new System.Drawing.Point(709, 372);
            this.btn_clearCustomer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_clearCustomer.Name = "btn_clearCustomer";
            this.btn_clearCustomer.Size = new System.Drawing.Size(141, 46);
            this.btn_clearCustomer.TabIndex = 49;
            this.btn_clearCustomer.Text = "Clear";
            this.btn_clearCustomer.UseVisualStyleBackColor = true;
            this.btn_clearCustomer.Click += new System.EventHandler(this.btn_clearCustomer_Click);
            // 
            // btn_deleteCustomer
            // 
            this.btn_deleteCustomer.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deleteCustomer.Location = new System.Drawing.Point(541, 372);
            this.btn_deleteCustomer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_deleteCustomer.Name = "btn_deleteCustomer";
            this.btn_deleteCustomer.Size = new System.Drawing.Size(141, 46);
            this.btn_deleteCustomer.TabIndex = 48;
            this.btn_deleteCustomer.Text = "Delete";
            this.btn_deleteCustomer.UseVisualStyleBackColor = true;
            this.btn_deleteCustomer.Click += new System.EventHandler(this.btn_deleteCustomer_Click);
            // 
            // btn_editCustomer
            // 
            this.btn_editCustomer.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_editCustomer.Location = new System.Drawing.Point(378, 372);
            this.btn_editCustomer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_editCustomer.Name = "btn_editCustomer";
            this.btn_editCustomer.Size = new System.Drawing.Size(141, 46);
            this.btn_editCustomer.TabIndex = 47;
            this.btn_editCustomer.Text = "Edit";
            this.btn_editCustomer.UseVisualStyleBackColor = true;
            this.btn_editCustomer.Click += new System.EventHandler(this.btn_editCustomer_Click);
            // 
            // btn_saveCustomer
            // 
            this.btn_saveCustomer.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_saveCustomer.Location = new System.Drawing.Point(217, 372);
            this.btn_saveCustomer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_saveCustomer.Name = "btn_saveCustomer";
            this.btn_saveCustomer.Size = new System.Drawing.Size(141, 46);
            this.btn_saveCustomer.TabIndex = 46;
            this.btn_saveCustomer.Text = "Save";
            this.btn_saveCustomer.UseVisualStyleBackColor = true;
            this.btn_saveCustomer.Click += new System.EventHandler(this.btn_saveCustomer_Click);
            // 
            // btn_newCustomer
            // 
            this.btn_newCustomer.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newCustomer.Location = new System.Drawing.Point(56, 372);
            this.btn_newCustomer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_newCustomer.Name = "btn_newCustomer";
            this.btn_newCustomer.Size = new System.Drawing.Size(141, 46);
            this.btn_newCustomer.TabIndex = 45;
            this.btn_newCustomer.Text = "New";
            this.btn_newCustomer.UseVisualStyleBackColor = true;
            this.btn_newCustomer.Click += new System.EventHandler(this.btn_newCustomer_Click);
            // 
            // txt_stateCode
            // 
            this.txt_stateCode.Location = new System.Drawing.Point(787, 304);
            this.txt_stateCode.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_stateCode.Name = "txt_stateCode";
            this.txt_stateCode.Size = new System.Drawing.Size(223, 26);
            this.txt_stateCode.TabIndex = 44;
            // 
            // lbl_stateCode
            // 
            this.lbl_stateCode.AutoSize = true;
            this.lbl_stateCode.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_stateCode.Location = new System.Drawing.Point(578, 297);
            this.lbl_stateCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_stateCode.Name = "lbl_stateCode";
            this.lbl_stateCode.Size = new System.Drawing.Size(147, 33);
            this.lbl_stateCode.TabIndex = 43;
            this.lbl_stateCode.Text = "State-Code:";
            // 
            // txt_state
            // 
            this.txt_state.Location = new System.Drawing.Point(217, 198);
            this.txt_state.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_state.Name = "txt_state";
            this.txt_state.Size = new System.Drawing.Size(223, 26);
            this.txt_state.TabIndex = 42;
            // 
            // lbl_state
            // 
            this.lbl_state.AutoSize = true;
            this.lbl_state.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_state.Location = new System.Drawing.Point(50, 191);
            this.lbl_state.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_state.Name = "lbl_state";
            this.lbl_state.Size = new System.Drawing.Size(79, 33);
            this.lbl_state.TabIndex = 41;
            this.lbl_state.Text = "State:";
            // 
            // txt_gstNo
            // 
            this.txt_gstNo.Location = new System.Drawing.Point(787, 243);
            this.txt_gstNo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_gstNo.Name = "txt_gstNo";
            this.txt_gstNo.Size = new System.Drawing.Size(223, 26);
            this.txt_gstNo.TabIndex = 40;
            // 
            // lbl_gstNo
            // 
            this.lbl_gstNo.AutoSize = true;
            this.lbl_gstNo.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gstNo.Location = new System.Drawing.Point(578, 236);
            this.lbl_gstNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_gstNo.Name = "lbl_gstNo";
            this.lbl_gstNo.Size = new System.Drawing.Size(114, 33);
            this.lbl_gstNo.TabIndex = 39;
            this.lbl_gstNo.Text = "GST-No:";
            // 
            // txt_email
            // 
            this.txt_email.Location = new System.Drawing.Point(217, 142);
            this.txt_email.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(223, 26);
            this.txt_email.TabIndex = 38;
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.Location = new System.Drawing.Point(50, 135);
            this.lbl_email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(88, 33);
            this.lbl_email.TabIndex = 37;
            this.lbl_email.Text = "Email:";
            // 
            // txt_phone
            // 
            this.txt_phone.Location = new System.Drawing.Point(787, 191);
            this.txt_phone.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_phone.Name = "txt_phone";
            this.txt_phone.Size = new System.Drawing.Size(223, 26);
            this.txt_phone.TabIndex = 36;
            // 
            // lbl_phone
            // 
            this.lbl_phone.AutoSize = true;
            this.lbl_phone.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_phone.Location = new System.Drawing.Point(578, 184);
            this.lbl_phone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_phone.Name = "lbl_phone";
            this.lbl_phone.Size = new System.Drawing.Size(93, 33);
            this.lbl_phone.TabIndex = 35;
            this.lbl_phone.Text = "Phone:";
            // 
            // txt_mobile
            // 
            this.txt_mobile.Location = new System.Drawing.Point(787, 142);
            this.txt_mobile.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_mobile.Name = "txt_mobile";
            this.txt_mobile.Size = new System.Drawing.Size(223, 26);
            this.txt_mobile.TabIndex = 34;
            // 
            // lbl_mobile
            // 
            this.lbl_mobile.AutoSize = true;
            this.lbl_mobile.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mobile.Location = new System.Drawing.Point(578, 135);
            this.lbl_mobile.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_mobile.Name = "lbl_mobile";
            this.lbl_mobile.Size = new System.Drawing.Size(104, 33);
            this.lbl_mobile.TabIndex = 33;
            this.lbl_mobile.Text = "Mobile:";
            // 
            // txt_address
            // 
            this.txt_address.Location = new System.Drawing.Point(217, 243);
            this.txt_address.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_address.Multiline = true;
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(280, 117);
            this.txt_address.TabIndex = 32;
            // 
            // lbl_address
            // 
            this.lbl_address.AutoSize = true;
            this.lbl_address.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_address.Location = new System.Drawing.Point(50, 243);
            this.lbl_address.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(113, 33);
            this.lbl_address.TabIndex = 31;
            this.lbl_address.Text = "Address:";
            // 
            // txt_customerName
            // 
            this.txt_customerName.Location = new System.Drawing.Point(787, 84);
            this.txt_customerName.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_customerName.Name = "txt_customerName";
            this.txt_customerName.Size = new System.Drawing.Size(223, 26);
            this.txt_customerName.TabIndex = 30;
            // 
            // lbl_customerName
            // 
            this.lbl_customerName.AutoSize = true;
            this.lbl_customerName.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerName.Location = new System.Drawing.Point(578, 77);
            this.lbl_customerName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_customerName.Name = "lbl_customerName";
            this.lbl_customerName.Size = new System.Drawing.Size(201, 33);
            this.lbl_customerName.TabIndex = 29;
            this.lbl_customerName.Text = "Customer Name:";
            // 
            // txt_customerId
            // 
            this.txt_customerId.Location = new System.Drawing.Point(217, 84);
            this.txt_customerId.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_customerId.Name = "txt_customerId";
            this.txt_customerId.Size = new System.Drawing.Size(223, 26);
            this.txt_customerId.TabIndex = 28;
            // 
            // lbl_customerId
            // 
            this.lbl_customerId.AutoSize = true;
            this.lbl_customerId.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerId.Location = new System.Drawing.Point(50, 77);
            this.lbl_customerId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_customerId.Name = "lbl_customerId";
            this.lbl_customerId.Size = new System.Drawing.Size(159, 33);
            this.lbl_customerId.TabIndex = 27;
            this.lbl_customerId.Text = "Customer Id:";
            // 
            // lbl_customerBilling
            // 
            this.lbl_customerBilling.AutoSize = true;
            this.lbl_customerBilling.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerBilling.Location = new System.Drawing.Point(399, 21);
            this.lbl_customerBilling.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_customerBilling.Name = "lbl_customerBilling";
            this.lbl_customerBilling.Size = new System.Drawing.Size(249, 36);
            this.lbl_customerBilling.TabIndex = 26;
            this.lbl_customerBilling.Text = "Customer Billing";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dg_financial);
            this.tabPage4.Controls.Add(this.btn_logoutFinancial);
            this.tabPage4.Controls.Add(this.btn_clearFinancial);
            this.tabPage4.Controls.Add(this.btn_deleteFinancial);
            this.tabPage4.Controls.Add(this.btn_saveFinancial);
            this.tabPage4.Controls.Add(this.btn_editFinancial);
            this.tabPage4.Controls.Add(this.txt_financialYear);
            this.tabPage4.Controls.Add(this.lbl_financialYear);
            this.tabPage4.Controls.Add(this.txt_financialId);
            this.tabPage4.Controls.Add(this.lbl_financialId);
            this.tabPage4.Controls.Add(this.lbl_financial);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1683, 773);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Financial Details";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dg_financial
            // 
            this.dg_financial.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_financial.Location = new System.Drawing.Point(280, 303);
            this.dg_financial.Name = "dg_financial";
            this.dg_financial.RowHeadersWidth = 62;
            this.dg_financial.RowTemplate.Height = 28;
            this.dg_financial.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_financial.Size = new System.Drawing.Size(588, 252);
            this.dg_financial.TabIndex = 52;
            this.dg_financial.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_financial_CellContentClick);
            // 
            // btn_logoutFinancial
            // 
            this.btn_logoutFinancial.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logoutFinancial.Location = new System.Drawing.Point(804, 236);
            this.btn_logoutFinancial.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_logoutFinancial.Name = "btn_logoutFinancial";
            this.btn_logoutFinancial.Size = new System.Drawing.Size(141, 46);
            this.btn_logoutFinancial.TabIndex = 51;
            this.btn_logoutFinancial.Text = "Logout";
            this.btn_logoutFinancial.UseVisualStyleBackColor = true;
            this.btn_logoutFinancial.Click += new System.EventHandler(this.btn_logoutFinancial_Click);
            // 
            // btn_clearFinancial
            // 
            this.btn_clearFinancial.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clearFinancial.Location = new System.Drawing.Point(655, 236);
            this.btn_clearFinancial.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_clearFinancial.Name = "btn_clearFinancial";
            this.btn_clearFinancial.Size = new System.Drawing.Size(141, 46);
            this.btn_clearFinancial.TabIndex = 50;
            this.btn_clearFinancial.Text = "Clear";
            this.btn_clearFinancial.UseVisualStyleBackColor = true;
            this.btn_clearFinancial.Click += new System.EventHandler(this.btn_clearFinancial_Click);
            // 
            // btn_deleteFinancial
            // 
            this.btn_deleteFinancial.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deleteFinancial.Location = new System.Drawing.Point(506, 236);
            this.btn_deleteFinancial.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_deleteFinancial.Name = "btn_deleteFinancial";
            this.btn_deleteFinancial.Size = new System.Drawing.Size(141, 46);
            this.btn_deleteFinancial.TabIndex = 49;
            this.btn_deleteFinancial.Text = "Delete";
            this.btn_deleteFinancial.UseVisualStyleBackColor = true;
            this.btn_deleteFinancial.Click += new System.EventHandler(this.btn_deleteFinancial_Click);
            // 
            // btn_saveFinancial
            // 
            this.btn_saveFinancial.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_saveFinancial.Location = new System.Drawing.Point(208, 236);
            this.btn_saveFinancial.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_saveFinancial.Name = "btn_saveFinancial";
            this.btn_saveFinancial.Size = new System.Drawing.Size(141, 46);
            this.btn_saveFinancial.TabIndex = 48;
            this.btn_saveFinancial.Text = "Save";
            this.btn_saveFinancial.UseVisualStyleBackColor = true;
            this.btn_saveFinancial.Click += new System.EventHandler(this.btn_saveFinancial_Click);
            // 
            // btn_editFinancial
            // 
            this.btn_editFinancial.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_editFinancial.Location = new System.Drawing.Point(357, 236);
            this.btn_editFinancial.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_editFinancial.Name = "btn_editFinancial";
            this.btn_editFinancial.Size = new System.Drawing.Size(141, 46);
            this.btn_editFinancial.TabIndex = 47;
            this.btn_editFinancial.Text = "Edit";
            this.btn_editFinancial.UseVisualStyleBackColor = true;
            this.btn_editFinancial.Click += new System.EventHandler(this.btn_editFinancial_Click);
            // 
            // txt_financialYear
            // 
            this.txt_financialYear.Location = new System.Drawing.Point(530, 186);
            this.txt_financialYear.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_financialYear.Name = "txt_financialYear";
            this.txt_financialYear.Size = new System.Drawing.Size(223, 26);
            this.txt_financialYear.TabIndex = 31;
            // 
            // lbl_financialYear
            // 
            this.lbl_financialYear.AutoSize = true;
            this.lbl_financialYear.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_financialYear.Location = new System.Drawing.Point(304, 179);
            this.lbl_financialYear.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_financialYear.Name = "lbl_financialYear";
            this.lbl_financialYear.Size = new System.Drawing.Size(183, 33);
            this.lbl_financialYear.TabIndex = 30;
            this.lbl_financialYear.Text = "Financial Year:";
            // 
            // txt_financialId
            // 
            this.txt_financialId.Location = new System.Drawing.Point(530, 107);
            this.txt_financialId.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_financialId.Name = "txt_financialId";
            this.txt_financialId.Size = new System.Drawing.Size(223, 26);
            this.txt_financialId.TabIndex = 29;
            // 
            // lbl_financialId
            // 
            this.lbl_financialId.AutoSize = true;
            this.lbl_financialId.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_financialId.Location = new System.Drawing.Point(304, 100);
            this.lbl_financialId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_financialId.Name = "lbl_financialId";
            this.lbl_financialId.Size = new System.Drawing.Size(156, 33);
            this.lbl_financialId.TabIndex = 28;
            this.lbl_financialId.Text = "Financial Id:";
            // 
            // lbl_financial
            // 
            this.lbl_financial.AutoSize = true;
            this.lbl_financial.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_financial.Location = new System.Drawing.Point(412, 30);
            this.lbl_financial.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_financial.Name = "lbl_financial";
            this.lbl_financial.Size = new System.Drawing.Size(246, 36);
            this.lbl_financial.TabIndex = 27;
            this.lbl_financial.Text = "Financial Details";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dg_loginPage);
            this.tabPage5.Controls.Add(this.btn_logoutLogin);
            this.tabPage5.Controls.Add(this.btn_clearLogin);
            this.tabPage5.Controls.Add(this.btn_deleteLogin);
            this.tabPage5.Controls.Add(this.btn_editLogin);
            this.tabPage5.Controls.Add(this.btn_saveLogin);
            this.tabPage5.Controls.Add(this.txt_passwordCreate);
            this.tabPage5.Controls.Add(this.lbl_passwordCreate);
            this.tabPage5.Controls.Add(this.txt_userNameCreate);
            this.tabPage5.Controls.Add(this.lbl_userNameCreate);
            this.tabPage5.Controls.Add(this.lbl_loginCreate);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1683, 773);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Create User";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dg_loginPage
            // 
            this.dg_loginPage.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_loginPage.Location = new System.Drawing.Point(301, 298);
            this.dg_loginPage.Name = "dg_loginPage";
            this.dg_loginPage.RowHeadersWidth = 62;
            this.dg_loginPage.RowTemplate.Height = 28;
            this.dg_loginPage.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_loginPage.Size = new System.Drawing.Size(589, 206);
            this.dg_loginPage.TabIndex = 54;
            this.dg_loginPage.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_loginPage_CellContentClick);
            // 
            // btn_logoutLogin
            // 
            this.btn_logoutLogin.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logoutLogin.Location = new System.Drawing.Point(813, 226);
            this.btn_logoutLogin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_logoutLogin.Name = "btn_logoutLogin";
            this.btn_logoutLogin.Size = new System.Drawing.Size(141, 46);
            this.btn_logoutLogin.TabIndex = 53;
            this.btn_logoutLogin.Text = "Logout";
            this.btn_logoutLogin.UseVisualStyleBackColor = true;
            this.btn_logoutLogin.Click += new System.EventHandler(this.btn_logoutLogin_Click);
            // 
            // btn_clearLogin
            // 
            this.btn_clearLogin.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clearLogin.Location = new System.Drawing.Point(664, 226);
            this.btn_clearLogin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_clearLogin.Name = "btn_clearLogin";
            this.btn_clearLogin.Size = new System.Drawing.Size(141, 46);
            this.btn_clearLogin.TabIndex = 52;
            this.btn_clearLogin.Text = "Clear";
            this.btn_clearLogin.UseVisualStyleBackColor = true;
            this.btn_clearLogin.Click += new System.EventHandler(this.btn_clearLogin_Click);
            // 
            // btn_deleteLogin
            // 
            this.btn_deleteLogin.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deleteLogin.Location = new System.Drawing.Point(515, 226);
            this.btn_deleteLogin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_deleteLogin.Name = "btn_deleteLogin";
            this.btn_deleteLogin.Size = new System.Drawing.Size(141, 46);
            this.btn_deleteLogin.TabIndex = 51;
            this.btn_deleteLogin.Text = "Delete";
            this.btn_deleteLogin.UseVisualStyleBackColor = true;
            this.btn_deleteLogin.Click += new System.EventHandler(this.btn_deleteLogin_Click);
            // 
            // btn_editLogin
            // 
            this.btn_editLogin.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_editLogin.Location = new System.Drawing.Point(366, 226);
            this.btn_editLogin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_editLogin.Name = "btn_editLogin";
            this.btn_editLogin.Size = new System.Drawing.Size(141, 46);
            this.btn_editLogin.TabIndex = 50;
            this.btn_editLogin.Text = "Edit";
            this.btn_editLogin.UseVisualStyleBackColor = true;
            this.btn_editLogin.Click += new System.EventHandler(this.btn_editLogin_Click);
            // 
            // btn_saveLogin
            // 
            this.btn_saveLogin.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_saveLogin.Location = new System.Drawing.Point(217, 226);
            this.btn_saveLogin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_saveLogin.Name = "btn_saveLogin";
            this.btn_saveLogin.Size = new System.Drawing.Size(141, 46);
            this.btn_saveLogin.TabIndex = 49;
            this.btn_saveLogin.Text = "Save";
            this.btn_saveLogin.UseVisualStyleBackColor = true;
            this.btn_saveLogin.Click += new System.EventHandler(this.btn_saveLogin_Click);
            // 
            // txt_passwordCreate
            // 
            this.txt_passwordCreate.Location = new System.Drawing.Point(553, 173);
            this.txt_passwordCreate.Name = "txt_passwordCreate";
            this.txt_passwordCreate.Size = new System.Drawing.Size(199, 26);
            this.txt_passwordCreate.TabIndex = 7;
            // 
            // lbl_passwordCreate
            // 
            this.lbl_passwordCreate.AutoSize = true;
            this.lbl_passwordCreate.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_passwordCreate.Location = new System.Drawing.Point(351, 166);
            this.lbl_passwordCreate.Name = "lbl_passwordCreate";
            this.lbl_passwordCreate.Size = new System.Drawing.Size(129, 33);
            this.lbl_passwordCreate.TabIndex = 6;
            this.lbl_passwordCreate.Text = "Password:";
            // 
            // txt_userNameCreate
            // 
            this.txt_userNameCreate.Location = new System.Drawing.Point(553, 109);
            this.txt_userNameCreate.Name = "txt_userNameCreate";
            this.txt_userNameCreate.Size = new System.Drawing.Size(199, 26);
            this.txt_userNameCreate.TabIndex = 5;
            // 
            // lbl_userNameCreate
            // 
            this.lbl_userNameCreate.AutoSize = true;
            this.lbl_userNameCreate.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_userNameCreate.Location = new System.Drawing.Point(351, 102);
            this.lbl_userNameCreate.Name = "lbl_userNameCreate";
            this.lbl_userNameCreate.Size = new System.Drawing.Size(138, 33);
            this.lbl_userNameCreate.TabIndex = 3;
            this.lbl_userNameCreate.Text = "UserName:";
            // 
            // lbl_loginCreate
            // 
            this.lbl_loginCreate.AutoSize = true;
            this.lbl_loginCreate.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_loginCreate.Location = new System.Drawing.Point(446, 35);
            this.lbl_loginCreate.Name = "lbl_loginCreate";
            this.lbl_loginCreate.Size = new System.Drawing.Size(177, 32);
            this.lbl_loginCreate.TabIndex = 2;
            this.lbl_loginCreate.Text = "Create Login ";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dg_invoiceView1);
            this.tabPage6.Controls.Add(this.btn_logoutInvoice);
            this.tabPage6.Controls.Add(this.btn_clearInvoice);
            this.tabPage6.Controls.Add(this.btn_find);
            this.tabPage6.Controls.Add(this.btn_deleteInvoice);
            this.tabPage6.Controls.Add(this.btn_editInvoice);
            this.tabPage6.Controls.Add(this.btn_saveInvoice);
            this.tabPage6.Controls.Add(this.btn_newInvoice);
            this.tabPage6.Controls.Add(this.txt_grandTotalInvoice);
            this.tabPage6.Controls.Add(this.lbl_grandTotalAmount);
            this.tabPage6.Controls.Add(this.txt_totalDiscountInvoice);
            this.tabPage6.Controls.Add(this.lbl_totalDiscount);
            this.tabPage6.Controls.Add(this.txt_totalTaxInvoice);
            this.tabPage6.Controls.Add(this.lbl_totalGstInvoice);
            this.tabPage6.Controls.Add(this.pn_itemDetails);
            this.tabPage6.Controls.Add(this.txt_stateCodeInvoice);
            this.tabPage6.Controls.Add(this.lbl_stateCodeInvoice);
            this.tabPage6.Controls.Add(this.txt_stateInvoice);
            this.tabPage6.Controls.Add(this.label8);
            this.tabPage6.Controls.Add(this.txt_phoneInvoice);
            this.tabPage6.Controls.Add(this.label7);
            this.tabPage6.Controls.Add(this.txt_emailInvoice);
            this.tabPage6.Controls.Add(this.label5);
            this.tabPage6.Controls.Add(this.txt_gstNoInvoice);
            this.tabPage6.Controls.Add(this.txt_addressInvoice);
            this.tabPage6.Controls.Add(this.lbl_gstNoInvoice);
            this.tabPage6.Controls.Add(this.txt_customerNameInvoice);
            this.tabPage6.Controls.Add(this.label4);
            this.tabPage6.Controls.Add(this.label3);
            this.tabPage6.Controls.Add(this.txt_mobileInvoice);
            this.tabPage6.Controls.Add(this.label2);
            this.tabPage6.Controls.Add(this.txt_customerIdInvoice);
            this.tabPage6.Controls.Add(this.label1);
            this.tabPage6.Controls.Add(this.dtp_billDateInvoice);
            this.tabPage6.Controls.Add(this.lbl_billDate);
            this.tabPage6.Controls.Add(this.txt_billNoInvoice);
            this.tabPage6.Controls.Add(this.lbl_billNo);
            this.tabPage6.Controls.Add(this.cb_salesType);
            this.tabPage6.Controls.Add(this.lbl_salesType);
            this.tabPage6.Controls.Add(this.lbl_invoice);
            this.tabPage6.Location = new System.Drawing.Point(4, 29);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1683, 773);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Invoice Bills";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dg_invoiceView1
            // 
            this.dg_invoiceView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dg_invoiceView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dg_invoiceView1.CausesValidation = false;
            this.dg_invoiceView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dg_invoiceView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dg_invoiceView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_invoiceView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.Name,
            this.Qty,
            this.Rate,
            this.Discount,
            this.TaxValue,
            this.Total,
            this.Edit,
            this.Delete});
            this.dg_invoiceView1.EnableHeadersVisualStyles = false;
            this.dg_invoiceView1.GridColor = System.Drawing.SystemColors.Control;
            this.dg_invoiceView1.Location = new System.Drawing.Point(24, 415);
            this.dg_invoiceView1.Name = "dg_invoiceView1";
            this.dg_invoiceView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dg_invoiceView1.RowHeadersWidth = 62;
            this.dg_invoiceView1.RowTemplate.Height = 28;
            this.dg_invoiceView1.Size = new System.Drawing.Size(1106, 219);
            this.dg_invoiceView1.TabIndex = 94;
            // 
            // Id
            // 
            this.Id.DataPropertyName = "id";
            this.Id.HeaderText = "Id";
            this.Id.MinimumWidth = 8;
            this.Id.Name = "Id";
            this.Id.Width = 150;
            // 
            // Name
            // 
            this.Name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Name.DataPropertyName = "itemName";
            this.Name.HeaderText = "Name";
            this.Name.MinimumWidth = 8;
            this.Name.Name = "Name";
            // 
            // Qty
            // 
            this.Qty.DataPropertyName = "quantity";
            this.Qty.HeaderText = "Qty";
            this.Qty.MinimumWidth = 8;
            this.Qty.Name = "Qty";
            this.Qty.Width = 150;
            // 
            // Rate
            // 
            this.Rate.DataPropertyName = "price";
            this.Rate.HeaderText = "Rate";
            this.Rate.MinimumWidth = 8;
            this.Rate.Name = "Rate";
            this.Rate.Width = 150;
            // 
            // Discount
            // 
            this.Discount.DataPropertyName = "discount";
            this.Discount.HeaderText = "Discount";
            this.Discount.MinimumWidth = 8;
            this.Discount.Name = "Discount";
            this.Discount.Width = 150;
            // 
            // TaxValue
            // 
            this.TaxValue.DataPropertyName = "tax";
            this.TaxValue.HeaderText = "TaxValue";
            this.TaxValue.MinimumWidth = 8;
            this.TaxValue.Name = "TaxValue";
            this.TaxValue.Width = 150;
            // 
            // Total
            // 
            this.Total.DataPropertyName = "totalAmount";
            this.Total.HeaderText = "Total";
            this.Total.MinimumWidth = 8;
            this.Total.Name = "Total";
            this.Total.Width = 150;
            // 
            // Edit
            // 
            this.Edit.HeaderText = "Edit";
            this.Edit.MinimumWidth = 8;
            this.Edit.Name = "Edit";
            this.Edit.Width = 150;
            // 
            // Delete
            // 
            this.Delete.HeaderText = "Delete";
            this.Delete.MinimumWidth = 8;
            this.Delete.Name = "Delete";
            this.Delete.Width = 150;
            // 
            // btn_logoutInvoice
            // 
            this.btn_logoutInvoice.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.btn_logoutInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logoutInvoice.Location = new System.Drawing.Point(1156, 688);
            this.btn_logoutInvoice.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_logoutInvoice.Name = "btn_logoutInvoice";
            this.btn_logoutInvoice.Size = new System.Drawing.Size(141, 69);
            this.btn_logoutInvoice.TabIndex = 93;
            this.btn_logoutInvoice.Text = "Logout";
            this.btn_logoutInvoice.UseVisualStyleBackColor = false;
            this.btn_logoutInvoice.Click += new System.EventHandler(this.btn_logoutInvoice_Click);
            // 
            // btn_clearInvoice
            // 
            this.btn_clearInvoice.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn_clearInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clearInvoice.Location = new System.Drawing.Point(967, 688);
            this.btn_clearInvoice.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_clearInvoice.Name = "btn_clearInvoice";
            this.btn_clearInvoice.Size = new System.Drawing.Size(141, 69);
            this.btn_clearInvoice.TabIndex = 92;
            this.btn_clearInvoice.Text = "Clear";
            this.btn_clearInvoice.UseVisualStyleBackColor = false;
            this.btn_clearInvoice.Click += new System.EventHandler(this.btn_clearInvoice_Click);
            // 
            // btn_find
            // 
            this.btn_find.BackColor = System.Drawing.Color.MediumBlue;
            this.btn_find.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.ForeColor = System.Drawing.SystemColors.Control;
            this.btn_find.Location = new System.Drawing.Point(779, 688);
            this.btn_find.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(141, 69);
            this.btn_find.TabIndex = 91;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = false;
            // 
            // btn_deleteInvoice
            // 
            this.btn_deleteInvoice.BackColor = System.Drawing.Color.Red;
            this.btn_deleteInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deleteInvoice.Location = new System.Drawing.Point(590, 688);
            this.btn_deleteInvoice.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_deleteInvoice.Name = "btn_deleteInvoice";
            this.btn_deleteInvoice.Size = new System.Drawing.Size(141, 69);
            this.btn_deleteInvoice.TabIndex = 90;
            this.btn_deleteInvoice.Text = "Delete";
            this.btn_deleteInvoice.UseVisualStyleBackColor = false;
            this.btn_deleteInvoice.Click += new System.EventHandler(this.btn_deleteInvoice_Click);
            // 
            // btn_editInvoice
            // 
            this.btn_editInvoice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_editInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_editInvoice.Location = new System.Drawing.Point(396, 688);
            this.btn_editInvoice.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_editInvoice.Name = "btn_editInvoice";
            this.btn_editInvoice.Size = new System.Drawing.Size(141, 69);
            this.btn_editInvoice.TabIndex = 89;
            this.btn_editInvoice.Text = "Edit";
            this.btn_editInvoice.UseVisualStyleBackColor = false;
            this.btn_editInvoice.Click += new System.EventHandler(this.btn_editInvoice_Click);
            // 
            // btn_saveInvoice
            // 
            this.btn_saveInvoice.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_saveInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_saveInvoice.Location = new System.Drawing.Point(201, 688);
            this.btn_saveInvoice.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_saveInvoice.Name = "btn_saveInvoice";
            this.btn_saveInvoice.Size = new System.Drawing.Size(141, 69);
            this.btn_saveInvoice.TabIndex = 88;
            this.btn_saveInvoice.Text = "Save";
            this.btn_saveInvoice.UseVisualStyleBackColor = false;
            this.btn_saveInvoice.Click += new System.EventHandler(this.btn_saveInvoice_Click);
            // 
            // btn_newInvoice
            // 
            this.btn_newInvoice.BackColor = System.Drawing.Color.Navy;
            this.btn_newInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newInvoice.ForeColor = System.Drawing.SystemColors.Control;
            this.btn_newInvoice.Location = new System.Drawing.Point(16, 688);
            this.btn_newInvoice.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_newInvoice.Name = "btn_newInvoice";
            this.btn_newInvoice.Size = new System.Drawing.Size(141, 69);
            this.btn_newInvoice.TabIndex = 87;
            this.btn_newInvoice.Text = "New";
            this.btn_newInvoice.UseVisualStyleBackColor = false;
            this.btn_newInvoice.Click += new System.EventHandler(this.btn_newInvoice_Click);
            // 
            // txt_grandTotalInvoice
            // 
            this.txt_grandTotalInvoice.Location = new System.Drawing.Point(1384, 576);
            this.txt_grandTotalInvoice.Multiline = true;
            this.txt_grandTotalInvoice.Name = "txt_grandTotalInvoice";
            this.txt_grandTotalInvoice.Size = new System.Drawing.Size(260, 59);
            this.txt_grandTotalInvoice.TabIndex = 86;
            // 
            // lbl_grandTotalAmount
            // 
            this.lbl_grandTotalAmount.AutoSize = true;
            this.lbl_grandTotalAmount.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_grandTotalAmount.Location = new System.Drawing.Point(1204, 569);
            this.lbl_grandTotalAmount.Name = "lbl_grandTotalAmount";
            this.lbl_grandTotalAmount.Size = new System.Drawing.Size(169, 32);
            this.lbl_grandTotalAmount.TabIndex = 85;
            this.lbl_grandTotalAmount.Text = "Grand Total:";
            // 
            // txt_totalDiscountInvoice
            // 
            this.txt_totalDiscountInvoice.Location = new System.Drawing.Point(1384, 512);
            this.txt_totalDiscountInvoice.Multiline = true;
            this.txt_totalDiscountInvoice.Name = "txt_totalDiscountInvoice";
            this.txt_totalDiscountInvoice.Size = new System.Drawing.Size(199, 33);
            this.txt_totalDiscountInvoice.TabIndex = 84;
            // 
            // lbl_totalDiscount
            // 
            this.lbl_totalDiscount.AutoSize = true;
            this.lbl_totalDiscount.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalDiscount.Location = new System.Drawing.Point(1204, 512);
            this.lbl_totalDiscount.Name = "lbl_totalDiscount";
            this.lbl_totalDiscount.Size = new System.Drawing.Size(137, 33);
            this.lbl_totalDiscount.TabIndex = 83;
            this.lbl_totalDiscount.Text = "Total Disc:";
            // 
            // txt_totalTaxInvoice
            // 
            this.txt_totalTaxInvoice.Location = new System.Drawing.Point(1384, 455);
            this.txt_totalTaxInvoice.Multiline = true;
            this.txt_totalTaxInvoice.Name = "txt_totalTaxInvoice";
            this.txt_totalTaxInvoice.Size = new System.Drawing.Size(199, 33);
            this.txt_totalTaxInvoice.TabIndex = 82;
            // 
            // lbl_totalGstInvoice
            // 
            this.lbl_totalGstInvoice.AutoSize = true;
            this.lbl_totalGstInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalGstInvoice.Location = new System.Drawing.Point(1204, 455);
            this.lbl_totalGstInvoice.Name = "lbl_totalGstInvoice";
            this.lbl_totalGstInvoice.Size = new System.Drawing.Size(125, 33);
            this.lbl_totalGstInvoice.TabIndex = 81;
            this.lbl_totalGstInvoice.Text = "Total Tax:";
            // 
            // pn_itemDetails
            // 
            this.pn_itemDetails.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pn_itemDetails.Controls.Add(this.lbl_taxInvoice);
            this.pn_itemDetails.Controls.Add(this.txt_taxInvoiceBill);
            this.pn_itemDetails.Controls.Add(this.label6);
            this.pn_itemDetails.Controls.Add(this.txt_itemCodeInvoice);
            this.pn_itemDetails.Controls.Add(this.lbl_itemDescription);
            this.pn_itemDetails.Controls.Add(this.txt_itemNameInvoice);
            this.pn_itemDetails.Controls.Add(this.lbl_quantityInvoice);
            this.pn_itemDetails.Controls.Add(this.txt_quantityInvoice);
            this.pn_itemDetails.Controls.Add(this.lbl_discountInvoice);
            this.pn_itemDetails.Controls.Add(this.lbl_totalInvoice);
            this.pn_itemDetails.Controls.Add(this.txt_discountInvoice);
            this.pn_itemDetails.Controls.Add(this.lbl_priceInvoice);
            this.pn_itemDetails.Controls.Add(this.txt_priceInvoice);
            this.pn_itemDetails.Controls.Add(this.txt_totalAmountInvoice);
            this.pn_itemDetails.Controls.Add(this.btn_refreshInvoice);
            this.pn_itemDetails.Controls.Add(this.btn_addInvoice);
            this.pn_itemDetails.Location = new System.Drawing.Point(22, 275);
            this.pn_itemDetails.Name = "pn_itemDetails";
            this.pn_itemDetails.Size = new System.Drawing.Size(1533, 121);
            this.pn_itemDetails.TabIndex = 80;
            // 
            // lbl_taxInvoice
            // 
            this.lbl_taxInvoice.AutoSize = true;
            this.lbl_taxInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_taxInvoice.Location = new System.Drawing.Point(1008, 18);
            this.lbl_taxInvoice.Name = "lbl_taxInvoice";
            this.lbl_taxInvoice.Size = new System.Drawing.Size(63, 33);
            this.lbl_taxInvoice.TabIndex = 49;
            this.lbl_taxInvoice.Text = "Tax:";
            // 
            // txt_taxInvoiceBill
            // 
            this.txt_taxInvoiceBill.Location = new System.Drawing.Point(961, 68);
            this.txt_taxInvoiceBill.Name = "txt_taxInvoiceBill";
            this.txt_taxInvoiceBill.Size = new System.Drawing.Size(166, 26);
            this.txt_taxInvoiceBill.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Firebrick;
            this.label6.Location = new System.Drawing.Point(20, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 33);
            this.label6.TabIndex = 2;
            this.label6.Text = "Item Code:";
            // 
            // txt_itemCodeInvoice
            // 
            this.txt_itemCodeInvoice.Location = new System.Drawing.Point(9, 68);
            this.txt_itemCodeInvoice.Name = "txt_itemCodeInvoice";
            this.txt_itemCodeInvoice.Size = new System.Drawing.Size(160, 26);
            this.txt_itemCodeInvoice.TabIndex = 13;
            this.txt_itemCodeInvoice.TextChanged += new System.EventHandler(this.txt_itemCodeInvoice_TextChanged);
            // 
            // lbl_itemDescription
            // 
            this.lbl_itemDescription.AutoSize = true;
            this.lbl_itemDescription.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemDescription.Location = new System.Drawing.Point(214, 18);
            this.lbl_itemDescription.Name = "lbl_itemDescription";
            this.lbl_itemDescription.Size = new System.Drawing.Size(142, 33);
            this.lbl_itemDescription.TabIndex = 4;
            this.lbl_itemDescription.Text = "Item Name:";
            // 
            // txt_itemNameInvoice
            // 
            this.txt_itemNameInvoice.Location = new System.Drawing.Point(193, 68);
            this.txt_itemNameInvoice.Multiline = true;
            this.txt_itemNameInvoice.Name = "txt_itemNameInvoice";
            this.txt_itemNameInvoice.Size = new System.Drawing.Size(191, 26);
            this.txt_itemNameInvoice.TabIndex = 14;
            // 
            // lbl_quantityInvoice
            // 
            this.lbl_quantityInvoice.AutoSize = true;
            this.lbl_quantityInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_quantityInvoice.ForeColor = System.Drawing.Color.Firebrick;
            this.lbl_quantityInvoice.Location = new System.Drawing.Point(437, 18);
            this.lbl_quantityInvoice.Name = "lbl_quantityInvoice";
            this.lbl_quantityInvoice.Size = new System.Drawing.Size(120, 33);
            this.lbl_quantityInvoice.TabIndex = 6;
            this.lbl_quantityInvoice.Text = "Quantity:";
            // 
            // txt_quantityInvoice
            // 
            this.txt_quantityInvoice.Location = new System.Drawing.Point(415, 68);
            this.txt_quantityInvoice.Name = "txt_quantityInvoice";
            this.txt_quantityInvoice.Size = new System.Drawing.Size(156, 26);
            this.txt_quantityInvoice.TabIndex = 15;
            // 
            // lbl_discountInvoice
            // 
            this.lbl_discountInvoice.AutoSize = true;
            this.lbl_discountInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_discountInvoice.Location = new System.Drawing.Point(800, 18);
            this.lbl_discountInvoice.Name = "lbl_discountInvoice";
            this.lbl_discountInvoice.Size = new System.Drawing.Size(122, 33);
            this.lbl_discountInvoice.TabIndex = 8;
            this.lbl_discountInvoice.Text = "Disc (%):";
            // 
            // lbl_totalInvoice
            // 
            this.lbl_totalInvoice.AutoSize = true;
            this.lbl_totalInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalInvoice.Location = new System.Drawing.Point(1182, 18);
            this.lbl_totalInvoice.Name = "lbl_totalInvoice";
            this.lbl_totalInvoice.Size = new System.Drawing.Size(79, 33);
            this.lbl_totalInvoice.TabIndex = 47;
            this.lbl_totalInvoice.Text = "Total:";
            // 
            // txt_discountInvoice
            // 
            this.txt_discountInvoice.Location = new System.Drawing.Point(774, 68);
            this.txt_discountInvoice.Name = "txt_discountInvoice";
            this.txt_discountInvoice.Size = new System.Drawing.Size(166, 26);
            this.txt_discountInvoice.TabIndex = 17;
            this.txt_discountInvoice.TextChanged += new System.EventHandler(this.txt_discountInvoice_TextChanged);
            // 
            // lbl_priceInvoice
            // 
            this.lbl_priceInvoice.AutoSize = true;
            this.lbl_priceInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_priceInvoice.Location = new System.Drawing.Point(629, 18);
            this.lbl_priceInvoice.Name = "lbl_priceInvoice";
            this.lbl_priceInvoice.Size = new System.Drawing.Size(80, 33);
            this.lbl_priceInvoice.TabIndex = 10;
            this.lbl_priceInvoice.Text = "Price:";
            // 
            // txt_priceInvoice
            // 
            this.txt_priceInvoice.Location = new System.Drawing.Point(596, 68);
            this.txt_priceInvoice.Name = "txt_priceInvoice";
            this.txt_priceInvoice.Size = new System.Drawing.Size(155, 26);
            this.txt_priceInvoice.TabIndex = 16;
            // 
            // txt_totalAmountInvoice
            // 
            this.txt_totalAmountInvoice.Location = new System.Drawing.Point(1155, 68);
            this.txt_totalAmountInvoice.Name = "txt_totalAmountInvoice";
            this.txt_totalAmountInvoice.Size = new System.Drawing.Size(157, 26);
            this.txt_totalAmountInvoice.TabIndex = 19;
            // 
            // btn_refreshInvoice
            // 
            this.btn_refreshInvoice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_refreshInvoice.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_refreshInvoice.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_refreshInvoice.Location = new System.Drawing.Point(1438, 36);
            this.btn_refreshInvoice.Name = "btn_refreshInvoice";
            this.btn_refreshInvoice.Size = new System.Drawing.Size(80, 58);
            this.btn_refreshInvoice.TabIndex = 21;
            this.btn_refreshInvoice.Text = "-";
            this.btn_refreshInvoice.UseVisualStyleBackColor = false;
            this.btn_refreshInvoice.Click += new System.EventHandler(this.btn_refreshInvoice_Click);
            // 
            // btn_addInvoice
            // 
            this.btn_addInvoice.BackColor = System.Drawing.Color.Black;
            this.btn_addInvoice.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addInvoice.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_addInvoice.Location = new System.Drawing.Point(1342, 36);
            this.btn_addInvoice.Name = "btn_addInvoice";
            this.btn_addInvoice.Size = new System.Drawing.Size(80, 58);
            this.btn_addInvoice.TabIndex = 20;
            this.btn_addInvoice.Text = "+";
            this.btn_addInvoice.UseVisualStyleBackColor = false;
            this.btn_addInvoice.Click += new System.EventHandler(this.btn_addInvoice_Click);
            // 
            // txt_stateCodeInvoice
            // 
            this.txt_stateCodeInvoice.Location = new System.Drawing.Point(1366, 194);
            this.txt_stateCodeInvoice.Multiline = true;
            this.txt_stateCodeInvoice.Name = "txt_stateCodeInvoice";
            this.txt_stateCodeInvoice.Size = new System.Drawing.Size(191, 33);
            this.txt_stateCodeInvoice.TabIndex = 79;
            // 
            // lbl_stateCodeInvoice
            // 
            this.lbl_stateCodeInvoice.AutoSize = true;
            this.lbl_stateCodeInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_stateCodeInvoice.Location = new System.Drawing.Point(1204, 194);
            this.lbl_stateCodeInvoice.Name = "lbl_stateCodeInvoice";
            this.lbl_stateCodeInvoice.Size = new System.Drawing.Size(147, 33);
            this.lbl_stateCodeInvoice.TabIndex = 78;
            this.lbl_stateCodeInvoice.Text = "State-Code:";
            // 
            // txt_stateInvoice
            // 
            this.txt_stateInvoice.Location = new System.Drawing.Point(1366, 116);
            this.txt_stateInvoice.Multiline = true;
            this.txt_stateInvoice.Name = "txt_stateInvoice";
            this.txt_stateInvoice.Size = new System.Drawing.Size(191, 33);
            this.txt_stateInvoice.TabIndex = 77;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1204, 116);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 33);
            this.label8.TabIndex = 76;
            this.label8.Text = "State:";
            // 
            // txt_phoneInvoice
            // 
            this.txt_phoneInvoice.Location = new System.Drawing.Point(1366, 66);
            this.txt_phoneInvoice.Multiline = true;
            this.txt_phoneInvoice.Name = "txt_phoneInvoice";
            this.txt_phoneInvoice.Size = new System.Drawing.Size(191, 33);
            this.txt_phoneInvoice.TabIndex = 75;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1204, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 33);
            this.label7.TabIndex = 74;
            this.label7.Text = "Phone:";
            // 
            // txt_emailInvoice
            // 
            this.txt_emailInvoice.Location = new System.Drawing.Point(555, 172);
            this.txt_emailInvoice.Multiline = true;
            this.txt_emailInvoice.Name = "txt_emailInvoice";
            this.txt_emailInvoice.Size = new System.Drawing.Size(185, 33);
            this.txt_emailInvoice.TabIndex = 72;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(390, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 33);
            this.label5.TabIndex = 71;
            this.label5.Text = "Email:";
            // 
            // txt_gstNoInvoice
            // 
            this.txt_gstNoInvoice.Location = new System.Drawing.Point(967, 116);
            this.txt_gstNoInvoice.Multiline = true;
            this.txt_gstNoInvoice.Name = "txt_gstNoInvoice";
            this.txt_gstNoInvoice.Size = new System.Drawing.Size(187, 33);
            this.txt_gstNoInvoice.TabIndex = 70;
            // 
            // txt_addressInvoice
            // 
            this.txt_addressInvoice.Location = new System.Drawing.Point(962, 163);
            this.txt_addressInvoice.Multiline = true;
            this.txt_addressInvoice.Name = "txt_addressInvoice";
            this.txt_addressInvoice.Size = new System.Drawing.Size(220, 82);
            this.txt_addressInvoice.TabIndex = 69;
            // 
            // lbl_gstNoInvoice
            // 
            this.lbl_gstNoInvoice.AutoSize = true;
            this.lbl_gstNoInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gstNoInvoice.Location = new System.Drawing.Point(760, 116);
            this.lbl_gstNoInvoice.Name = "lbl_gstNoInvoice";
            this.lbl_gstNoInvoice.Size = new System.Drawing.Size(114, 33);
            this.lbl_gstNoInvoice.TabIndex = 68;
            this.lbl_gstNoInvoice.Text = "GST-No:";
            // 
            // txt_customerNameInvoice
            // 
            this.txt_customerNameInvoice.Location = new System.Drawing.Point(967, 68);
            this.txt_customerNameInvoice.Multiline = true;
            this.txt_customerNameInvoice.Name = "txt_customerNameInvoice";
            this.txt_customerNameInvoice.Size = new System.Drawing.Size(187, 33);
            this.txt_customerNameInvoice.TabIndex = 67;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(760, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(201, 33);
            this.label4.TabIndex = 66;
            this.label4.Text = "Customer Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(760, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 33);
            this.label3.TabIndex = 65;
            this.label3.Text = "Address:";
            // 
            // txt_mobileInvoice
            // 
            this.txt_mobileInvoice.Location = new System.Drawing.Point(555, 123);
            this.txt_mobileInvoice.Multiline = true;
            this.txt_mobileInvoice.Name = "txt_mobileInvoice";
            this.txt_mobileInvoice.Size = new System.Drawing.Size(185, 33);
            this.txt_mobileInvoice.TabIndex = 64;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(390, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 33);
            this.label2.TabIndex = 63;
            this.label2.Text = "Mobile:";
            // 
            // txt_customerIdInvoice
            // 
            this.txt_customerIdInvoice.Location = new System.Drawing.Point(555, 66);
            this.txt_customerIdInvoice.Multiline = true;
            this.txt_customerIdInvoice.Name = "txt_customerIdInvoice";
            this.txt_customerIdInvoice.Size = new System.Drawing.Size(185, 35);
            this.txt_customerIdInvoice.TabIndex = 62;
            this.txt_customerIdInvoice.TextChanged += new System.EventHandler(this.txt_customerIdInvoice_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Firebrick;
            this.label1.Location = new System.Drawing.Point(390, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 33);
            this.label1.TabIndex = 61;
            this.label1.Text = "Customer Id:";
            // 
            // dtp_billDateInvoice
            // 
            this.dtp_billDateInvoice.CustomFormat = "";
            this.dtp_billDateInvoice.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_billDateInvoice.Location = new System.Drawing.Point(163, 170);
            this.dtp_billDateInvoice.Name = "dtp_billDateInvoice";
            this.dtp_billDateInvoice.Size = new System.Drawing.Size(198, 26);
            this.dtp_billDateInvoice.TabIndex = 60;
            // 
            // lbl_billDate
            // 
            this.lbl_billDate.AutoSize = true;
            this.lbl_billDate.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_billDate.Location = new System.Drawing.Point(16, 163);
            this.lbl_billDate.Name = "lbl_billDate";
            this.lbl_billDate.Size = new System.Drawing.Size(125, 33);
            this.lbl_billDate.TabIndex = 59;
            this.lbl_billDate.Text = "Bill Date:";
            // 
            // txt_billNoInvoice
            // 
            this.txt_billNoInvoice.Location = new System.Drawing.Point(163, 116);
            this.txt_billNoInvoice.Multiline = true;
            this.txt_billNoInvoice.Name = "txt_billNoInvoice";
            this.txt_billNoInvoice.Size = new System.Drawing.Size(199, 33);
            this.txt_billNoInvoice.TabIndex = 58;
            // 
            // lbl_billNo
            // 
            this.lbl_billNo.AutoSize = true;
            this.lbl_billNo.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_billNo.Location = new System.Drawing.Point(16, 116);
            this.lbl_billNo.Name = "lbl_billNo";
            this.lbl_billNo.Size = new System.Drawing.Size(107, 33);
            this.lbl_billNo.TabIndex = 57;
            this.lbl_billNo.Text = "Bill No:";
            // 
            // cb_salesType
            // 
            this.cb_salesType.FormattingEnabled = true;
            this.cb_salesType.Items.AddRange(new object[] {
            "Exclusive",
            "Inclusive"});
            this.cb_salesType.Location = new System.Drawing.Point(163, 73);
            this.cb_salesType.Name = "cb_salesType";
            this.cb_salesType.Size = new System.Drawing.Size(199, 28);
            this.cb_salesType.TabIndex = 56;
            // 
            // lbl_salesType
            // 
            this.lbl_salesType.AutoSize = true;
            this.lbl_salesType.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_salesType.Location = new System.Drawing.Point(16, 66);
            this.lbl_salesType.Name = "lbl_salesType";
            this.lbl_salesType.Size = new System.Drawing.Size(141, 33);
            this.lbl_salesType.TabIndex = 55;
            this.lbl_salesType.Text = "Sales Type:";
            // 
            // lbl_invoice
            // 
            this.lbl_invoice.AutoSize = true;
            this.lbl_invoice.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_invoice.Location = new System.Drawing.Point(698, 3);
            this.lbl_invoice.Name = "lbl_invoice";
            this.lbl_invoice.Size = new System.Drawing.Size(222, 41);
            this.lbl_invoice.TabIndex = 1;
            this.lbl_invoice.Text = "Invoice Form";
            // 
            // dbBankDataSet1
            // 
            this.dbBankDataSet1.DataSetName = "dbBankDataSet1";
            this.dbBankDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dbBankDataSet1BindingSource
            // 
            this.dbBankDataSet1BindingSource.DataSource = this.dbBankDataSet1;
            this.dbBankDataSet1BindingSource.Position = 0;
            // 
            // tb_taxTableAdapter
            // 
            this.tb_taxTableAdapter.ClearBeforeFill = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1820, 848);
            this.Controls.Add(this.tc_invoiceBills);
            //this.Name = "Form2";
            this.Text = "Form2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tc_invoiceBills.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_view)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_itemView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbtaxBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbBankDataSet)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_viewCustomer)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_financial)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_loginPage)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_invoiceView1)).EndInit();
            this.pn_itemDetails.ResumeLayout(false);
            this.pn_itemDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dbBankDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbBankDataSet1BindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tc_invoiceBills;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dg_view;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_edit;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.TextBox txt_taxValue;
        private System.Windows.Forms.Label lbl_txtValue;
        private System.Windows.Forms.TextBox txt_taxName;
        private System.Windows.Forms.Label lbl_taxName;
        private System.Windows.Forms.TextBox txt_taxId;
        private System.Windows.Forms.Label lbl_tax;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lbl_taxId;
        private System.Windows.Forms.Button btn_new;
        private System.Windows.Forms.Label lbl_itemDetails;
        private System.Windows.Forms.Label lbl_itemCode;
        private System.Windows.Forms.Label lbl_itemName;
        private System.Windows.Forms.TextBox txt_itemCode;
        private System.Windows.Forms.TextBox txt_hsnCode;
        private System.Windows.Forms.Label lbl_hsnCode;
        private System.Windows.Forms.TextBox txt_itemName;
        private System.Windows.Forms.TextBox txt_unit;
        private System.Windows.Forms.Label lbl_unit;
        private System.Windows.Forms.Label lbl_sellingPrice;
        private System.Windows.Forms.ComboBox cb_tax;
        private System.Windows.Forms.Label txt_tax;
        private System.Windows.Forms.TextBox txt_sellingPrice;
        private System.Windows.Forms.Button btn_save1;
        private System.Windows.Forms.Button btn_new1;
        private System.Windows.Forms.DataGridView dg_itemView;
        private System.Windows.Forms.Button btn_logout1;
        private System.Windows.Forms.Button btn_clear1;
        private System.Windows.Forms.Button btn_delete1;
        private System.Windows.Forms.Button btn_edit1;
        private System.Windows.Forms.BindingSource dbBankDataSet1BindingSource;
        private dbBankDataSet1 dbBankDataSet1;
        private dbBankDataSet dbBankDataSet;
        private System.Windows.Forms.BindingSource tbtaxBindingSource;
        private dbBankDataSetTableAdapters.tb_taxTableAdapter tb_taxTableAdapter;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label lbl_customerBilling;
        private System.Windows.Forms.TextBox txt_customerName;
        private System.Windows.Forms.Label lbl_customerName;
        private System.Windows.Forms.TextBox txt_customerId;
        private System.Windows.Forms.Label lbl_customerId;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.TextBox txt_phone;
        private System.Windows.Forms.Label lbl_phone;
        private System.Windows.Forms.TextBox txt_mobile;
        private System.Windows.Forms.Label lbl_mobile;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.Label lbl_stateCode;
        private System.Windows.Forms.TextBox txt_state;
        private System.Windows.Forms.Label lbl_state;
        private System.Windows.Forms.TextBox txt_gstNo;
        private System.Windows.Forms.Label lbl_gstNo;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Button btn_deleteCustomer;
        private System.Windows.Forms.Button btn_editCustomer;
        private System.Windows.Forms.Button btn_saveCustomer;
        private System.Windows.Forms.Button btn_newCustomer;
        private System.Windows.Forms.TextBox txt_stateCode;
        private System.Windows.Forms.Button btn_logoutCustomer;
        private System.Windows.Forms.Button btn_clearCustomer;
        private System.Windows.Forms.DataGridView dg_viewCustomer;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label lbl_financial;
        private System.Windows.Forms.TextBox txt_financialYear;
        private System.Windows.Forms.Label lbl_financialYear;
        private System.Windows.Forms.TextBox txt_financialId;
        private System.Windows.Forms.Label lbl_financialId;
        private System.Windows.Forms.Button btn_deleteFinancial;
        private System.Windows.Forms.Button btn_saveFinancial;
        private System.Windows.Forms.Button btn_editFinancial;
        private System.Windows.Forms.DataGridView dg_financial;
        private System.Windows.Forms.Button btn_logoutFinancial;
        private System.Windows.Forms.Button btn_clearFinancial;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label lbl_loginCreate;
        private System.Windows.Forms.Label lbl_userNameCreate;
        private System.Windows.Forms.TextBox txt_userNameCreate;
        private System.Windows.Forms.TextBox txt_passwordCreate;
        private System.Windows.Forms.Label lbl_passwordCreate;
        private System.Windows.Forms.Button btn_editLogin;
        private System.Windows.Forms.Button btn_saveLogin;
        private System.Windows.Forms.DataGridView dg_loginPage;
        private System.Windows.Forms.Button btn_logoutLogin;
        private System.Windows.Forms.Button btn_clearLogin;
        private System.Windows.Forms.Button btn_deleteLogin;
        private System.Windows.Forms.Label lbl_taxValueItem;
        private System.Windows.Forms.TextBox txt_taxValueItem;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label lbl_salesType;
        private System.Windows.Forms.Label lbl_invoice;
        private System.Windows.Forms.TextBox txt_addressInvoice;
        private System.Windows.Forms.Label lbl_gstNoInvoice;
        private System.Windows.Forms.TextBox txt_customerNameInvoice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_mobileInvoice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_customerIdInvoice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtp_billDateInvoice;
        private System.Windows.Forms.Label lbl_billDate;
        private System.Windows.Forms.TextBox txt_billNoInvoice;
        private System.Windows.Forms.Label lbl_billNo;
        private System.Windows.Forms.ComboBox cb_salesType;
        private System.Windows.Forms.Label lbl_stateCodeInvoice;
        private System.Windows.Forms.TextBox txt_stateInvoice;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_phoneInvoice;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_emailInvoice;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_gstNoInvoice;
        private System.Windows.Forms.TextBox txt_stateCodeInvoice;
        private System.Windows.Forms.Panel pn_itemDetails;
        private System.Windows.Forms.Label lbl_taxInvoice;
        private System.Windows.Forms.TextBox txt_taxInvoiceBill;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_itemCodeInvoice;
        private System.Windows.Forms.Label lbl_itemDescription;
        private System.Windows.Forms.TextBox txt_itemNameInvoice;
        private System.Windows.Forms.Label lbl_quantityInvoice;
        private System.Windows.Forms.TextBox txt_quantityInvoice;
        private System.Windows.Forms.Label lbl_discountInvoice;
        private System.Windows.Forms.Label lbl_totalInvoice;
        private System.Windows.Forms.TextBox txt_discountInvoice;
        private System.Windows.Forms.Label lbl_priceInvoice;
        private System.Windows.Forms.TextBox txt_priceInvoice;
        private System.Windows.Forms.TextBox txt_totalAmountInvoice;
        private System.Windows.Forms.Button btn_refreshInvoice;
        private System.Windows.Forms.Button btn_addInvoice;
        private System.Windows.Forms.Button btn_logoutInvoice;
        private System.Windows.Forms.Button btn_clearInvoice;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_deleteInvoice;
        private System.Windows.Forms.Button btn_editInvoice;
        private System.Windows.Forms.Button btn_saveInvoice;
        private System.Windows.Forms.Button btn_newInvoice;
        private System.Windows.Forms.TextBox txt_grandTotalInvoice;
        private System.Windows.Forms.Label lbl_grandTotalAmount;
        private System.Windows.Forms.TextBox txt_totalDiscountInvoice;
        private System.Windows.Forms.Label lbl_totalDiscount;
        private System.Windows.Forms.TextBox txt_totalTaxInvoice;
        private System.Windows.Forms.Label lbl_totalGstInvoice;
        private System.Windows.Forms.DataGridView dg_invoiceView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Discount;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaxValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total;
        private System.Windows.Forms.DataGridViewButtonColumn Edit;
        private System.Windows.Forms.DataGridViewButtonColumn Delete;
    }
}