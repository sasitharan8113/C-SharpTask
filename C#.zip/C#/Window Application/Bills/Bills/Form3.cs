﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bills
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection(@"Data Source=localhost;Initial Catalog=dbBank;Integrated Security=True");

        int a, b, c;

        private void btn_receiptNewButton_Click(object sender, EventArgs e)
        {
            string regNumber1;
            connection.Open();
            clear();
            string query = "select receipt_id from tb_receiptBills order by receipt_id desc";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();


            if (reader.Read())
            {
                int id = int.Parse(reader[0].ToString()) + 1;
                regNumber1 = id.ToString("0");
            }
            else if (Convert.IsDBNull(reader))
            {
                regNumber1 = "1";
            }
            else
            {
                regNumber1 = "1";
            }
            txt_receiptId.Text = regNumber1.ToString();
            txt_receiptId.Focus();
            connection.Close();
        }

        public void clear()
        {
            txt_receiptId.Clear();
            dtp_receiptDate.Refresh();
            txt_receiptCustomerCode.Clear();
            txt_receiptCustomerName.Clear();
            txt_receiptAmountReceived.Clear();
            txt_receiptBalance.Clear();
            txt_receiptBankAccount.Clear();
            txt_receiptBankName.Clear();
            txt_receiptChequeNo.Clear();
            txt_receiptDescription.Clear();
            cb_paymentType.Text = string.Empty;
        }

        private void btn_receiptLogoutButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txt_receiptId_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void dtp_receiptDate_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        public void details()
        {

            string query = "select customername,totalGrandAmount from tb_invoiceBills where customerId=@customerId";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@customerId", txt_receiptCustomerCode.Text);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                txt_receiptCustomerName.Text = reader["customername"].ToString();
                txt_receiptBalance.Text = reader["totalGrandAmount"].ToString();
            }
            else
            {
                txt_receiptCustomerName.Clear();
            }
            reader.Close();
            connection.Close();
            txt_receiptAmountReceived.Focus();
        }


        private void txt_receiptCustomerCode_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                details();
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void cb_paymentType_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void txt_receiptBankAccount_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void txt_receiptBankName_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void txt_receiptChequeNo_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void txt_receiptDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void btn_receiptClearButton_Click(object sender, EventArgs e)
        {
            clear();
            txt_receiptBankAccount.Visible = true;
            txt_receiptBankName.Visible = true;
            txt_receiptChequeNo.Visible = true;
        }

        private void cb_paymentType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cb_paymentType.SelectedIndex==0)
            {
                txt_receiptBankAccount.Visible= false;
                txt_receiptBankName.Visible= false;
                txt_receiptChequeNo.Visible= false;
            }
            else
            {
                txt_receiptBankAccount.Visible= true;
                txt_receiptBankName.Visible= true;
                txt_receiptChequeNo.Visible = true;
            }
        }

        private void btn_receiptDeleteButton_Click(object sender, EventArgs e)
        {
            connection.Open();
            a = int.Parse(txt_receiptBalance.Text);
            b = int.Parse(txt_receiptAmountReceived.Text);
            c = a + b;
            txt_receiptBalance.Text = c.ToString();

            string query = "insert into tb_receiptBills values" +
                "(@receipt_id,@receipt_date,@customer_code,@customer_name,@amount_received,@balance,@payment_type,@bank_account,@bank_name,@cheque_no,@description)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@receipt_id", txt_receiptId.Text);
            command.Parameters.AddWithValue("@receipt_date", dtp_receiptDate.Text);
            command.Parameters.AddWithValue("@customer_code", txt_receiptCustomerCode.Text);
            command.Parameters.AddWithValue("@customer_name", txt_receiptCustomerName.Text);
            command.Parameters.AddWithValue("@amount_received", txt_receiptAmountReceived.Text);
            command.Parameters.AddWithValue("@balance", txt_receiptBalance.Text);
            command.Parameters.AddWithValue("@payment_type", cb_paymentType.Text);
            command.Parameters.AddWithValue("@bank_account", txt_receiptBankAccount.Text);
            command.Parameters.AddWithValue("@bank_name", txt_receiptBankName.Text);
            command.Parameters.AddWithValue("@cheque_no", txt_receiptChequeNo.Text);
            command.Parameters.AddWithValue("@description", txt_receiptDescription.Text);
            command.ExecuteNonQuery();

            string query1 = "update tb_invoiceBills set totalGrandAmount=@totalGrandAmount where customerId=@customerId";
            SqlCommand command1 = new SqlCommand(query1, connection);
            command1.Parameters.AddWithValue("@totalGrandAmount", txt_receiptBalance.Text);
            command1.Parameters.AddWithValue("@customerId", txt_receiptCustomerCode.Text);
            command1.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Refund data is successfully");
        }

        private void btn_receiptEditButton_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "update tb_receiptBills set" +
                " receipt_date=@receipt_date,customer_name=@customer_name,description=@description";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@receipt_date",dtp_receiptDate.Text);
            command.Parameters.AddWithValue("@customer_name",txt_receiptCustomerName.Text);
            command.Parameters.AddWithValue("@description",txt_receiptDescription.Text);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("update data is successfully");
        }

        private void txt_receiptAmountReceived_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void btn_receiptSaveButton_Click(object sender, EventArgs e)
        {
            connection.Open();
            a = int.Parse(txt_receiptBalance.Text);
            b = int.Parse(txt_receiptAmountReceived.Text);
            c = a - b;
            txt_receiptBalance.Text = c.ToString();
            string query = "insert into tb_receiptBills values" +
                "(@receipt_id,@receipt_date,@customer_code,@customer_name,@amount_received,@balance,@payment_type,@bank_account,@bank_name,@cheque_no,@description)";
            SqlCommand command=new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@receipt_id",txt_receiptId.Text);
            command.Parameters.AddWithValue("@receipt_date", dtp_receiptDate.Text);
            command.Parameters.AddWithValue("@customer_code",txt_receiptCustomerCode.Text);
            command.Parameters.AddWithValue("@customer_name",txt_receiptCustomerName.Text);
            command.Parameters.AddWithValue("@amount_received",txt_receiptAmountReceived.Text);
            command.Parameters.AddWithValue("@balance",txt_receiptBalance.Text);
            command.Parameters.AddWithValue("@payment_type", cb_paymentType.Text);
            command.Parameters.AddWithValue("@bank_account",txt_receiptBankAccount.Text);
            command.Parameters.AddWithValue("@bank_name",txt_receiptBankName.Text);
            command.Parameters.AddWithValue("@cheque_no",txt_receiptChequeNo.Text);
            command.Parameters.AddWithValue("@description",txt_receiptDescription.Text);
            command.ExecuteNonQuery();

            string query1 = "update tb_invoiceBills set totalGrandAmount=@totalGrandAmount where customerId=@customerId";
            SqlCommand command1 = new SqlCommand(query1, connection);
            command1.Parameters.AddWithValue("@totalGrandAmount", txt_receiptBalance.Text);
            command1.Parameters.AddWithValue("@customerId", txt_receiptCustomerCode.Text);
            command1.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Insert Data is successfully");
        }
    }
}
