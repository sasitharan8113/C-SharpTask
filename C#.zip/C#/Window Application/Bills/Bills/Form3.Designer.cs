﻿namespace Bills
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_receiptForm = new System.Windows.Forms.Label();
            this.lbl_receiptId = new System.Windows.Forms.Label();
            this.txt_receiptId = new System.Windows.Forms.TextBox();
            this.lbl_receiptDate = new System.Windows.Forms.Label();
            this.dtp_receiptDate = new System.Windows.Forms.DateTimePicker();
            this.lbl_receiptCustomerCode = new System.Windows.Forms.Label();
            this.txt_receiptCustomerCode = new System.Windows.Forms.TextBox();
            this.txt_receiptCustomerName = new System.Windows.Forms.TextBox();
            this.lbl_receiptCustomerName = new System.Windows.Forms.Label();
            this.lbl_receiptAmountReceived = new System.Windows.Forms.Label();
            this.txt_receiptAmountReceived = new System.Windows.Forms.TextBox();
            this.lbl_receiptBalance = new System.Windows.Forms.Label();
            this.txt_receiptBalance = new System.Windows.Forms.TextBox();
            this.gb_paymentMethod = new System.Windows.Forms.GroupBox();
            this.txt_receiptDescription = new System.Windows.Forms.TextBox();
            this.lbl_receiptDescription = new System.Windows.Forms.Label();
            this.txt_receiptChequeNo = new System.Windows.Forms.TextBox();
            this.lbl_receiptChequeNo = new System.Windows.Forms.Label();
            this.txt_receiptBankName = new System.Windows.Forms.TextBox();
            this.lbl_receiptBankName = new System.Windows.Forms.Label();
            this.txt_receiptBankAccount = new System.Windows.Forms.TextBox();
            this.lbl_receiptBankAccount = new System.Windows.Forms.Label();
            this.cb_paymentType = new System.Windows.Forms.ComboBox();
            this.lbl_receiptPaymentType = new System.Windows.Forms.Label();
            this.btn_receiptNewButton = new System.Windows.Forms.Button();
            this.btn_receiptSaveButton = new System.Windows.Forms.Button();
            this.btn_receiptEditButton = new System.Windows.Forms.Button();
            this.btn_receiptDeleteButton = new System.Windows.Forms.Button();
            this.btn_receiptClearButton = new System.Windows.Forms.Button();
            this.btn_receiptLogoutButton = new System.Windows.Forms.Button();
            this.gb_paymentMethod.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_receiptForm
            // 
            this.lbl_receiptForm.AutoSize = true;
            this.lbl_receiptForm.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptForm.Location = new System.Drawing.Point(937, 44);
            this.lbl_receiptForm.Name = "lbl_receiptForm";
            this.lbl_receiptForm.Size = new System.Drawing.Size(228, 41);
            this.lbl_receiptForm.TabIndex = 0;
            this.lbl_receiptForm.Text = "Receipt Form";
            // 
            // lbl_receiptId
            // 
            this.lbl_receiptId.AutoSize = true;
            this.lbl_receiptId.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptId.Location = new System.Drawing.Point(64, 149);
            this.lbl_receiptId.Name = "lbl_receiptId";
            this.lbl_receiptId.Size = new System.Drawing.Size(137, 33);
            this.lbl_receiptId.TabIndex = 1;
            this.lbl_receiptId.Text = "Receipt Id:";
            // 
            // txt_receiptId
            // 
            this.txt_receiptId.Location = new System.Drawing.Point(310, 156);
            this.txt_receiptId.Name = "txt_receiptId";
            this.txt_receiptId.Size = new System.Drawing.Size(169, 26);
            this.txt_receiptId.TabIndex = 1;
            this.txt_receiptId.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_receiptId_KeyUp);
            // 
            // lbl_receiptDate
            // 
            this.lbl_receiptDate.AutoSize = true;
            this.lbl_receiptDate.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptDate.Location = new System.Drawing.Point(527, 149);
            this.lbl_receiptDate.Name = "lbl_receiptDate";
            this.lbl_receiptDate.Size = new System.Drawing.Size(167, 33);
            this.lbl_receiptDate.TabIndex = 3;
            this.lbl_receiptDate.Text = "Receipt Date:";
            // 
            // dtp_receiptDate
            // 
            this.dtp_receiptDate.CustomFormat = "dd-MM-yyyy";
            this.dtp_receiptDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_receiptDate.Location = new System.Drawing.Point(730, 154);
            this.dtp_receiptDate.Name = "dtp_receiptDate";
            this.dtp_receiptDate.Size = new System.Drawing.Size(185, 26);
            this.dtp_receiptDate.TabIndex = 2;
            this.dtp_receiptDate.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dtp_receiptDate_KeyUp);
            // 
            // lbl_receiptCustomerCode
            // 
            this.lbl_receiptCustomerCode.AutoSize = true;
            this.lbl_receiptCustomerCode.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptCustomerCode.Location = new System.Drawing.Point(969, 149);
            this.lbl_receiptCustomerCode.Name = "lbl_receiptCustomerCode";
            this.lbl_receiptCustomerCode.Size = new System.Drawing.Size(196, 33);
            this.lbl_receiptCustomerCode.TabIndex = 4;
            this.lbl_receiptCustomerCode.Text = "Customer Code:";
            // 
            // txt_receiptCustomerCode
            // 
            this.txt_receiptCustomerCode.AutoCompleteCustomSource.AddRange(new string[] {
            "301",
            "302"});
            this.txt_receiptCustomerCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_receiptCustomerCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_receiptCustomerCode.Location = new System.Drawing.Point(1203, 156);
            this.txt_receiptCustomerCode.Name = "txt_receiptCustomerCode";
            this.txt_receiptCustomerCode.Size = new System.Drawing.Size(169, 26);
            this.txt_receiptCustomerCode.TabIndex = 3;
            this.txt_receiptCustomerCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_receiptCustomerCode_KeyUp);
            // 
            // txt_receiptCustomerName
            // 
            this.txt_receiptCustomerName.Location = new System.Drawing.Point(1653, 154);
            this.txt_receiptCustomerName.Name = "txt_receiptCustomerName";
            this.txt_receiptCustomerName.Size = new System.Drawing.Size(169, 26);
            this.txt_receiptCustomerName.TabIndex = 17;
            // 
            // lbl_receiptCustomerName
            // 
            this.lbl_receiptCustomerName.AutoSize = true;
            this.lbl_receiptCustomerName.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptCustomerName.Location = new System.Drawing.Point(1423, 149);
            this.lbl_receiptCustomerName.Name = "lbl_receiptCustomerName";
            this.lbl_receiptCustomerName.Size = new System.Drawing.Size(201, 33);
            this.lbl_receiptCustomerName.TabIndex = 6;
            this.lbl_receiptCustomerName.Text = "Customer Name:";
            // 
            // lbl_receiptAmountReceived
            // 
            this.lbl_receiptAmountReceived.AutoSize = true;
            this.lbl_receiptAmountReceived.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptAmountReceived.Location = new System.Drawing.Point(64, 224);
            this.lbl_receiptAmountReceived.Name = "lbl_receiptAmountReceived";
            this.lbl_receiptAmountReceived.Size = new System.Drawing.Size(220, 33);
            this.lbl_receiptAmountReceived.TabIndex = 8;
            this.lbl_receiptAmountReceived.Text = "Amount Received:";
            // 
            // txt_receiptAmountReceived
            // 
            this.txt_receiptAmountReceived.Location = new System.Drawing.Point(310, 231);
            this.txt_receiptAmountReceived.Name = "txt_receiptAmountReceived";
            this.txt_receiptAmountReceived.Size = new System.Drawing.Size(169, 26);
            this.txt_receiptAmountReceived.TabIndex = 4;
            this.txt_receiptAmountReceived.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_receiptAmountReceived_KeyUp);
            // 
            // lbl_receiptBalance
            // 
            this.lbl_receiptBalance.AutoSize = true;
            this.lbl_receiptBalance.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptBalance.Location = new System.Drawing.Point(527, 224);
            this.lbl_receiptBalance.Name = "lbl_receiptBalance";
            this.lbl_receiptBalance.Size = new System.Drawing.Size(112, 33);
            this.lbl_receiptBalance.TabIndex = 10;
            this.lbl_receiptBalance.Text = "Balance:";
            // 
            // txt_receiptBalance
            // 
            this.txt_receiptBalance.Location = new System.Drawing.Point(729, 231);
            this.txt_receiptBalance.Name = "txt_receiptBalance";
            this.txt_receiptBalance.Size = new System.Drawing.Size(185, 26);
            this.txt_receiptBalance.TabIndex = 11;
            this.txt_receiptBalance.TabStop = false;
            // 
            // gb_paymentMethod
            // 
            this.gb_paymentMethod.BackColor = System.Drawing.SystemColors.Control;
            this.gb_paymentMethod.Controls.Add(this.txt_receiptDescription);
            this.gb_paymentMethod.Controls.Add(this.lbl_receiptDescription);
            this.gb_paymentMethod.Controls.Add(this.txt_receiptChequeNo);
            this.gb_paymentMethod.Controls.Add(this.lbl_receiptChequeNo);
            this.gb_paymentMethod.Controls.Add(this.txt_receiptBankName);
            this.gb_paymentMethod.Controls.Add(this.lbl_receiptBankName);
            this.gb_paymentMethod.Controls.Add(this.txt_receiptBankAccount);
            this.gb_paymentMethod.Controls.Add(this.lbl_receiptBankAccount);
            this.gb_paymentMethod.Controls.Add(this.cb_paymentType);
            this.gb_paymentMethod.Controls.Add(this.lbl_receiptPaymentType);
            this.gb_paymentMethod.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_paymentMethod.ForeColor = System.Drawing.Color.Red;
            this.gb_paymentMethod.Location = new System.Drawing.Point(70, 320);
            this.gb_paymentMethod.Name = "gb_paymentMethod";
            this.gb_paymentMethod.Size = new System.Drawing.Size(1382, 232);
            this.gb_paymentMethod.TabIndex = 12;
            this.gb_paymentMethod.TabStop = false;
            this.gb_paymentMethod.Text = "Payment Type";
            // 
            // txt_receiptDescription
            // 
            this.txt_receiptDescription.Location = new System.Drawing.Point(659, 149);
            this.txt_receiptDescription.Multiline = true;
            this.txt_receiptDescription.Name = "txt_receiptDescription";
            this.txt_receiptDescription.Size = new System.Drawing.Size(256, 51);
            this.txt_receiptDescription.TabIndex = 9;
            this.txt_receiptDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_receiptDescription_KeyUp);
            // 
            // lbl_receiptDescription
            // 
            this.lbl_receiptDescription.AutoSize = true;
            this.lbl_receiptDescription.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptDescription.ForeColor = System.Drawing.Color.Black;
            this.lbl_receiptDescription.Location = new System.Drawing.Point(456, 149);
            this.lbl_receiptDescription.Name = "lbl_receiptDescription";
            this.lbl_receiptDescription.Size = new System.Drawing.Size(153, 33);
            this.lbl_receiptDescription.TabIndex = 17;
            this.lbl_receiptDescription.Text = "Description:";
            // 
            // txt_receiptChequeNo
            // 
            this.txt_receiptChequeNo.Location = new System.Drawing.Point(219, 146);
            this.txt_receiptChequeNo.Name = "txt_receiptChequeNo";
            this.txt_receiptChequeNo.Size = new System.Drawing.Size(213, 40);
            this.txt_receiptChequeNo.TabIndex = 8;
            this.txt_receiptChequeNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_receiptChequeNo_KeyUp);
            // 
            // lbl_receiptChequeNo
            // 
            this.lbl_receiptChequeNo.AutoSize = true;
            this.lbl_receiptChequeNo.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptChequeNo.ForeColor = System.Drawing.Color.Black;
            this.lbl_receiptChequeNo.Location = new System.Drawing.Point(36, 149);
            this.lbl_receiptChequeNo.Name = "lbl_receiptChequeNo";
            this.lbl_receiptChequeNo.Size = new System.Drawing.Size(149, 33);
            this.lbl_receiptChequeNo.TabIndex = 15;
            this.lbl_receiptChequeNo.Text = "Cheque No:";
            // 
            // txt_receiptBankName
            // 
            this.txt_receiptBankName.Location = new System.Drawing.Point(1073, 72);
            this.txt_receiptBankName.Name = "txt_receiptBankName";
            this.txt_receiptBankName.Size = new System.Drawing.Size(196, 40);
            this.txt_receiptBankName.TabIndex = 7;
            this.txt_receiptBankName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_receiptBankName_KeyUp);
            // 
            // lbl_receiptBankName
            // 
            this.lbl_receiptBankName.AutoSize = true;
            this.lbl_receiptBankName.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptBankName.ForeColor = System.Drawing.Color.Black;
            this.lbl_receiptBankName.Location = new System.Drawing.Point(895, 75);
            this.lbl_receiptBankName.Name = "lbl_receiptBankName";
            this.lbl_receiptBankName.Size = new System.Drawing.Size(153, 33);
            this.lbl_receiptBankName.TabIndex = 13;
            this.lbl_receiptBankName.Text = "Bank Name:";
            // 
            // txt_receiptBankAccount
            // 
            this.txt_receiptBankAccount.Location = new System.Drawing.Point(659, 68);
            this.txt_receiptBankAccount.Name = "txt_receiptBankAccount";
            this.txt_receiptBankAccount.Size = new System.Drawing.Size(202, 40);
            this.txt_receiptBankAccount.TabIndex = 6;
            this.txt_receiptBankAccount.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_receiptBankAccount_KeyUp);
            // 
            // lbl_receiptBankAccount
            // 
            this.lbl_receiptBankAccount.AutoSize = true;
            this.lbl_receiptBankAccount.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptBankAccount.ForeColor = System.Drawing.Color.Black;
            this.lbl_receiptBankAccount.Location = new System.Drawing.Point(456, 75);
            this.lbl_receiptBankAccount.Name = "lbl_receiptBankAccount";
            this.lbl_receiptBankAccount.Size = new System.Drawing.Size(180, 33);
            this.lbl_receiptBankAccount.TabIndex = 11;
            this.lbl_receiptBankAccount.Text = "Bank Account:";
            // 
            // cb_paymentType
            // 
            this.cb_paymentType.AutoCompleteCustomSource.AddRange(new string[] {
            "Cash Payment",
            "Bank Payment"});
            this.cb_paymentType.FormattingEnabled = true;
            this.cb_paymentType.Items.AddRange(new object[] {
            "Cash Payment",
            "Bank Payment"});
            this.cb_paymentType.Location = new System.Drawing.Point(219, 72);
            this.cb_paymentType.Name = "cb_paymentType";
            this.cb_paymentType.Size = new System.Drawing.Size(213, 41);
            this.cb_paymentType.TabIndex = 5;
            this.cb_paymentType.SelectedIndexChanged += new System.EventHandler(this.cb_paymentType_SelectedIndexChanged);
            this.cb_paymentType.KeyUp += new System.Windows.Forms.KeyEventHandler(this.cb_paymentType_KeyUp);
            // 
            // lbl_receiptPaymentType
            // 
            this.lbl_receiptPaymentType.AutoSize = true;
            this.lbl_receiptPaymentType.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_receiptPaymentType.ForeColor = System.Drawing.Color.Black;
            this.lbl_receiptPaymentType.Location = new System.Drawing.Point(36, 75);
            this.lbl_receiptPaymentType.Name = "lbl_receiptPaymentType";
            this.lbl_receiptPaymentType.Size = new System.Drawing.Size(177, 33);
            this.lbl_receiptPaymentType.TabIndex = 9;
            this.lbl_receiptPaymentType.Text = "Payment Type:";
            // 
            // btn_receiptNewButton
            // 
            this.btn_receiptNewButton.BackColor = System.Drawing.Color.Blue;
            this.btn_receiptNewButton.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_receiptNewButton.ForeColor = System.Drawing.Color.White;
            this.btn_receiptNewButton.Location = new System.Drawing.Point(72, 606);
            this.btn_receiptNewButton.Name = "btn_receiptNewButton";
            this.btn_receiptNewButton.Size = new System.Drawing.Size(140, 58);
            this.btn_receiptNewButton.TabIndex = 13;
            this.btn_receiptNewButton.Text = "New";
            this.btn_receiptNewButton.UseVisualStyleBackColor = false;
            this.btn_receiptNewButton.Click += new System.EventHandler(this.btn_receiptNewButton_Click);
            // 
            // btn_receiptSaveButton
            // 
            this.btn_receiptSaveButton.BackColor = System.Drawing.Color.ForestGreen;
            this.btn_receiptSaveButton.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_receiptSaveButton.ForeColor = System.Drawing.Color.Black;
            this.btn_receiptSaveButton.Location = new System.Drawing.Point(288, 606);
            this.btn_receiptSaveButton.Name = "btn_receiptSaveButton";
            this.btn_receiptSaveButton.Size = new System.Drawing.Size(143, 58);
            this.btn_receiptSaveButton.TabIndex = 10;
            this.btn_receiptSaveButton.TabStop = false;
            this.btn_receiptSaveButton.Text = "Save";
            this.btn_receiptSaveButton.UseVisualStyleBackColor = false;
            this.btn_receiptSaveButton.Click += new System.EventHandler(this.btn_receiptSaveButton_Click);
            // 
            // btn_receiptEditButton
            // 
            this.btn_receiptEditButton.BackColor = System.Drawing.Color.Turquoise;
            this.btn_receiptEditButton.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_receiptEditButton.ForeColor = System.Drawing.Color.Black;
            this.btn_receiptEditButton.Location = new System.Drawing.Point(510, 606);
            this.btn_receiptEditButton.Name = "btn_receiptEditButton";
            this.btn_receiptEditButton.Size = new System.Drawing.Size(138, 58);
            this.btn_receiptEditButton.TabIndex = 15;
            this.btn_receiptEditButton.Text = "Edit";
            this.btn_receiptEditButton.UseVisualStyleBackColor = false;
            this.btn_receiptEditButton.Click += new System.EventHandler(this.btn_receiptEditButton_Click);
            // 
            // btn_receiptDeleteButton
            // 
            this.btn_receiptDeleteButton.BackColor = System.Drawing.Color.Red;
            this.btn_receiptDeleteButton.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_receiptDeleteButton.ForeColor = System.Drawing.Color.Black;
            this.btn_receiptDeleteButton.Location = new System.Drawing.Point(729, 606);
            this.btn_receiptDeleteButton.Name = "btn_receiptDeleteButton";
            this.btn_receiptDeleteButton.Size = new System.Drawing.Size(137, 58);
            this.btn_receiptDeleteButton.TabIndex = 16;
            this.btn_receiptDeleteButton.Text = "Delete";
            this.btn_receiptDeleteButton.UseVisualStyleBackColor = false;
            this.btn_receiptDeleteButton.Click += new System.EventHandler(this.btn_receiptDeleteButton_Click);
            // 
            // btn_receiptClearButton
            // 
            this.btn_receiptClearButton.BackColor = System.Drawing.Color.Silver;
            this.btn_receiptClearButton.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_receiptClearButton.ForeColor = System.Drawing.Color.Black;
            this.btn_receiptClearButton.Location = new System.Drawing.Point(953, 606);
            this.btn_receiptClearButton.Name = "btn_receiptClearButton";
            this.btn_receiptClearButton.Size = new System.Drawing.Size(135, 58);
            this.btn_receiptClearButton.TabIndex = 17;
            this.btn_receiptClearButton.Text = "Clear";
            this.btn_receiptClearButton.UseVisualStyleBackColor = false;
            this.btn_receiptClearButton.Click += new System.EventHandler(this.btn_receiptClearButton_Click);
            // 
            // btn_receiptLogoutButton
            // 
            this.btn_receiptLogoutButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_receiptLogoutButton.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_receiptLogoutButton.ForeColor = System.Drawing.Color.Black;
            this.btn_receiptLogoutButton.Location = new System.Drawing.Point(1177, 606);
            this.btn_receiptLogoutButton.Name = "btn_receiptLogoutButton";
            this.btn_receiptLogoutButton.Size = new System.Drawing.Size(151, 58);
            this.btn_receiptLogoutButton.TabIndex = 18;
            this.btn_receiptLogoutButton.Text = "Logout";
            this.btn_receiptLogoutButton.UseVisualStyleBackColor = false;
            this.btn_receiptLogoutButton.Click += new System.EventHandler(this.btn_receiptLogoutButton_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.btn_receiptLogoutButton);
            this.Controls.Add(this.btn_receiptClearButton);
            this.Controls.Add(this.btn_receiptDeleteButton);
            this.Controls.Add(this.btn_receiptEditButton);
            this.Controls.Add(this.btn_receiptSaveButton);
            this.Controls.Add(this.btn_receiptNewButton);
            this.Controls.Add(this.gb_paymentMethod);
            this.Controls.Add(this.txt_receiptBalance);
            this.Controls.Add(this.lbl_receiptBalance);
            this.Controls.Add(this.txt_receiptAmountReceived);
            this.Controls.Add(this.lbl_receiptAmountReceived);
            this.Controls.Add(this.txt_receiptCustomerName);
            this.Controls.Add(this.lbl_receiptCustomerName);
            this.Controls.Add(this.txt_receiptCustomerCode);
            this.Controls.Add(this.lbl_receiptCustomerCode);
            this.Controls.Add(this.dtp_receiptDate);
            this.Controls.Add(this.lbl_receiptDate);
            this.Controls.Add(this.txt_receiptId);
            this.Controls.Add(this.lbl_receiptId);
            this.Controls.Add(this.lbl_receiptForm);
            this.Name = "Form3";
            this.Text = "Form3";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.gb_paymentMethod.ResumeLayout(false);
            this.gb_paymentMethod.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_receiptForm;
        private System.Windows.Forms.Label lbl_receiptId;
        private System.Windows.Forms.TextBox txt_receiptId;
        private System.Windows.Forms.Label lbl_receiptDate;
        private System.Windows.Forms.DateTimePicker dtp_receiptDate;
        private System.Windows.Forms.Label lbl_receiptCustomerCode;
        private System.Windows.Forms.TextBox txt_receiptCustomerCode;
        private System.Windows.Forms.TextBox txt_receiptCustomerName;
        private System.Windows.Forms.Label lbl_receiptCustomerName;
        private System.Windows.Forms.Label lbl_receiptAmountReceived;
        private System.Windows.Forms.TextBox txt_receiptAmountReceived;
        private System.Windows.Forms.Label lbl_receiptBalance;
        private System.Windows.Forms.TextBox txt_receiptBalance;
        private System.Windows.Forms.GroupBox gb_paymentMethod;
        private System.Windows.Forms.ComboBox cb_paymentType;
        private System.Windows.Forms.Label lbl_receiptPaymentType;
        private System.Windows.Forms.TextBox txt_receiptChequeNo;
        private System.Windows.Forms.Label lbl_receiptChequeNo;
        private System.Windows.Forms.TextBox txt_receiptBankName;
        private System.Windows.Forms.Label lbl_receiptBankName;
        private System.Windows.Forms.TextBox txt_receiptBankAccount;
        private System.Windows.Forms.Label lbl_receiptBankAccount;
        private System.Windows.Forms.TextBox txt_receiptDescription;
        private System.Windows.Forms.Label lbl_receiptDescription;
        private System.Windows.Forms.Button btn_receiptNewButton;
        private System.Windows.Forms.Button btn_receiptSaveButton;
        private System.Windows.Forms.Button btn_receiptEditButton;
        private System.Windows.Forms.Button btn_receiptDeleteButton;
        private System.Windows.Forms.Button btn_receiptClearButton;
        private System.Windows.Forms.Button btn_receiptLogoutButton;
    }
}