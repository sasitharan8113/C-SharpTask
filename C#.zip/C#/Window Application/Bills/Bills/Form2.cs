﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bills
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection connection = new SqlConnection(@"Data Source=localhost;Initial Catalog=dbBank;Integrated Security=True");
        public int userNum;

        private void btn_showInvoice_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = dg_findAll.SelectedRows[0];
            userNum = Convert.ToInt32(selectedRow.Cells["BillNo"].Value.ToString());
            MessageBox.Show(userNum.ToString());
            this.DialogResult = DialogResult.OK;
        }

        private void btn_findAllInvoice_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "select id,billNo,billDate,itemCode,totalAmount from tb_originalItemInvoice";
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dg_findAll.DataSource = table;
            connection.Close();
        }
    }
}
