﻿namespace Bills
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_invoice = new System.Windows.Forms.Label();
            this.txt_invoiceBillNumber = new System.Windows.Forms.TextBox();
            this.lbl_billNo = new System.Windows.Forms.Label();
            this.lbl_billDate = new System.Windows.Forms.Label();
            this.dtp_invoiceBillDate = new System.Windows.Forms.DateTimePicker();
            this.lbl_customerId = new System.Windows.Forms.Label();
            this.txt_invoiceCustomerId = new System.Windows.Forms.TextBox();
            this.txt_invoiceCustomerName = new System.Windows.Forms.TextBox();
            this.lbl_invoiceCustomerId = new System.Windows.Forms.Label();
            this.txt_invoiceState = new System.Windows.Forms.TextBox();
            this.lbl_invoiceState = new System.Windows.Forms.Label();
            this.txt_invoiceGstNo = new System.Windows.Forms.TextBox();
            this.lbl_gstNoInvoice = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_invoicePhone = new System.Windows.Forms.TextBox();
            this.lbl_invoicePhone = new System.Windows.Forms.Label();
            this.txt_invoiceMobile = new System.Windows.Forms.TextBox();
            this.txt_invoiceEmail = new System.Windows.Forms.TextBox();
            this.txt_invoiceAddress = new System.Windows.Forms.TextBox();
            this.lbl_invoiceAddress = new System.Windows.Forms.Label();
            this.lbl_invoiceEmail = new System.Windows.Forms.Label();
            this.txt_invoiceStateCode = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pn_itemDetails = new System.Windows.Forms.Panel();
            this.txt_invoiceTaxValue = new System.Windows.Forms.TextBox();
            this.lbl_taxInvoice = new System.Windows.Forms.Label();
            this.txt_taxInvoiceBill = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_itemCodeInvoice = new System.Windows.Forms.TextBox();
            this.lbl_itemDescription = new System.Windows.Forms.Label();
            this.txt_itemNameInvoice = new System.Windows.Forms.TextBox();
            this.lbl_quantityInvoice = new System.Windows.Forms.Label();
            this.txt_quantityInvoice = new System.Windows.Forms.TextBox();
            this.lbl_discountInvoice = new System.Windows.Forms.Label();
            this.lbl_totalInvoice = new System.Windows.Forms.Label();
            this.txt_discountInvoice = new System.Windows.Forms.TextBox();
            this.lbl_priceInvoice = new System.Windows.Forms.Label();
            this.txt_priceInvoice = new System.Windows.Forms.TextBox();
            this.txt_totalAmountInvoice = new System.Windows.Forms.TextBox();
            this.btn_refreshInvoice = new System.Windows.Forms.Button();
            this.btn_addInvoice = new System.Windows.Forms.Button();
            this.dg_dataView = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Discount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TaxValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Edit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.txt_invoiceGrandTotal = new System.Windows.Forms.TextBox();
            this.lbl_invoiceGrandAmount = new System.Windows.Forms.Label();
            this.txt_invoiceTotalTax = new System.Windows.Forms.TextBox();
            this.lbl_invoiceTotalTax = new System.Windows.Forms.Label();
            this.txt_invoiceTotalAmount = new System.Windows.Forms.TextBox();
            this.lbl_totalAmount = new System.Windows.Forms.Label();
            this.btn_invoiceLogoutButton = new System.Windows.Forms.Button();
            this.btn_invoiceClearButton = new System.Windows.Forms.Button();
            this.btn_invoiceFindButton = new System.Windows.Forms.Button();
            this.btn_invoiceDeleteButton = new System.Windows.Forms.Button();
            this.btn_invoiceEditButton = new System.Windows.Forms.Button();
            this.btn_invoiceSaveButton = new System.Windows.Forms.Button();
            this.btn_invoiceNewButton = new System.Windows.Forms.Button();
            this.btn_invoiceReceiptButton = new System.Windows.Forms.Button();
            this.pn_itemDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_dataView)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_invoice
            // 
            this.lbl_invoice.AutoSize = true;
            this.lbl_invoice.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_invoice.Location = new System.Drawing.Point(851, 26);
            this.lbl_invoice.Name = "lbl_invoice";
            this.lbl_invoice.Size = new System.Drawing.Size(222, 41);
            this.lbl_invoice.TabIndex = 2;
            this.lbl_invoice.Text = "Invoice Form";
            // 
            // txt_invoiceBillNumber
            // 
            this.txt_invoiceBillNumber.Location = new System.Drawing.Point(179, 101);
            this.txt_invoiceBillNumber.Name = "txt_invoiceBillNumber";
            this.txt_invoiceBillNumber.Size = new System.Drawing.Size(199, 26);
            this.txt_invoiceBillNumber.TabIndex = 1;
            this.txt_invoiceBillNumber.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_invoiceBillNumber_KeyUp);
            // 
            // lbl_billNo
            // 
            this.lbl_billNo.AutoSize = true;
            this.lbl_billNo.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_billNo.Location = new System.Drawing.Point(26, 96);
            this.lbl_billNo.Name = "lbl_billNo";
            this.lbl_billNo.Size = new System.Drawing.Size(107, 33);
            this.lbl_billNo.TabIndex = 78;
            this.lbl_billNo.Text = "Bill No:";
            // 
            // lbl_billDate
            // 
            this.lbl_billDate.AutoSize = true;
            this.lbl_billDate.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_billDate.Location = new System.Drawing.Point(439, 96);
            this.lbl_billDate.Name = "lbl_billDate";
            this.lbl_billDate.Size = new System.Drawing.Size(125, 33);
            this.lbl_billDate.TabIndex = 80;
            this.lbl_billDate.Text = "Bill Date:";
            // 
            // dtp_invoiceBillDate
            // 
            this.dtp_invoiceBillDate.CustomFormat = "dd-MM-yyyy";
            this.dtp_invoiceBillDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_invoiceBillDate.Location = new System.Drawing.Point(595, 101);
            this.dtp_invoiceBillDate.Name = "dtp_invoiceBillDate";
            this.dtp_invoiceBillDate.Size = new System.Drawing.Size(199, 26);
            this.dtp_invoiceBillDate.TabIndex = 2;
            this.dtp_invoiceBillDate.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dtp_invoiceBillDate_KeyUp);
            // 
            // lbl_customerId
            // 
            this.lbl_customerId.AutoSize = true;
            this.lbl_customerId.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerId.ForeColor = System.Drawing.Color.Red;
            this.lbl_customerId.Location = new System.Drawing.Point(861, 96);
            this.lbl_customerId.Name = "lbl_customerId";
            this.lbl_customerId.Size = new System.Drawing.Size(159, 33);
            this.lbl_customerId.TabIndex = 82;
            this.lbl_customerId.Text = "Customer Id:";
            // 
            // txt_invoiceCustomerId
            // 
            this.txt_invoiceCustomerId.AutoCompleteCustomSource.AddRange(new string[] {
            "301",
            "302"});
            this.txt_invoiceCustomerId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_invoiceCustomerId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_invoiceCustomerId.Location = new System.Drawing.Point(1048, 101);
            this.txt_invoiceCustomerId.Name = "txt_invoiceCustomerId";
            this.txt_invoiceCustomerId.Size = new System.Drawing.Size(199, 26);
            this.txt_invoiceCustomerId.TabIndex = 3;
            this.txt_invoiceCustomerId.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_invoiceCustomerId_KeyUp);
            // 
            // txt_invoiceCustomerName
            // 
            this.txt_invoiceCustomerName.Location = new System.Drawing.Point(1541, 103);
            this.txt_invoiceCustomerName.Name = "txt_invoiceCustomerName";
            this.txt_invoiceCustomerName.Size = new System.Drawing.Size(199, 26);
            this.txt_invoiceCustomerName.TabIndex = 85;
            this.txt_invoiceCustomerName.TabStop = false;
            // 
            // lbl_invoiceCustomerId
            // 
            this.lbl_invoiceCustomerId.AutoSize = true;
            this.lbl_invoiceCustomerId.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_invoiceCustomerId.Location = new System.Drawing.Point(1319, 94);
            this.lbl_invoiceCustomerId.Name = "lbl_invoiceCustomerId";
            this.lbl_invoiceCustomerId.Size = new System.Drawing.Size(201, 33);
            this.lbl_invoiceCustomerId.TabIndex = 84;
            this.lbl_invoiceCustomerId.Text = "Customer Name:";
            // 
            // txt_invoiceState
            // 
            this.txt_invoiceState.Location = new System.Drawing.Point(1541, 175);
            this.txt_invoiceState.Name = "txt_invoiceState";
            this.txt_invoiceState.Size = new System.Drawing.Size(199, 26);
            this.txt_invoiceState.TabIndex = 93;
            this.txt_invoiceState.TabStop = false;
            // 
            // lbl_invoiceState
            // 
            this.lbl_invoiceState.AutoSize = true;
            this.lbl_invoiceState.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_invoiceState.Location = new System.Drawing.Point(1319, 166);
            this.lbl_invoiceState.Name = "lbl_invoiceState";
            this.lbl_invoiceState.Size = new System.Drawing.Size(79, 33);
            this.lbl_invoiceState.TabIndex = 92;
            this.lbl_invoiceState.Text = "State:";
            // 
            // txt_invoiceGstNo
            // 
            this.txt_invoiceGstNo.Location = new System.Drawing.Point(1048, 173);
            this.txt_invoiceGstNo.Name = "txt_invoiceGstNo";
            this.txt_invoiceGstNo.Size = new System.Drawing.Size(199, 26);
            this.txt_invoiceGstNo.TabIndex = 88;
            this.txt_invoiceGstNo.TabStop = false;
            // 
            // lbl_gstNoInvoice
            // 
            this.lbl_gstNoInvoice.AutoSize = true;
            this.lbl_gstNoInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gstNoInvoice.Location = new System.Drawing.Point(861, 168);
            this.lbl_gstNoInvoice.Name = "lbl_gstNoInvoice";
            this.lbl_gstNoInvoice.Size = new System.Drawing.Size(114, 33);
            this.lbl_gstNoInvoice.TabIndex = 91;
            this.lbl_gstNoInvoice.Text = "GST-No:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(439, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 33);
            this.label3.TabIndex = 90;
            this.label3.Text = "Mobile:";
            // 
            // txt_invoicePhone
            // 
            this.txt_invoicePhone.Location = new System.Drawing.Point(179, 173);
            this.txt_invoicePhone.Name = "txt_invoicePhone";
            this.txt_invoicePhone.Size = new System.Drawing.Size(199, 26);
            this.txt_invoicePhone.TabIndex = 86;
            this.txt_invoicePhone.TabStop = false;
            // 
            // lbl_invoicePhone
            // 
            this.lbl_invoicePhone.AutoSize = true;
            this.lbl_invoicePhone.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_invoicePhone.Location = new System.Drawing.Point(26, 168);
            this.lbl_invoicePhone.Name = "lbl_invoicePhone";
            this.lbl_invoicePhone.Size = new System.Drawing.Size(93, 33);
            this.lbl_invoicePhone.TabIndex = 89;
            this.lbl_invoicePhone.Text = "Phone:";
            // 
            // txt_invoiceMobile
            // 
            this.txt_invoiceMobile.Location = new System.Drawing.Point(595, 175);
            this.txt_invoiceMobile.Name = "txt_invoiceMobile";
            this.txt_invoiceMobile.Size = new System.Drawing.Size(199, 26);
            this.txt_invoiceMobile.TabIndex = 94;
            this.txt_invoiceMobile.TabStop = false;
            // 
            // txt_invoiceEmail
            // 
            this.txt_invoiceEmail.Location = new System.Drawing.Point(595, 249);
            this.txt_invoiceEmail.Name = "txt_invoiceEmail";
            this.txt_invoiceEmail.Size = new System.Drawing.Size(199, 26);
            this.txt_invoiceEmail.TabIndex = 100;
            this.txt_invoiceEmail.TabStop = false;
            // 
            // txt_invoiceAddress
            // 
            this.txt_invoiceAddress.Location = new System.Drawing.Point(1048, 247);
            this.txt_invoiceAddress.Multiline = true;
            this.txt_invoiceAddress.Name = "txt_invoiceAddress";
            this.txt_invoiceAddress.Size = new System.Drawing.Size(227, 69);
            this.txt_invoiceAddress.TabIndex = 96;
            this.txt_invoiceAddress.TabStop = false;
            // 
            // lbl_invoiceAddress
            // 
            this.lbl_invoiceAddress.AutoSize = true;
            this.lbl_invoiceAddress.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_invoiceAddress.Location = new System.Drawing.Point(861, 242);
            this.lbl_invoiceAddress.Name = "lbl_invoiceAddress";
            this.lbl_invoiceAddress.Size = new System.Drawing.Size(113, 33);
            this.lbl_invoiceAddress.TabIndex = 99;
            this.lbl_invoiceAddress.Text = "Address:";
            // 
            // lbl_invoiceEmail
            // 
            this.lbl_invoiceEmail.AutoSize = true;
            this.lbl_invoiceEmail.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_invoiceEmail.Location = new System.Drawing.Point(439, 242);
            this.lbl_invoiceEmail.Name = "lbl_invoiceEmail";
            this.lbl_invoiceEmail.Size = new System.Drawing.Size(88, 33);
            this.lbl_invoiceEmail.TabIndex = 98;
            this.lbl_invoiceEmail.Text = "Email:";
            // 
            // txt_invoiceStateCode
            // 
            this.txt_invoiceStateCode.Location = new System.Drawing.Point(179, 247);
            this.txt_invoiceStateCode.Name = "txt_invoiceStateCode";
            this.txt_invoiceStateCode.Size = new System.Drawing.Size(199, 26);
            this.txt_invoiceStateCode.TabIndex = 95;
            this.txt_invoiceStateCode.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 242);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 33);
            this.label4.TabIndex = 97;
            this.label4.Text = "State-Code:";
            // 
            // pn_itemDetails
            // 
            this.pn_itemDetails.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pn_itemDetails.Controls.Add(this.txt_invoiceTaxValue);
            this.pn_itemDetails.Controls.Add(this.lbl_taxInvoice);
            this.pn_itemDetails.Controls.Add(this.txt_taxInvoiceBill);
            this.pn_itemDetails.Controls.Add(this.label6);
            this.pn_itemDetails.Controls.Add(this.txt_itemCodeInvoice);
            this.pn_itemDetails.Controls.Add(this.lbl_itemDescription);
            this.pn_itemDetails.Controls.Add(this.txt_itemNameInvoice);
            this.pn_itemDetails.Controls.Add(this.lbl_quantityInvoice);
            this.pn_itemDetails.Controls.Add(this.txt_quantityInvoice);
            this.pn_itemDetails.Controls.Add(this.lbl_discountInvoice);
            this.pn_itemDetails.Controls.Add(this.lbl_totalInvoice);
            this.pn_itemDetails.Controls.Add(this.txt_discountInvoice);
            this.pn_itemDetails.Controls.Add(this.lbl_priceInvoice);
            this.pn_itemDetails.Controls.Add(this.txt_priceInvoice);
            this.pn_itemDetails.Controls.Add(this.txt_totalAmountInvoice);
            this.pn_itemDetails.Controls.Add(this.btn_refreshInvoice);
            this.pn_itemDetails.Controls.Add(this.btn_addInvoice);
            this.pn_itemDetails.Location = new System.Drawing.Point(32, 357);
            this.pn_itemDetails.Name = "pn_itemDetails";
            this.pn_itemDetails.Size = new System.Drawing.Size(1542, 121);
            this.pn_itemDetails.TabIndex = 101;
            // 
            // txt_invoiceTaxValue
            // 
            this.txt_invoiceTaxValue.Location = new System.Drawing.Point(1551, 60);
            this.txt_invoiceTaxValue.Name = "txt_invoiceTaxValue";
            this.txt_invoiceTaxValue.Size = new System.Drawing.Size(157, 26);
            this.txt_invoiceTaxValue.TabIndex = 50;
            this.txt_invoiceTaxValue.TabStop = false;
            // 
            // lbl_taxInvoice
            // 
            this.lbl_taxInvoice.AutoSize = true;
            this.lbl_taxInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_taxInvoice.Location = new System.Drawing.Point(1008, 18);
            this.lbl_taxInvoice.Name = "lbl_taxInvoice";
            this.lbl_taxInvoice.Size = new System.Drawing.Size(63, 33);
            this.lbl_taxInvoice.TabIndex = 49;
            this.lbl_taxInvoice.Text = "Tax:";
            // 
            // txt_taxInvoiceBill
            // 
            this.txt_taxInvoiceBill.Location = new System.Drawing.Point(961, 68);
            this.txt_taxInvoiceBill.Name = "txt_taxInvoiceBill";
            this.txt_taxInvoiceBill.Size = new System.Drawing.Size(166, 26);
            this.txt_taxInvoiceBill.TabIndex = 18;
            this.txt_taxInvoiceBill.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Firebrick;
            this.label6.Location = new System.Drawing.Point(20, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 33);
            this.label6.TabIndex = 2;
            this.label6.Text = "Item Code:";
            // 
            // txt_itemCodeInvoice
            // 
            this.txt_itemCodeInvoice.AutoCompleteCustomSource.AddRange(new string[] {
            "201",
            "2202",
            "22203"});
            this.txt_itemCodeInvoice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_itemCodeInvoice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt_itemCodeInvoice.Location = new System.Drawing.Point(9, 68);
            this.txt_itemCodeInvoice.Name = "txt_itemCodeInvoice";
            this.txt_itemCodeInvoice.Size = new System.Drawing.Size(160, 26);
            this.txt_itemCodeInvoice.TabIndex = 4;
            this.txt_itemCodeInvoice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_itemCodeInvoice_KeyUp);
            // 
            // lbl_itemDescription
            // 
            this.lbl_itemDescription.AutoSize = true;
            this.lbl_itemDescription.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemDescription.Location = new System.Drawing.Point(214, 18);
            this.lbl_itemDescription.Name = "lbl_itemDescription";
            this.lbl_itemDescription.Size = new System.Drawing.Size(142, 33);
            this.lbl_itemDescription.TabIndex = 4;
            this.lbl_itemDescription.Text = "Item Name:";
            // 
            // txt_itemNameInvoice
            // 
            this.txt_itemNameInvoice.Location = new System.Drawing.Point(193, 68);
            this.txt_itemNameInvoice.Multiline = true;
            this.txt_itemNameInvoice.Name = "txt_itemNameInvoice";
            this.txt_itemNameInvoice.Size = new System.Drawing.Size(191, 26);
            this.txt_itemNameInvoice.TabIndex = 14;
            this.txt_itemNameInvoice.TabStop = false;
            // 
            // lbl_quantityInvoice
            // 
            this.lbl_quantityInvoice.AutoSize = true;
            this.lbl_quantityInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_quantityInvoice.ForeColor = System.Drawing.Color.Firebrick;
            this.lbl_quantityInvoice.Location = new System.Drawing.Point(437, 18);
            this.lbl_quantityInvoice.Name = "lbl_quantityInvoice";
            this.lbl_quantityInvoice.Size = new System.Drawing.Size(120, 33);
            this.lbl_quantityInvoice.TabIndex = 6;
            this.lbl_quantityInvoice.Text = "Quantity:";
            // 
            // txt_quantityInvoice
            // 
            this.txt_quantityInvoice.Location = new System.Drawing.Point(415, 68);
            this.txt_quantityInvoice.Name = "txt_quantityInvoice";
            this.txt_quantityInvoice.Size = new System.Drawing.Size(156, 26);
            this.txt_quantityInvoice.TabIndex = 5;
            this.txt_quantityInvoice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_quantityInvoice_KeyUp);
            // 
            // lbl_discountInvoice
            // 
            this.lbl_discountInvoice.AutoSize = true;
            this.lbl_discountInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_discountInvoice.Location = new System.Drawing.Point(800, 18);
            this.lbl_discountInvoice.Name = "lbl_discountInvoice";
            this.lbl_discountInvoice.Size = new System.Drawing.Size(122, 33);
            this.lbl_discountInvoice.TabIndex = 8;
            this.lbl_discountInvoice.Text = "Disc (%):";
            // 
            // lbl_totalInvoice
            // 
            this.lbl_totalInvoice.AutoSize = true;
            this.lbl_totalInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalInvoice.Location = new System.Drawing.Point(1182, 18);
            this.lbl_totalInvoice.Name = "lbl_totalInvoice";
            this.lbl_totalInvoice.Size = new System.Drawing.Size(79, 33);
            this.lbl_totalInvoice.TabIndex = 47;
            this.lbl_totalInvoice.Text = "Total:";
            // 
            // txt_discountInvoice
            // 
            this.txt_discountInvoice.Location = new System.Drawing.Point(774, 68);
            this.txt_discountInvoice.Name = "txt_discountInvoice";
            this.txt_discountInvoice.Size = new System.Drawing.Size(166, 26);
            this.txt_discountInvoice.TabIndex = 6;
            this.txt_discountInvoice.TextChanged += new System.EventHandler(this.txt_discountInvoice_TextChanged);
            this.txt_discountInvoice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_discountInvoice_KeyUp);
            // 
            // lbl_priceInvoice
            // 
            this.lbl_priceInvoice.AutoSize = true;
            this.lbl_priceInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_priceInvoice.Location = new System.Drawing.Point(629, 18);
            this.lbl_priceInvoice.Name = "lbl_priceInvoice";
            this.lbl_priceInvoice.Size = new System.Drawing.Size(80, 33);
            this.lbl_priceInvoice.TabIndex = 10;
            this.lbl_priceInvoice.Text = "Price:";
            // 
            // txt_priceInvoice
            // 
            this.txt_priceInvoice.Location = new System.Drawing.Point(596, 68);
            this.txt_priceInvoice.Name = "txt_priceInvoice";
            this.txt_priceInvoice.Size = new System.Drawing.Size(155, 26);
            this.txt_priceInvoice.TabIndex = 16;
            this.txt_priceInvoice.TabStop = false;
            // 
            // txt_totalAmountInvoice
            // 
            this.txt_totalAmountInvoice.Location = new System.Drawing.Point(1155, 68);
            this.txt_totalAmountInvoice.Name = "txt_totalAmountInvoice";
            this.txt_totalAmountInvoice.Size = new System.Drawing.Size(157, 26);
            this.txt_totalAmountInvoice.TabIndex = 7;
            this.txt_totalAmountInvoice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_totalAmountInvoice_KeyUp);
            // 
            // btn_refreshInvoice
            // 
            this.btn_refreshInvoice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_refreshInvoice.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_refreshInvoice.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_refreshInvoice.Location = new System.Drawing.Point(1438, 36);
            this.btn_refreshInvoice.Name = "btn_refreshInvoice";
            this.btn_refreshInvoice.Size = new System.Drawing.Size(80, 58);
            this.btn_refreshInvoice.TabIndex = 21;
            this.btn_refreshInvoice.TabStop = false;
            this.btn_refreshInvoice.Text = "-";
            this.btn_refreshInvoice.UseVisualStyleBackColor = false;
            this.btn_refreshInvoice.Click += new System.EventHandler(this.btn_refreshInvoice_Click);
            // 
            // btn_addInvoice
            // 
            this.btn_addInvoice.BackColor = System.Drawing.Color.Black;
            this.btn_addInvoice.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addInvoice.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_addInvoice.Location = new System.Drawing.Point(1342, 36);
            this.btn_addInvoice.Name = "btn_addInvoice";
            this.btn_addInvoice.Size = new System.Drawing.Size(80, 58);
            this.btn_addInvoice.TabIndex = 8;
            this.btn_addInvoice.Text = "+";
            this.btn_addInvoice.UseVisualStyleBackColor = false;
            this.btn_addInvoice.Click += new System.EventHandler(this.btn_addInvoice_Click);
            this.btn_addInvoice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.btn_addInvoice_KeyUp);
            // 
            // dg_dataView
            // 
            this.dg_dataView.BackgroundColor = System.Drawing.Color.White;
            this.dg_dataView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dg_dataView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dg_dataView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dg_dataView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_dataView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.ItemName,
            this.Quantity,
            this.Rate,
            this.Discount,
            this.Tax,
            this.TaxValue,
            this.Amount,
            this.Edit,
            this.Delete});
            this.dg_dataView.EnableHeadersVisualStyles = false;
            this.dg_dataView.Location = new System.Drawing.Point(32, 523);
            this.dg_dataView.Name = "dg_dataView";
            this.dg_dataView.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dg_dataView.RowHeadersVisible = false;
            this.dg_dataView.RowHeadersWidth = 62;
            this.dg_dataView.RowTemplate.Height = 28;
            this.dg_dataView.Size = new System.Drawing.Size(1190, 305);
            this.dg_dataView.TabIndex = 102;
            this.dg_dataView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_dataView_CellContentClick);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "id";
            this.ID.HeaderText = "ID";
            this.ID.MinimumWidth = 8;
            this.ID.Name = "ID";
            this.ID.Width = 150;
            // 
            // ItemName
            // 
            this.ItemName.DataPropertyName = "itemCode";
            this.ItemName.HeaderText = "ItemName";
            this.ItemName.MinimumWidth = 8;
            this.ItemName.Name = "ItemName";
            this.ItemName.Width = 150;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "quantity";
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.MinimumWidth = 8;
            this.Quantity.Name = "Quantity";
            this.Quantity.Width = 150;
            // 
            // Rate
            // 
            this.Rate.DataPropertyName = "price";
            this.Rate.HeaderText = "Rate";
            this.Rate.MinimumWidth = 8;
            this.Rate.Name = "Rate";
            this.Rate.Width = 150;
            // 
            // Discount
            // 
            this.Discount.DataPropertyName = "discount";
            this.Discount.HeaderText = "Discount";
            this.Discount.MinimumWidth = 8;
            this.Discount.Name = "Discount";
            this.Discount.Width = 150;
            // 
            // Tax
            // 
            this.Tax.DataPropertyName = "tax";
            this.Tax.HeaderText = "Tax";
            this.Tax.MinimumWidth = 8;
            this.Tax.Name = "Tax";
            this.Tax.Width = 150;
            // 
            // TaxValue
            // 
            this.TaxValue.DataPropertyName = "taxType";
            this.TaxValue.HeaderText = "TaxValue";
            this.TaxValue.MinimumWidth = 8;
            this.TaxValue.Name = "TaxValue";
            this.TaxValue.Width = 150;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "totalAmount";
            this.Amount.HeaderText = "Amount";
            this.Amount.MinimumWidth = 8;
            this.Amount.Name = "Amount";
            this.Amount.Width = 150;
            // 
            // Edit
            // 
            this.Edit.HeaderText = "Edit";
            this.Edit.MinimumWidth = 8;
            this.Edit.Name = "Edit";
            this.Edit.Text = "Edit";
            this.Edit.UseColumnTextForButtonValue = true;
            this.Edit.Width = 150;
            // 
            // Delete
            // 
            this.Delete.HeaderText = "Delete";
            this.Delete.MinimumWidth = 8;
            this.Delete.Name = "Delete";
            this.Delete.Text = "Delete";
            this.Delete.UseColumnTextForButtonValue = true;
            this.Delete.Width = 150;
            // 
            // txt_invoiceGrandTotal
            // 
            this.txt_invoiceGrandTotal.Location = new System.Drawing.Point(1539, 771);
            this.txt_invoiceGrandTotal.Name = "txt_invoiceGrandTotal";
            this.txt_invoiceGrandTotal.Size = new System.Drawing.Size(198, 26);
            this.txt_invoiceGrandTotal.TabIndex = 108;
            // 
            // lbl_invoiceGrandAmount
            // 
            this.lbl_invoiceGrandAmount.AutoSize = true;
            this.lbl_invoiceGrandAmount.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_invoiceGrandAmount.Location = new System.Drawing.Point(1359, 764);
            this.lbl_invoiceGrandAmount.Name = "lbl_invoiceGrandAmount";
            this.lbl_invoiceGrandAmount.Size = new System.Drawing.Size(169, 32);
            this.lbl_invoiceGrandAmount.TabIndex = 107;
            this.lbl_invoiceGrandAmount.Text = "Grand Total:";
            // 
            // txt_invoiceTotalTax
            // 
            this.txt_invoiceTotalTax.Location = new System.Drawing.Point(1538, 714);
            this.txt_invoiceTotalTax.Name = "txt_invoiceTotalTax";
            this.txt_invoiceTotalTax.Size = new System.Drawing.Size(199, 26);
            this.txt_invoiceTotalTax.TabIndex = 106;
            // 
            // lbl_invoiceTotalTax
            // 
            this.lbl_invoiceTotalTax.AutoSize = true;
            this.lbl_invoiceTotalTax.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_invoiceTotalTax.Location = new System.Drawing.Point(1359, 707);
            this.lbl_invoiceTotalTax.Name = "lbl_invoiceTotalTax";
            this.lbl_invoiceTotalTax.Size = new System.Drawing.Size(125, 33);
            this.lbl_invoiceTotalTax.TabIndex = 105;
            this.lbl_invoiceTotalTax.Text = "Total Tax:";
            // 
            // txt_invoiceTotalAmount
            // 
            this.txt_invoiceTotalAmount.Location = new System.Drawing.Point(1538, 657);
            this.txt_invoiceTotalAmount.Name = "txt_invoiceTotalAmount";
            this.txt_invoiceTotalAmount.Size = new System.Drawing.Size(199, 26);
            this.txt_invoiceTotalAmount.TabIndex = 104;
            // 
            // lbl_totalAmount
            // 
            this.lbl_totalAmount.AutoSize = true;
            this.lbl_totalAmount.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalAmount.Location = new System.Drawing.Point(1359, 650);
            this.lbl_totalAmount.Name = "lbl_totalAmount";
            this.lbl_totalAmount.Size = new System.Drawing.Size(173, 33);
            this.lbl_totalAmount.TabIndex = 103;
            this.lbl_totalAmount.Text = "Total Amount:";
            // 
            // btn_invoiceLogoutButton
            // 
            this.btn_invoiceLogoutButton.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.btn_invoiceLogoutButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_invoiceLogoutButton.Location = new System.Drawing.Point(1172, 911);
            this.btn_invoiceLogoutButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_invoiceLogoutButton.Name = "btn_invoiceLogoutButton";
            this.btn_invoiceLogoutButton.Size = new System.Drawing.Size(141, 69);
            this.btn_invoiceLogoutButton.TabIndex = 115;
            this.btn_invoiceLogoutButton.Text = "Logout";
            this.btn_invoiceLogoutButton.UseVisualStyleBackColor = false;
            this.btn_invoiceLogoutButton.Click += new System.EventHandler(this.btn_invoiceLogoutButton_Click);
            // 
            // btn_invoiceClearButton
            // 
            this.btn_invoiceClearButton.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn_invoiceClearButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_invoiceClearButton.Location = new System.Drawing.Point(983, 911);
            this.btn_invoiceClearButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_invoiceClearButton.Name = "btn_invoiceClearButton";
            this.btn_invoiceClearButton.Size = new System.Drawing.Size(141, 69);
            this.btn_invoiceClearButton.TabIndex = 114;
            this.btn_invoiceClearButton.Text = "Clear";
            this.btn_invoiceClearButton.UseVisualStyleBackColor = false;
            this.btn_invoiceClearButton.Click += new System.EventHandler(this.btn_invoiceClearButton_Click);
            // 
            // btn_invoiceFindButton
            // 
            this.btn_invoiceFindButton.BackColor = System.Drawing.Color.MediumBlue;
            this.btn_invoiceFindButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_invoiceFindButton.ForeColor = System.Drawing.SystemColors.Control;
            this.btn_invoiceFindButton.Location = new System.Drawing.Point(795, 911);
            this.btn_invoiceFindButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_invoiceFindButton.Name = "btn_invoiceFindButton";
            this.btn_invoiceFindButton.Size = new System.Drawing.Size(141, 69);
            this.btn_invoiceFindButton.TabIndex = 113;
            this.btn_invoiceFindButton.Text = "Find";
            this.btn_invoiceFindButton.UseVisualStyleBackColor = false;
            this.btn_invoiceFindButton.Click += new System.EventHandler(this.btn_invoiceFindButton_Click);
            // 
            // btn_invoiceDeleteButton
            // 
            this.btn_invoiceDeleteButton.BackColor = System.Drawing.Color.Red;
            this.btn_invoiceDeleteButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_invoiceDeleteButton.Location = new System.Drawing.Point(606, 911);
            this.btn_invoiceDeleteButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_invoiceDeleteButton.Name = "btn_invoiceDeleteButton";
            this.btn_invoiceDeleteButton.Size = new System.Drawing.Size(141, 69);
            this.btn_invoiceDeleteButton.TabIndex = 112;
            this.btn_invoiceDeleteButton.Text = "Delete";
            this.btn_invoiceDeleteButton.UseVisualStyleBackColor = false;
            this.btn_invoiceDeleteButton.Click += new System.EventHandler(this.btn_invoiceDeleteButton_Click);
            // 
            // btn_invoiceEditButton
            // 
            this.btn_invoiceEditButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_invoiceEditButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_invoiceEditButton.Location = new System.Drawing.Point(412, 911);
            this.btn_invoiceEditButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_invoiceEditButton.Name = "btn_invoiceEditButton";
            this.btn_invoiceEditButton.Size = new System.Drawing.Size(141, 69);
            this.btn_invoiceEditButton.TabIndex = 111;
            this.btn_invoiceEditButton.Text = "Edit";
            this.btn_invoiceEditButton.UseVisualStyleBackColor = false;
            this.btn_invoiceEditButton.Click += new System.EventHandler(this.btn_invoiceEditButton_Click);
            // 
            // btn_invoiceSaveButton
            // 
            this.btn_invoiceSaveButton.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_invoiceSaveButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_invoiceSaveButton.Location = new System.Drawing.Point(217, 911);
            this.btn_invoiceSaveButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_invoiceSaveButton.Name = "btn_invoiceSaveButton";
            this.btn_invoiceSaveButton.Size = new System.Drawing.Size(141, 69);
            this.btn_invoiceSaveButton.TabIndex = 110;
            this.btn_invoiceSaveButton.Text = "Save";
            this.btn_invoiceSaveButton.UseVisualStyleBackColor = false;
            this.btn_invoiceSaveButton.Click += new System.EventHandler(this.btn_invoiceSaveButton_Click);
            // 
            // btn_invoiceNewButton
            // 
            this.btn_invoiceNewButton.BackColor = System.Drawing.Color.Navy;
            this.btn_invoiceNewButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_invoiceNewButton.ForeColor = System.Drawing.SystemColors.Control;
            this.btn_invoiceNewButton.Location = new System.Drawing.Point(32, 911);
            this.btn_invoiceNewButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_invoiceNewButton.Name = "btn_invoiceNewButton";
            this.btn_invoiceNewButton.Size = new System.Drawing.Size(141, 69);
            this.btn_invoiceNewButton.TabIndex = 109;
            this.btn_invoiceNewButton.Text = "New";
            this.btn_invoiceNewButton.UseVisualStyleBackColor = false;
            this.btn_invoiceNewButton.Click += new System.EventHandler(this.btn_invoiceNewButton_Click);
            // 
            // btn_invoiceReceiptButton
            // 
            this.btn_invoiceReceiptButton.BackColor = System.Drawing.Color.LightPink;
            this.btn_invoiceReceiptButton.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_invoiceReceiptButton.ForeColor = System.Drawing.Color.Black;
            this.btn_invoiceReceiptButton.Location = new System.Drawing.Point(1365, 911);
            this.btn_invoiceReceiptButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_invoiceReceiptButton.Name = "btn_invoiceReceiptButton";
            this.btn_invoiceReceiptButton.Size = new System.Drawing.Size(141, 69);
            this.btn_invoiceReceiptButton.TabIndex = 116;
            this.btn_invoiceReceiptButton.Text = "Receipt";
            this.btn_invoiceReceiptButton.UseVisualStyleBackColor = false;
            this.btn_invoiceReceiptButton.Click += new System.EventHandler(this.btn_invoiceReceiptButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.btn_invoiceReceiptButton);
            this.Controls.Add(this.btn_invoiceLogoutButton);
            this.Controls.Add(this.btn_invoiceClearButton);
            this.Controls.Add(this.btn_invoiceFindButton);
            this.Controls.Add(this.btn_invoiceDeleteButton);
            this.Controls.Add(this.btn_invoiceEditButton);
            this.Controls.Add(this.btn_invoiceSaveButton);
            this.Controls.Add(this.btn_invoiceNewButton);
            this.Controls.Add(this.txt_invoiceGrandTotal);
            this.Controls.Add(this.lbl_invoiceGrandAmount);
            this.Controls.Add(this.txt_invoiceTotalTax);
            this.Controls.Add(this.lbl_invoiceTotalTax);
            this.Controls.Add(this.txt_invoiceTotalAmount);
            this.Controls.Add(this.lbl_totalAmount);
            this.Controls.Add(this.dg_dataView);
            this.Controls.Add(this.pn_itemDetails);
            this.Controls.Add(this.txt_invoiceEmail);
            this.Controls.Add(this.txt_invoiceAddress);
            this.Controls.Add(this.lbl_invoiceAddress);
            this.Controls.Add(this.lbl_invoiceEmail);
            this.Controls.Add(this.txt_invoiceStateCode);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_invoiceMobile);
            this.Controls.Add(this.txt_invoiceState);
            this.Controls.Add(this.lbl_invoiceState);
            this.Controls.Add(this.txt_invoiceGstNo);
            this.Controls.Add(this.lbl_gstNoInvoice);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_invoicePhone);
            this.Controls.Add(this.lbl_invoicePhone);
            this.Controls.Add(this.txt_invoiceCustomerName);
            this.Controls.Add(this.lbl_invoiceCustomerId);
            this.Controls.Add(this.txt_invoiceCustomerId);
            this.Controls.Add(this.lbl_customerId);
            this.Controls.Add(this.dtp_invoiceBillDate);
            this.Controls.Add(this.lbl_billDate);
            this.Controls.Add(this.txt_invoiceBillNumber);
            this.Controls.Add(this.lbl_billNo);
            this.Controls.Add(this.lbl_invoice);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pn_itemDetails.ResumeLayout(false);
            this.pn_itemDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_dataView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_invoice;
        private System.Windows.Forms.TextBox txt_invoiceBillNumber;
        private System.Windows.Forms.Label lbl_billNo;
        private System.Windows.Forms.Label lbl_billDate;
        private System.Windows.Forms.DateTimePicker dtp_invoiceBillDate;
        private System.Windows.Forms.Label lbl_customerId;
        private System.Windows.Forms.TextBox txt_invoiceCustomerId;
        private System.Windows.Forms.TextBox txt_invoiceCustomerName;
        private System.Windows.Forms.Label lbl_invoiceCustomerId;
        private System.Windows.Forms.TextBox txt_invoiceState;
        private System.Windows.Forms.Label lbl_invoiceState;
        private System.Windows.Forms.TextBox txt_invoiceGstNo;
        private System.Windows.Forms.Label lbl_gstNoInvoice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_invoicePhone;
        private System.Windows.Forms.Label lbl_invoicePhone;
        private System.Windows.Forms.TextBox txt_invoiceMobile;
        private System.Windows.Forms.TextBox txt_invoiceEmail;
        private System.Windows.Forms.TextBox txt_invoiceAddress;
        private System.Windows.Forms.Label lbl_invoiceAddress;
        private System.Windows.Forms.Label lbl_invoiceEmail;
        private System.Windows.Forms.TextBox txt_invoiceStateCode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel pn_itemDetails;
        private System.Windows.Forms.TextBox txt_invoiceTaxValue;
        private System.Windows.Forms.Label lbl_taxInvoice;
        private System.Windows.Forms.TextBox txt_taxInvoiceBill;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_itemCodeInvoice;
        private System.Windows.Forms.Label lbl_itemDescription;
        private System.Windows.Forms.TextBox txt_itemNameInvoice;
        private System.Windows.Forms.Label lbl_quantityInvoice;
        private System.Windows.Forms.TextBox txt_quantityInvoice;
        private System.Windows.Forms.Label lbl_discountInvoice;
        private System.Windows.Forms.Label lbl_totalInvoice;
        private System.Windows.Forms.TextBox txt_discountInvoice;
        private System.Windows.Forms.Label lbl_priceInvoice;
        private System.Windows.Forms.TextBox txt_priceInvoice;
        private System.Windows.Forms.TextBox txt_totalAmountInvoice;
        private System.Windows.Forms.Button btn_refreshInvoice;
        private System.Windows.Forms.Button btn_addInvoice;
        private System.Windows.Forms.DataGridView dg_dataView;
        private System.Windows.Forms.TextBox txt_invoiceGrandTotal;
        private System.Windows.Forms.Label lbl_invoiceGrandAmount;
        private System.Windows.Forms.TextBox txt_invoiceTotalTax;
        private System.Windows.Forms.Label lbl_invoiceTotalTax;
        private System.Windows.Forms.TextBox txt_invoiceTotalAmount;
        private System.Windows.Forms.Label lbl_totalAmount;
        private System.Windows.Forms.Button btn_invoiceLogoutButton;
        private System.Windows.Forms.Button btn_invoiceClearButton;
        private System.Windows.Forms.Button btn_invoiceFindButton;
        private System.Windows.Forms.Button btn_invoiceDeleteButton;
        private System.Windows.Forms.Button btn_invoiceEditButton;
        private System.Windows.Forms.Button btn_invoiceSaveButton;
        private System.Windows.Forms.Button btn_invoiceNewButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Discount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tax;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaxValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewButtonColumn Edit;
        private System.Windows.Forms.DataGridViewButtonColumn Delete;
        private System.Windows.Forms.Button btn_invoiceReceiptButton;
    }
}

