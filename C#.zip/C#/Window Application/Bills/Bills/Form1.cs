﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Bills
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int num,result;
        public int a, b, productAmount, discountAmount, sum, taxValue1;

        private void txt_invoiceBillNumber_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void dtp_invoiceBillDate_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void txt_invoiceCustomerId_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                details();
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }
        SqlConnection connection = new SqlConnection(@"Data Source=localhost;Initial Catalog=dbBank;Integrated Security=True");

        public void details()
        {

            string query = "select customername,email,mobile,state,phone,address,gstNo,stateCode from tb_customerBilling where customerId=@customerId";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@customerId", txt_invoiceCustomerId.Text);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                txt_invoiceCustomerName.Text = reader["customername"].ToString();
                txt_invoiceEmail.Text = reader["email"].ToString();
                txt_invoiceMobile.Text = reader["mobile"].ToString();
                txt_invoiceState.Text = reader["state"].ToString();
                txt_invoicePhone.Text = reader["phone"].ToString();
                txt_invoiceAddress.Text = reader["address"].ToString();
                txt_invoiceGstNo.Text = reader["gstNo"].ToString();
                txt_invoiceStateCode.Text = reader["stateCode"].ToString();
            }
            else
            {
                txt_invoiceCustomerName.Clear();
                txt_invoiceEmail.Clear();
                txt_invoiceMobile.Clear();
                txt_invoicePhone.Clear();
                txt_invoiceState.Clear();
                txt_invoiceStateCode.Clear();
                txt_invoiceGstNo.Clear();
                txt_invoiceAddress.Clear();
            }
            reader.Close();
            connection.Close();
        }

        public void itemCode()
        {
            connection.Open();
            string query = "select itemName,taxValue,sellingPrice from tb_itemCode where itemCode=@itemCode";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@itemCode", (txt_itemCodeInvoice.Text));

            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                txt_itemNameInvoice.Text = reader["itemName"].ToString();
                txt_taxInvoiceBill.Text = reader["taxValue"].ToString();
                txt_priceInvoice.Text = reader["sellingPrice"].ToString();
            }
            else
            {
                txt_itemNameInvoice.Clear();
                txt_taxInvoiceBill.Clear();
                txt_priceInvoice.Clear();
            }
            reader.Close();
            connection.Close();
        }

        private void btn_addInvoice_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "insert into tb_itemInvoice values" +
                 "(@billNo,@billDate,@itemCode,@itemName,@customerCode,@quantity,@price,@discount,@tax,@taxValue,@totalAmount)";

            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@billNo", int.Parse(txt_invoiceBillNumber.Text));
            command.Parameters.AddWithValue("@billDate", dtp_invoiceBillDate.Value.Date);
            command.Parameters.AddWithValue("@itemCode", (txt_itemCodeInvoice.Text));
            command.Parameters.AddWithValue("@itemName", txt_itemNameInvoice.Text);
            command.Parameters.AddWithValue("@customerCode", int.Parse(txt_invoiceCustomerId.Text));
            command.Parameters.AddWithValue("@quantity", int.Parse(txt_quantityInvoice.Text));
            command.Parameters.AddWithValue("@price", int.Parse(txt_priceInvoice.Text));
            command.Parameters.AddWithValue("@discount", int.Parse(txt_discountInvoice.Text));
            command.Parameters.AddWithValue("@tax", int.Parse(txt_taxInvoiceBill.Text));
            command.Parameters.AddWithValue("@taxValue", int.Parse(txt_invoiceTaxValue.Text));
            command.Parameters.AddWithValue("@totalAmount", int.Parse(txt_totalAmountInvoice.Text));
            command.ExecuteNonQuery();

            string query1 = "insert into tb_originalItemInvoice values" +
                 "(@billNo,@billDate,@itemCode,@itemName,@customerCode,@quantity,@price,@discount,@tax,@taxValue,@totalAmount)";

            SqlCommand command1 = new SqlCommand(query1, connection);
            command1.Parameters.AddWithValue("@billNo", int.Parse(txt_invoiceBillNumber.Text));
            command1.Parameters.AddWithValue("@billDate", dtp_invoiceBillDate.Value.Date);
            command1.Parameters.AddWithValue("@itemCode", (txt_itemCodeInvoice.Text));
            command1.Parameters.AddWithValue("@itemName", txt_itemNameInvoice.Text);
            command1.Parameters.AddWithValue("@customerCode", int.Parse(txt_invoiceCustomerId.Text));
            command1.Parameters.AddWithValue("@quantity", int.Parse(txt_quantityInvoice.Text));
            command1.Parameters.AddWithValue("@price", int.Parse(txt_priceInvoice.Text));
            command1.Parameters.AddWithValue("@discount", int.Parse(txt_discountInvoice.Text));
            command1.Parameters.AddWithValue("@tax", int.Parse(txt_taxInvoiceBill.Text));
            command1.Parameters.AddWithValue("@taxValue", int.Parse(txt_invoiceTaxValue.Text));
            command1.Parameters.AddWithValue("@totalAmount", int.Parse(txt_totalAmountInvoice.Text));
            command1.ExecuteNonQuery();

            display3();
            clearData1();
            sumTotal();
            sumAmount();
            grandTotal();
            connection.Close();
        }

        public void sumTotal()
        {
            string query = "select sum(taxType) from tb_itemInvoice";
            SqlCommand command = new SqlCommand(query, connection);
            object result = command.ExecuteScalar();
            txt_invoiceTotalTax.Text = result.ToString();
        }

        public void sumAmount()
        {
            string query = "select sum(totalAmount) from tb_itemInvoice";
            SqlCommand command = new SqlCommand(query, connection);
            object result1 = command.ExecuteScalar();
            txt_invoiceTotalAmount.Text = result1.ToString();
        }

        public void grandTotal()
        {
            try
            {
                int a1 = int.Parse(txt_invoiceTotalAmount.Text);
                int b1 = int.Parse(txt_invoiceTotalTax.Text);
                int c1 = a1 + b1;
                txt_invoiceGrandTotal.Text = c1.ToString();
            }
            catch { }
        }



        public void clearData1()
        {
            txt_itemCodeInvoice.Text = "";
            txt_itemNameInvoice.Text = "";
            txt_quantityInvoice.Text = "";
            txt_taxInvoiceBill.Text = "";
            txt_priceInvoice.Text = "";
            txt_discountInvoice.Text = "";
            txt_totalAmountInvoice.Text = "";

        }

        public void display3()
        {
            string query1 = "select id,itemCode,quantity,price,discount,tax,taxType,totalAmount from tb_itemInvoice ";
            SqlCommand cmd = new SqlCommand(query1, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dg_dataView.DataSource = table;
            cmd.ExecuteNonQuery();
        }

        private void btn_invoiceNewButton_Click(object sender, EventArgs e)
        {
            
            string regNumber1;
            connection.Open();
            clear();
            string query = "select billNo from tb_invoiceBills order by billNo desc";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();


            if (reader.Read())
            {
                int id = int.Parse(reader[0].ToString()) + 1;
                regNumber1 = id.ToString("0");
            }
            else if (Convert.IsDBNull(reader))
            {
                regNumber1 = "1";
            }
            else
            {
                regNumber1 = "1";
            }
            txt_invoiceBillNumber.Text = regNumber1.ToString();
            txt_invoiceBillNumber.Focus();
            connection.Close();
           
        }

        private void btn_addInvoice_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txt_itemCodeInvoice.Focus();
            }
        }

        private void btn_invoiceLogoutButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_refreshInvoice_Click(object sender, EventArgs e)
        {
            txt_itemCodeInvoice.Clear();
            txt_itemNameInvoice.Clear();
            txt_discountInvoice.Clear();
            txt_quantityInvoice.Clear();
            txt_priceInvoice.Clear();
            txt_taxInvoiceBill.Clear();
            txt_totalAmountInvoice.Clear();
            DataTable DT = (DataTable)dg_dataView.DataSource;
            if (DT != null)
            {
                DT.Clear();
            }
        }
        public void clear()
        {
            txt_invoiceBillNumber.Clear();
            dtp_invoiceBillDate.Refresh();
            txt_invoiceCustomerId.Clear();
            txt_invoiceCustomerName.Clear();
            txt_invoicePhone.Clear();
            txt_invoiceMobile.Clear();
            txt_invoiceGstNo.Clear();
            txt_invoiceState.Clear();
            txt_invoiceStateCode.Clear();
            txt_invoiceEmail.Clear();
            txt_invoiceAddress.Clear();

            txt_itemCodeInvoice.Clear();
            txt_itemNameInvoice.Clear();
            txt_discountInvoice.Clear();
            txt_quantityInvoice.Clear();
            txt_priceInvoice.Clear();
            txt_taxInvoiceBill.Clear();
            txt_totalAmountInvoice.Clear();
            txt_invoiceTotalAmount.Clear();
            txt_invoiceTotalTax.Clear();
            txt_invoiceGrandTotal.Clear();
            DataTable DT = (DataTable)dg_dataView.DataSource;
            if (DT != null)
            {
                DT.Clear();
            }
        }
        private void btn_invoiceClearButton_Click(object sender, EventArgs e)
        {
            txt_invoiceBillNumber.Clear();
            dtp_invoiceBillDate.Refresh();
            txt_invoiceCustomerId.Clear();
            txt_invoiceCustomerName.Clear();    
            txt_invoicePhone.Clear();
            txt_invoiceMobile.Clear();
            txt_invoiceGstNo.Clear();
            txt_invoiceState.Clear();
            txt_invoiceStateCode.Clear();
            txt_invoiceEmail.Clear();
            txt_invoiceAddress.Clear();

            txt_itemCodeInvoice.Clear();
            txt_itemNameInvoice.Clear();
            txt_discountInvoice.Clear();
            txt_quantityInvoice.Clear();
            txt_priceInvoice.Clear();
            txt_taxInvoiceBill.Clear();
            txt_totalAmountInvoice.Clear();
            txt_invoiceTotalAmount.Clear();
            txt_invoiceTotalTax.Clear();
            txt_invoiceGrandTotal.Clear();
            DataTable DT = (DataTable)dg_dataView.DataSource;
            if (DT != null)
            {
                DT.Clear();
            }
        }

        private void btn_invoiceSaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "insert into tb_invoiceBills " +
                "values(@billNo,@billName,@customerId,@customerName,@email,@mobile,@phone,@state,@stateCode,@gstNo,@address,@totalTax,@totalAmount,@grandTotal)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@billNo", int.Parse(txt_invoiceBillNumber.Text));
                command.Parameters.AddWithValue("@billName", dtp_invoiceBillDate.Value.Date);
                command.Parameters.AddWithValue("@customerId", int.Parse(txt_invoiceCustomerId.Text));
                command.Parameters.AddWithValue("@customerName", txt_invoiceCustomerName.Text);
                command.Parameters.AddWithValue("@email", txt_invoiceEmail.Text);
                command.Parameters.AddWithValue("@mobile", txt_invoiceMobile.Text);
                command.Parameters.AddWithValue("@phone", txt_invoicePhone.Text);
                command.Parameters.AddWithValue("@state", txt_invoiceState.Text);
                command.Parameters.AddWithValue("@stateCode", txt_invoiceStateCode.Text);
                command.Parameters.AddWithValue("@gstNo", txt_invoiceGstNo.Text);
                command.Parameters.AddWithValue("@address", txt_invoiceAddress.Text);
                command.Parameters.AddWithValue("@totalTax", int.Parse(txt_invoiceTotalTax.Text));
                command.Parameters.AddWithValue("@totalAmount", int.Parse(txt_invoiceTotalAmount.Text));
                command.Parameters.AddWithValue("@grandTotal", int.Parse(txt_invoiceGrandTotal.Text));
                command.ExecuteNonQuery();
                MessageBox.Show("Insert data is successfully.");

                string query2 = "delete from tb_itemInvoice";
                SqlCommand command1 = new SqlCommand(query2, connection);
                command1.ExecuteNonQuery();

                DataTable DT = (DataTable)dg_dataView.DataSource;
                if (DT != null)
                {
                    DT.Clear();
                }
                connection.Close();
            }
            catch
            {

            }

        }

        private void btn_invoiceEditButton_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "update tb_invoiceBills set billDate=@billDate,customerName=@customerName,email=@email,mobile=@mobile,state=@state,phone=@phone,address=@address,gstNo=@gstNo,stateCode=@stateCode where billNo=@billNo";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@billNo", int.Parse(txt_invoiceBillNumber.Text));
                cmd.Parameters.AddWithValue("@billDate", dtp_invoiceBillDate.Value.Date);
                cmd.Parameters.AddWithValue("@customerName", txt_invoiceCustomerName.Text);
                cmd.Parameters.AddWithValue("@email", txt_invoiceEmail.Text);
                cmd.Parameters.AddWithValue("@mobile", txt_invoiceMobile.Text);
                cmd.Parameters.AddWithValue("@state", txt_invoiceState.Text);
                cmd.Parameters.AddWithValue("@phone", txt_invoicePhone.Text);
                cmd.Parameters.AddWithValue("@address", txt_invoiceAddress.Text);
                cmd.Parameters.AddWithValue("@gstNo", txt_invoiceGstNo.Text);
                cmd.Parameters.AddWithValue("@stateCode", txt_invoiceStateCode.Text);
                cmd.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("Update Data is completed.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex.Message);
            }
        }

        private void btn_invoiceDeleteButton_Click(object sender, EventArgs e)
        {
            connection.Open();
            string Query = "delete tb_invoiceBills where billNo=@billNo";
            SqlCommand cmd = new SqlCommand(Query, connection);
            cmd.Parameters.AddWithValue("@billNo", int.Parse(txt_invoiceBillNumber.Text));
            cmd.ExecuteNonQuery();
            deleteDataInvoice();
            display3();
            connection.Close();
            MessageBox.Show("Delete data in successfully.");
        }

        public void deleteDataInvoice()
        {
            string query1 = "delete tb_itemInvoice where billNo=@billNo";
            SqlCommand command = new SqlCommand(query1, connection);
            command.Parameters.AddWithValue("@billNo", int.Parse(txt_invoiceBillNumber.Text));
            command.ExecuteNonQuery();
        }

        public void find(int num)
        {
            string query = "select id,itemName,quantity,price,discount,tax,taxType,totalAmount from tb_originalItemInvoice where billNo='" + num + "'";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dg_dataView.DataSource = table;
        }

        private void btn_invoiceFindButton_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            DialogResult dr = form2.ShowDialog();
            if (dr == DialogResult.OK)
            {
                num = form2.userNum;
                find(num);
            }
        }

        private void btn_invoiceReceiptButton_Click(object sender, EventArgs e)
        {
            Form3 form3= new Form3();
            form3.Show();
        }

        private void dg_dataView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dg_dataView.Columns[e.ColumnIndex].HeaderText == "Edit")
            {
                DataGridViewRow selectedRow = dg_dataView.Rows[e.RowIndex];
                MessageBox.Show("Update data is successfully");
            }

            if (dg_dataView.Columns[e.ColumnIndex].HeaderText == "Delete")
            {

                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    int id = Convert.ToInt32(dg_dataView.Rows[e.RowIndex].Cells["id"].Value);
                    connection.Open();
                    string query = "delete from tb_itemInvoice where id=@id";
                    SqlCommand command=new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id",id);
                    command.ExecuteNonQuery();
                    sumTotal();
                    sumAmount();
                    grandTotal();
                    connection.Close();
                    dg_dataView.Rows.RemoveAt(e.RowIndex);
                    MessageBox.Show("Delete data is successfully");
                }
            }
        }

        private void txt_itemCodeInvoice_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                itemCode();
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void txt_quantityInvoice_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void txt_discountInvoice_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (string.IsNullOrEmpty(txt_discountInvoice.Text))
                {
                    txt_discountInvoice.Text = "0";
                }
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void txt_totalAmountInvoice_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void txt_discountInvoice_TextChanged(object sender, EventArgs e)
        {
            try
            {
                //Base Amount.
                a = int.Parse(txt_quantityInvoice.Text);
                b = int.Parse(txt_priceInvoice.Text);
                productAmount = (a * b);
                int discount = int.Parse(txt_discountInvoice.Text);
                discountAmount = (productAmount * (discount / 100));
                sum = (productAmount - discountAmount);
                txt_totalAmountInvoice.Text = sum.ToString();
                taxValue1 = int.Parse(txt_taxInvoiceBill.Text);
                int sum1 = (productAmount * taxValue1) / 100;
                txt_invoiceTaxValue.Text = sum1.ToString();
            }
            catch { }
        }


    }
}
