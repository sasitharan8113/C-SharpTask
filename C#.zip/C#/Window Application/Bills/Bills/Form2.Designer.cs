﻿namespace Bills
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dg_findAll = new System.Windows.Forms.DataGridView();
            this.btn_showInvoice = new System.Windows.Forms.Button();
            this.btn_findAllInvoice = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dg_findAll)).BeginInit();
            this.SuspendLayout();
            // 
            // dg_findAll
            // 
            this.dg_findAll.BackgroundColor = System.Drawing.Color.White;
            this.dg_findAll.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dg_findAll.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dg_findAll.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_findAll.EnableHeadersVisualStyles = false;
            this.dg_findAll.Location = new System.Drawing.Point(150, 89);
            this.dg_findAll.Name = "dg_findAll";
            this.dg_findAll.RowHeadersVisible = false;
            this.dg_findAll.RowHeadersWidth = 62;
            this.dg_findAll.RowTemplate.Height = 28;
            this.dg_findAll.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_findAll.Size = new System.Drawing.Size(824, 449);
            this.dg_findAll.TabIndex = 0;
            // 
            // btn_showInvoice
            // 
            this.btn_showInvoice.BackColor = System.Drawing.Color.White;
            this.btn_showInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_showInvoice.ForeColor = System.Drawing.Color.Black;
            this.btn_showInvoice.Location = new System.Drawing.Point(669, 565);
            this.btn_showInvoice.Name = "btn_showInvoice";
            this.btn_showInvoice.Size = new System.Drawing.Size(203, 58);
            this.btn_showInvoice.TabIndex = 1;
            this.btn_showInvoice.Text = "Search";
            this.btn_showInvoice.UseVisualStyleBackColor = false;
            this.btn_showInvoice.Click += new System.EventHandler(this.btn_showInvoice_Click);
            // 
            // btn_findAllInvoice
            // 
            this.btn_findAllInvoice.BackColor = System.Drawing.Color.White;
            this.btn_findAllInvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_findAllInvoice.ForeColor = System.Drawing.Color.Black;
            this.btn_findAllInvoice.Location = new System.Drawing.Point(281, 565);
            this.btn_findAllInvoice.Name = "btn_findAllInvoice";
            this.btn_findAllInvoice.Size = new System.Drawing.Size(203, 58);
            this.btn_findAllInvoice.TabIndex = 2;
            this.btn_findAllInvoice.Text = "Find All";
            this.btn_findAllInvoice.UseVisualStyleBackColor = false;
            this.btn_findAllInvoice.Click += new System.EventHandler(this.btn_findAllInvoice_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1125, 653);
            this.Controls.Add(this.btn_findAllInvoice);
            this.Controls.Add(this.btn_showInvoice);
            this.Controls.Add(this.dg_findAll);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "Form2";
            this.Text = "Form2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dg_findAll)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dg_findAll;
        private System.Windows.Forms.Button btn_showInvoice;
        private System.Windows.Forms.Button btn_findAllInvoice;
    }
}