﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            string connectString = @"Data Source=localhost;Initial Catalog=dbBank;
                                    User ID=sa;Password=123456";
            SqlConnection sqlCn = new SqlConnection(connectString);
            sqlCn.Open();
            string sql = "select id,name from tb_customer";
            SqlCommand cnn = new SqlCommand(sql,sqlCn);

            SqlDataReader sqlDataReader = cnn.ExecuteReader();

            string output = " ";

            while (sqlDataReader.Read())
            {
                output += sqlDataReader.GetInt32(0) +"-"+ sqlDataReader.GetString(1) + "\n";
            }
            MessageBox.Show(output);
            sqlDataReader.Close();
            cnn.Dispose();
            sqlCn.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
