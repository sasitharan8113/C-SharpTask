﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CrudWindowForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection connection=new SqlConnection(@"Data Source=localhost;Initial Catalog=dbBank;
                                    User ID=sa;Password=123456");
        private void insert(object sender, EventArgs e)
        {
                connection.Open();
                SqlCommand cmd = new SqlCommand("insert into tb_employee values(@Name,@EmpId,@Role,@age,@phoneNumber)"
                    , connection);
                cmd.Parameters.AddWithValue("@Name", textBox1.Text);
                cmd.Parameters.AddWithValue("@EmpId", textBox2.Text);
                cmd.Parameters.AddWithValue("@Role", textBox3.Text);
                cmd.Parameters.AddWithValue("@phoneNumber", textBox4.Text);
                cmd.Parameters.AddWithValue("@age", int.Parse(textBox5.Text));
                cmd.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("Insert the data is successfully.");   
        }

        private void update(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand(
                "Update tb_employee set Name=@Name,Role=@Role,age=@age,phoneNumber=@phoneNumber where EmpId=@EmpId", connection);
            command.Parameters.AddWithValue("@Name", textBox1.Text);
            command.Parameters.AddWithValue("@EmpId", textBox2.Text);
            command.Parameters.AddWithValue("@Role", textBox3.Text);
            command.Parameters.AddWithValue("@phoneNumber", textBox4.Text);
            command.Parameters.AddWithValue("@age", int.Parse(textBox5.Text));
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Update the data is successfully.");
        }

        private void delete(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand sqlCommand = new SqlCommand("Delete tb_employee where EmpId=@EmpId", connection);
            sqlCommand.Parameters.AddWithValue("@EmpId", textBox2.Text);
            sqlCommand.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Successfully Deleted");
        }

        private void show(object sender, EventArgs e)
        {
            connection.Open ();
            SqlCommand command = new SqlCommand("Select * from tb_employee",connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close ();
        }

        private void search(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("Select * from tb_employee where EmpId=@EmpId", connection);
            command.Parameters.AddWithValue("@EmpId", textBox2.Text);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }
    }
}
