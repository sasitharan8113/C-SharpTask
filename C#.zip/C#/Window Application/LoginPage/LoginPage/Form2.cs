﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace LoginPage
{
    public partial class dg_view : Form
    {
        public dg_view()
        {
            InitializeComponent();
            generateId();
            display();
        }


        SqlConnection connection = new SqlConnection(@"Data Source=localhost;Initial Catalog=dbBank;Integrated Security=True");


        private void btn_save_Click(object sender, EventArgs e)
        {
            connection.Open();
            try
            {
                string query1 = "insert into tb_registration values(@regNo,@name,@age,@dob,@gender,@address,@amount)";
                SqlCommand cmd = new SqlCommand(query1, connection);
                cmd.Parameters.AddWithValue("@regNo", txt_regNo.Text);
                cmd.Parameters.AddWithValue("@name", txt_name.Text);
                cmd.Parameters.AddWithValue("@age", int.Parse(txt_age.Text));
                cmd.Parameters.AddWithValue("@dob", dtp_date.Value);
                cmd.Parameters.AddWithValue("@gender", cb_gender.Text);
                cmd.Parameters.AddWithValue("@address", txt_address.Text);
                cmd.Parameters.AddWithValue("@amount", decimal.Parse(txt_amount.Text));
                cmd.ExecuteNonQuery();
                connection.Close();
                display();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Insert the data is successfully.");
        }

        public void display()
        {
            connection.Open();
            string query = "select * from tb_registration";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
            command.ExecuteNonQuery();
            connection.Close();
        }



        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "delete tb_registration where regNo=@regNo";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@regNo", txt_regNo.Text);
                command.ExecuteNonQuery();
                connection.Close();
                display();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Successfully Deleted");

        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "update tb_registration set name=@Name,age=@Age,dob=@dob,gender=@gender,address=@address,amount=@amount where regNo=@regNo";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@regNo", txt_regNo.Text);
                command.Parameters.AddWithValue("@Name", txt_name.Text);
                command.Parameters.AddWithValue("@Age", int.Parse(txt_age.Text));
                command.Parameters.AddWithValue("@dob", dtp_date.Value);
                command.Parameters.AddWithValue("@gender", cb_gender.Text);
                command.Parameters.AddWithValue("@address", txt_address.Text);
                command.Parameters.AddWithValue("@amount", decimal.Parse(txt_amount.Text));
                command.ExecuteNonQuery();
                connection.Close();
                display();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            MessageBox.Show("Update the data is successfully.");
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void generateId()
        {
            string regNumber;
            connection.Open();
            string query = "select regNo from tb_registration order by regNo desc";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                int id = int.Parse(reader[0].ToString()) + 1;
                regNumber = id.ToString("0000");
            }
            else if (Convert.IsDBNull(reader))
            {
                regNumber = "0001";
            }
            else
            {
                regNumber = "0001";
            }
            connection.Close();

            txt_regNo.Text = regNumber.ToString();
        }

        private void btn_Check_Click(object sender, EventArgs e)
        {
            txt_regNo.Text = "";
            txt_name.Text = "";
            txt_age.Text = "";
            cb_gender.Text = "";
            dtp_date.Text = "";
            txt_address.Text = "";
            txt_amount.Text = "";
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            txt_regNo.Text= dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txt_name.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txt_age.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            dtp_date.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            cb_gender.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txt_address.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txt_amount.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
        }
    }
}
