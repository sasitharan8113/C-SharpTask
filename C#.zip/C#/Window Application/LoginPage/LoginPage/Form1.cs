﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace LoginPage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        private void btn_submit_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(@"Data Source=localhost;Initial Catalog=dbBank;Integrated Security=True");
            connection.Open();
            string query =
            "select * from tb_login where username='" + txt_userName.Text + "' and password='" + txt_password.Text+ "'";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                MessageBox.Show("Login successful!");
                dg_view form = new dg_view();
                form.Show();
            }
            else
            {
                MessageBox.Show("Login failed. Please check your username and password.");
            }
            connection.Close();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_userName.Text="";
            txt_password.Text ="";
        }
    }
}
