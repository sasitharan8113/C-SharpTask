﻿using System;

namespace StringTask
{
    public class Program
    {
        public static void Main(string[] args){
            string str;
            Console.Write("Enter a string=");
            str = Console.ReadLine();

            //string length
            Console.WriteLine("Total length="+str.Length);

            //string to character
            char[] ch = str.ToCharArray();
            foreach (char ch1 in ch)
            {
             Console.Write(ch1+" ");
            }

            //Access string
            Console.WriteLine("\naccess string=" + str[0]);

            //string to string array
            Console.WriteLine("Array elements:");
            String[] splits = str.Split(' ');
            for(int i=0;i<splits.Length; i++)
            {
                Console.WriteLine(splits[i]+" ");   
            }
        }
    }
}
