﻿using System;
using System.Threading;

namespace Threads

{

    public class thread1
    {
        public static void display()
        {
            for (int i = 1; i < 10; i++){
                Console.WriteLine(i);
                //Thread.Sleep(1000);
            }
        }

        public void display1()
        {
            for (int i = 10; i < 20; i++)
            {
                Console.WriteLine(i);
                //Thread.Sleep(100);     
            }
        }
    }


    public class Program
    {
       public static void Main(string[] args)
        {
            Console.WriteLine("thread start");
            thread1 s1= new thread1();
            Thread t1 =new Thread(new ThreadStart(thread1.display));
            Thread t2 = new Thread(new ThreadStart(s1.display1));
            t1.Start();
            //t1.Join();
            t2.Start();

            t1.Abort();
            t2.Abort();
            Console.WriteLine("thread end");
        }
    }
}
