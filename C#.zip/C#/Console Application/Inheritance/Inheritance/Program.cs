﻿using System;
using System.Data;
using System.Runtime.CompilerServices;

namespace Inheritance
{
    public class Program
    {
        class employee
        {
            string empName;
            int age;
            ulong phoneNumber;
            string role;

            public void getData(string empName, int age, ulong phoneNumber,string role)
            {
                this.empName = empName;
                this.age = age;
                this.phoneNumber = phoneNumber;
                this.role = role;
            }

            public void display()
            {
                Console.WriteLine("employee name="+empName);
                Console.WriteLine("employee age="+age);
                Console.WriteLine("employee phone number=" + phoneNumber);
                Console.WriteLine("employee role="+role);
            }
        }

        class details : employee
        {
            public double salary;
            public byte experience;

            public void getData1(double salary,byte experience)
            {
                this.salary = salary;
                this.experience = experience;
            }
            public void display1()
            {
                Console.WriteLine("employee salary=" + salary);
                Console.WriteLine("employee age=" + experience);
            }
        }


        class family : details
        {
            public string fatherName;
            public string motherName;

            public void getData2(string fatherName,string motherName)
            {
                this.fatherName = fatherName;
                this.motherName = motherName;
            }

            public void display2()
            {
                Console.WriteLine("employee father name=" + fatherName);
                Console.WriteLine("employee mother name=" + motherName);
            }
        }
        public static void Main(string[] args)
        {
            family del = new family();
            del.getData("sasi",22,8870244640,"developer");
            del.display();
            del.getData1(74000.78, 2);
            del.display1();
            del.getData2("sethuraj","radhaselvi");
            del.display2();
        }
    }
}
