﻿using System;
using System.IO;

namespace FileHandling
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string fileName;
            Console.Write("Enter a file name=");
            fileName = Console.ReadLine();

            string filePath;
            Console.Write("Enter a file path=");
            filePath = Console.ReadLine();

            string file = Path.Combine(filePath, fileName);

            //create a file
            FileStream fs = File.Create(file);
            fs.Close();

            if (File.Exists(file))
            {
                Console.WriteLine("file is created");
            }
            else
            {
                Console.WriteLine("file is not created");
            }

            //--------------------------------------------------------

            Console.WriteLine("write a content file:");
            string writeText = Console.ReadLine();

            ////write a file in single line
            File.WriteAllText(file, writeText);

            //--------------------------------------------------------

            //write a file in multi line
            int num;
            string contentFile;
            Console.Write("how many line in write a file=");
            num = Convert.ToInt32(Console.ReadLine());

            StreamWriter multipleLine = new StreamWriter(file);
            for (int i = 0; i < num; i++)
            {
                contentFile = Console.ReadLine();
                multipleLine.WriteLine(contentFile);
            }
            multipleLine.Close();

            //--------------------------------------------------------

            //read a file
            Console.WriteLine("Read file all content:");
            string readData = File.ReadAllText(file);
            Console.WriteLine(readData);

            //--------------------------------------------------------

            //Delete a file
            File.Delete(file);

            //--------------------------------------------------------

            //one file data to copy to another file.
            Console.WriteLine("one File to another file copy:");
            string transferFile;
            Console.Write("Enter a file name=");
            transferFile = Console.ReadLine();

            string filePath1;
            Console.Write("Enter a file path=");
            filePath1 = Console.ReadLine();

            string copyFile = Path.Combine(filePath1, transferFile);

            File.Copy(file, copyFile, true);

            //--------------------------------------------------------
        }
    }
}
