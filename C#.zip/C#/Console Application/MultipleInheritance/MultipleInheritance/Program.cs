﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface

{
    public class Program
    {
        interface details
        {
             void display();
        }

        interface employee:details
        {
            void display();
        }

        class family : employee
        {
            public void display()
            {
                Console.WriteLine("hello world");
            }
        }
        public static void Main(string[] args)
        {
            family family1 = new family();
            family1.display();
        }
    }
}
