﻿using System;

namespace csharp1
{
    public class Program
    {
        string name;
        byte age;
        string address;
        sbyte condition = 0;
        public void display(){

            //Exception handling
             try
             {
                  Console.Write("Enter a student name=");
                  name = Console.ReadLine();
             }
             catch (Exception)
             {
                 Console.WriteLine("use the correct datatypes");
             }

            //----------------------------------------------------------------
            //validation and exception handling

            while (condition != 1)
            {
                try
                {
                    Console.Write("Enter a student age=");
                    age = Convert.ToByte(Console.ReadLine());
                    if(age>5 && age < 100)
                    {
                        condition = 1;
                    }
                    else
                    {
                        Console.WriteLine("age limit is 5 and 100");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("use the correct datatype");
                }
            }

            //-------------------------------------------------------------------
            try
            {
                Console.Write("Enter a address=");
                address = Console.ReadLine();
            }catch (Exception)
            {
                Console.WriteLine("use the correct datatype");
            }

            Console.WriteLine("--------------------------------------");

            Console.WriteLine("Student details:");
            Console.WriteLine("Student name=" + name);
            Console.WriteLine("Student name=" + age);
            Console.WriteLine("Student address=" + address);

        }

        public static void Main(string[] args)
        {
            Program program = new Program();
            program.display();
        }
    }
}
