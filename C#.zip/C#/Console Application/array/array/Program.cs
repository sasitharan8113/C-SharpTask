﻿using System;

namespace array
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.Write("Enter a number=");
            byte num= Convert.ToByte(Console.ReadLine());
            
            int i,j,temp=0;
            int[] arr=new int[num];

            //-------------------------------------------------
            
            Console.WriteLine("insert the array element:");
            for (i = 0; i < num; i++)
            {
                arr[i]=Convert.ToByte(Console.ReadLine());
            }

            //-------------------------------------------------
            
            Console.Write("\nArray elements=");
            for(i= 0; i < arr.Length; i++)
            {
                Console.Write(arr[i]+" ");
            }

            //-------------------------------------------------

            Console.WriteLine("\narray sum:");
            int sum=0;
            for(i=0;i< arr.Length; i++)
            {
                sum += arr[i];
            }

            Console.Write("sum of array=" + sum);

            //-------------------------------------------------

            Console.WriteLine("\nsort of array:");
            for(i=0;i< arr.Length; i++)
            {
                for (j = i + 1; j < arr.Length; j++)
                {
                    if (arr[i] > arr[j])
                    {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
                Console.WriteLine(arr[i]);
            }
            //-------------------------------------------------
            Console.WriteLine();
        }
    }
}
