﻿using System;

namespace Guid1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Guid demoGuid = Guid.NewGuid();
            Console.WriteLine(demoGuid);
        }
    }
}
