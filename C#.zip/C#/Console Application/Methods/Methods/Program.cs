﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods
{
    public class Program
    {

        //static methods
        public static void add(int a,int b)
        {
            int sum=a+b;
            Console.WriteLine("sum="+sum);
        }

        //non static methods
        public void add(int a,int b,int c)
        {
            int sum = a + b + c;
            Console.WriteLine("sum1="+sum);
        }

        public static void Main(string[] args)
        {
            add(2, 4);
            Program program = new Program();
            program.add(2,5,4);
        }
    }
}
