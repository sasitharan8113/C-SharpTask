﻿using System;

namespace Matrix
{
    public class Program
    {

        public static void Main(string[] args)
        {
            Console.WriteLine("First matrix:");

            int row,col,i,j,num;
           
            Console.Write("Enter a row size=");
            row=Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter a column size=");
            col=Convert.ToInt32(Console.ReadLine());

            int[,] arr= new int[row,col];

            Console.WriteLine("Enter a array element:");

            for (i = 0; i < row; i++) {
                for (j = 0; j < col; j++)
                {
                    arr[i,j]= Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("--------------------------------------------------");

            //---------------------------------------------------------------------

            Console.WriteLine("Second matrix:");

            int[,] arr1 = new int[row, col];

            Console.WriteLine("Enter a array element:");

            for (i = 0; i < row; i++)
            {
                for (j = 0; j < col; j++)
                {
                    arr1[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("--------------------------------------------------");

            //---------------------------------------------------------------------

            //Console.WriteLine("Third matrix:");

            int[,] arr2 = new int[row, col];

            //---------------------------------------------------------------------

            Console.WriteLine("Display the first matrix array:");
            for (i = 0; i < row; i++)
            {
                for (j = 0; j < col; j++)
                {
                    Console.Write(arr[i, j] + " ");
                }
                Console.WriteLine();
            }

            Console.WriteLine("--------------------------------------------------");

            Console.WriteLine("Display the second matrix array:");
            for (i = 0; i < row; i++)
            {
                for (j = 0; j < col; j++)
                {
                    Console.Write(arr1[i, j] + " ");
                }
                Console.WriteLine();
            }

            Console.WriteLine("--------------------------------------------------");

            //---------------------------------------------------------------------

            Console.WriteLine("Menu:");
            Console.WriteLine("1. Add Matrix");
            Console.WriteLine("2. Subtract Matrix");
            Console.WriteLine("3. Multiply Matrix");
            Console.WriteLine("4. Divide Matrix");
            Console.WriteLine("5. Exit");


            do
            {
                Console.Write("\nEnter your choice: ");
                num = Convert.ToInt32(Console.ReadLine());

                switch (num)
                {
                    case 1:
                        for (i = 0; i < row; i++)
                        {
                            for (j = 0; j < col; j++)
                            {
                                arr2[i, j] = arr[i, j] + arr1[i, j];
                            }
                        }
                        Console.WriteLine("Addition the Two matrix:");
                        for (i = 0; i < row; i++)
                        {
                            for (j = 0; j < col; j++)
                            {
                                Console.Write(arr2[i, j] + " ");
                            }
                            Console.WriteLine();
                        }
                        break;


                    case 2:
                        for (i = 0; i < row; i++)
                        {
                            for (j = 0; j < col; j++)
                            {
                                arr2[i, j] = arr[i, j] - arr1[i, j];
                            }
                        }
                        Console.WriteLine("Subtraction the Two matrix:");
                        for (i = 0; i < row; i++)
                        {
                            for (j = 0; j < col; j++)
                            {
                                Console.Write(arr2[i, j] + " ");
                            }
                            Console.WriteLine();
                        }
                        break;


                    case 3:
                        for (i = 0; i < row; i++)
                        {
                            for (j = 0; j < col; j++)
                            {
                                arr2[i, j] = arr[i, j] * arr1[i, j];
                            }
                        }
                        Console.WriteLine("Multiplication the Two matrix:");
                        for (i = 0; i < row; i++)
                        {
                            for (j = 0; j < col; j++)
                            {
                                Console.Write(arr2[i, j] + " ");
                            }
                            Console.WriteLine();
                        }
                        break;

                    case 4:

                        for (i = 0; i < row; i++)
                        {
                            for (j = 0; j < col; j++)
                            {
                                arr2[i, j] = arr[i, j] / arr1[i, j];
                            }
                        }
                        Console.WriteLine("Division the Two matrix:");
                        for (i = 0; i < row; i++)
                        {
                            for (j = 0; j < col; j++)
                            {
                                Console.Write(arr2[i, j] + " ");
                            }
                            Console.WriteLine();
                        }
                        break;
                      
                    case 5:
                        Console.WriteLine("Exit.");
                        return;


                    default:
                        Console.WriteLine("Invalid number");
                        break;
                }
                

            } while (num != 5);
        }
    }
}
