﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Struct
{
    public class Program
    {
        struct details
        {
            public string name;
            public byte age;
            public ulong phoneNumber;
        }
        public static void Main(string[] args)
        {
           // details del=new details();
            details del;
            del.name = "sasi";
            del.age = 23;
            del.phoneNumber = 8870244640;
            Console.WriteLine(del.name);
            Console.WriteLine(del.age); 
            Console.WriteLine(del.phoneNumber);

        }
    }
}
