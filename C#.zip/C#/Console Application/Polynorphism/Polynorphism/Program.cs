﻿using System;

namespace Polymorphism
{
    public class Program
    {
        class rbi
        {
            public virtual void display() {
                Console.WriteLine("rbi provide gold loan interest rate=9.0%");
            }
        }

        class sbi : rbi
        {
            public override void display()
            {
                Console.WriteLine("sbi provide gold loan interest rate=8.6%");
            }
        }

        class tmb : rbi { 
            public override void display()
            {
                Console.WriteLine("tmb provide gold loan interest rate=9.5%");
            }
        }
        public static void Main(string[] args)
        {
            rbi r1=new rbi();
            rbi s1=new sbi();
            rbi s2=new tmb();
            r1.display();
            s1.display();
            s2.display();
        }
    }
}
