﻿using System;


namespace Encapsulation
{
    class details
    {
        private string name;
        private int age;
        private string address;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public void display()
        {
            Console.WriteLine("Enter a name="+name);
            Console.WriteLine("Enter a age=" + age);
            Console.WriteLine("Enter a address="+address);
        }
        
    }

    public class Program
    {
        public static void Main(string[] args)
        {
      
                details del = new details();
                del.Name = "sasi";
                del.Age = 25;
                del.Address = "kovilpatti";
                del.display();
        }
    }
}
